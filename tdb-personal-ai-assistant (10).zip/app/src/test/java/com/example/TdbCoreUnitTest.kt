package com.example

import com.example.core.error.ApiHttpException
import com.example.core.error.ErrorRecoveryEngine
import com.example.core.network.DiscoveredGeminiModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.net.UnknownHostException

class TdbCoreUnitTest {

    @Test
    fun `model discovery capability check never fakes text model as image generator`() {
        val textModel = DiscoveredGeminiModel(
            id = "gemini-2.5-flash",
            resourceName = "models/gemini-2.5-flash",
            displayName = "Gemini 2.5 Flash",
            description = "Fast multimodal text model",
            supportedMethods = listOf("generateContent", "countTokens"),
            inputTokenLimit = 1048576,
            outputTokenLimit = 8192
        )
        val imageModel = DiscoveredGeminiModel(
            id = "gemini-2.5-flash-image",
            resourceName = "models/gemini-2.5-flash-image",
            displayName = "Gemini 2.5 Flash Image",
            description = "Native image generation",
            supportedMethods = listOf("generateContent"),
            inputTokenLimit = 32768,
            outputTokenLimit = 8192
        )

        assertTrue(textModel.supportsGenerateContent)
        assertFalse(textModel.supportsImageOutput)
        assertEquals("Text & Multimodal", textModel.capabilitySummary)
        assertTrue(imageModel.supportsImageOutput)
    }

    @Test
    fun `error recovery engine classifies network and auth errors clearly`() {
        val authDiag = ErrorRecoveryEngine.diagnose(ApiHttpException(401, "{}", "API key invalid"), "Chat")
        assertTrue(authDiag.requiresUserPermission)
        assertFalse(authDiag.isRetryable)
        assertTrue(authDiag.recoverySuggestion.contains("API", ignoreCase = true))

        val offlineDiag = ErrorRecoveryEngine.diagnose(UnknownHostException("generativelanguage.googleapis.com"), "Models")
        assertTrue(offlineDiag.isRetryable)
        assertTrue(offlineDiag.userMessage.contains("offline", ignoreCase = true))
        assertTrue(offlineDiag.causeSummary.contains("internet", ignoreCase = true))
    }

    @Test
    fun `natural language file command parser extracts folder, file, and language`() {
        val cmd = "Create a folder named TDB Project and create an index.html file inside it."
        val plan = com.example.core.files.ControlledFileEngine.parseNaturalCommandStatic(cmd)

        assertEquals("TDB Project", plan.folderName)
        assertEquals("index.html", plan.fileName)
        assertEquals("HTML", plan.languageHint)

        val quotedPlan = com.example.core.files.ControlledFileEngine.parseNaturalCommandStatic(
            "Make a directory called \"MyApp_v2\" with script.py inside"
        )
        assertEquals("MyApp_v2", quotedPlan.folderName)
        assertEquals("script.py", quotedPlan.fileName)
        assertEquals("Python", quotedPlan.languageHint)
    }

    @Test
    fun `memory secret guard pattern detects API keys and password assignments`() {
        val secretRegex = Regex("""AIza[0-9A-Za-z\-_]{20,}""")
        val assignRegex = Regex(
            """\b(password|passcode|api[_\s]?key|secret[_\s]?key|access[_\s]?token|oauth[_\s]?token)\b\s*[:=]\s*\S+""",
            RegexOption.IGNORE_CASE
        )

        assertTrue(secretRegex.containsMatchIn("AIzaSyDummyKeyForUnitTest1234567890ABCD"))
        assertTrue(assignRegex.containsMatchIn("password: superSecretValue99"))
        assertFalse(secretRegex.containsMatchIn("Deep Barmon Bhai Vlog channel uploads in Bengali"))
        assertFalse(assignRegex.containsMatchIn("Deep Barmon Bhai Vlog channel uploads in Bengali"))
    }
}
