package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.automation.services.TdbVoiceWakeService
import com.example.ui.components.TdbAtmosphereBackground
import com.example.ui.screens.AutomationScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.CodingAssistantScreen
import com.example.ui.screens.ControlHubScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ErrorLogsScreen
import com.example.ui.screens.FileManagerScreen
import com.example.ui.screens.GeminiApiManagementScreen
import com.example.ui.screens.ImageGenScreen
import com.example.ui.screens.MemoryVaultScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.PermissionCenterScreen
import com.example.ui.screens.ProfileSettingsScreen
import com.example.ui.screens.StudioHubScreen
import com.example.ui.screens.TaskSchedulerScreen
import com.example.ui.screens.ThumbnailStudioScreen
import com.example.ui.screens.VideoCreatorScreen
import com.example.ui.screens.VoiceScreen
import com.example.ui.screens.YouTubeAutomationScreen
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.ElectricAzure
import com.example.ui.theme.TdbAssistantTheme
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.viewmodel.ChatViewModel
import com.example.ui.viewmodel.ControlViewModel
import com.example.ui.viewmodel.MainAppViewModel
import com.example.ui.viewmodel.StudioViewModel
import com.example.ui.viewmodel.VoiceViewModel

private data class TdbTopTab(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val testTag: String
)

class MainActivity : ComponentActivity() {

    private val incomingIntentState = mutableStateOf<Intent?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        incomingIntentState.value = intent

        val appContainer = (application as TdbApplication).container

        setContent {
            TdbAssistantTheme {
                val mainAppViewModel: MainAppViewModel = viewModel(
                    factory = MainAppViewModel.provideFactory(appContainer)
                )
                val chatViewModel: ChatViewModel = viewModel(
                    factory = ChatViewModel.provideFactory(appContainer)
                )
                val voiceViewModel: VoiceViewModel = viewModel(
                    factory = VoiceViewModel.provideFactory(appContainer)
                )
                val studioViewModel: StudioViewModel = viewModel(
                    factory = StudioViewModel.provideFactory(appContainer)
                )
                val controlViewModel: ControlViewModel = viewModel(
                    factory = ControlViewModel.provideFactory(appContainer)
                )

                TdbRootShell(
                    incomingIntent = incomingIntentState.value,
                    onIntentConsumed = { incomingIntentState.value = null },
                    mainAppViewModel = mainAppViewModel,
                    chatViewModel = chatViewModel,
                    voiceViewModel = voiceViewModel,
                    studioViewModel = studioViewModel,
                    controlViewModel = controlViewModel
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        incomingIntentState.value = intent
    }
}

@Composable
private fun TdbRootShell(
    incomingIntent: Intent?,
    onIntentConsumed: () -> Unit,
    mainAppViewModel: MainAppViewModel,
    chatViewModel: ChatViewModel,
    voiceViewModel: VoiceViewModel,
    studioViewModel: StudioViewModel,
    controlViewModel: ControlViewModel
) {
    val navController = rememberNavController()
    val settings by mainAppViewModel.settings.collectAsStateWithLifecycle()
    val discoveredModels by mainAppViewModel.discoveredModels.collectAsStateWithLifecycle()
    val connectionReport by mainAppViewModel.connectionReport.collectAsStateWithLifecycle()
    val recentLogs by mainAppViewModel.recentLogs.collectAsStateWithLifecycle()
    val isOnline by mainAppViewModel.isOnline.collectAsStateWithLifecycle()

    var pendingYouTubeTopic by remember { mutableStateOf("") }

    val topTabs = remember {
        listOf(
            TdbTopTab("dashboard", "Home", Icons.Filled.Dashboard, "nav_home"),
            TdbTopTab("chat", "Chat", Icons.Filled.ChatBubble, "nav_chat"),
            TdbTopTab("voice", "Voice", Icons.Filled.Mic, "nav_voice"),
            TdbTopTab("studio_hub", "Studio", Icons.Filled.AutoAwesome, "nav_studio"),
            TdbTopTab("control_hub", "Control", Icons.Filled.Tune, "nav_control")
        )
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: "onboarding"
    val showPrimaryNav = currentRoute != "onboarding"

    val navigateTo: (String) -> Unit = { target ->
        val isTopTab = topTabs.any { it.route == target }
        if (isTopTab) {
            navController.navigate(target) {
                popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                }
                launchSingleTop = true
                restoreState = true
            }
        } else {
            navController.navigate(target) {
                launchSingleTop = true
            }
        }
    }

    // Handle incoming OAuth redirect or Voice notification deep link
    LaunchedEffect(incomingIntent) {
        val intent = incomingIntent ?: return@LaunchedEffect
        val dataUri: Uri? = intent.data
        if (dataUri != null && dataUri.scheme == "com.aistudio.tdbassistant.kxmzqr") {
            controlViewModel.handleOAuthCallback(dataUri)
            mainAppViewModel.markOnboardingSeen()
            navController.navigate("youtube_automation") {
                launchSingleTop = true
            }
            onIntentConsumed()
        } else if (intent.getBooleanExtra(TdbVoiceWakeService.EXTRA_OPEN_VOICE, false)) {
            mainAppViewModel.markOnboardingSeen()
            navController.navigate("voice") {
                launchSingleTop = true
            }
            onIntentConsumed()
        }
    }

    TdbAtmosphereBackground(glowIntensity = settings.glowIntensity) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 720.dp

            Scaffold(
                containerColor = Color.Transparent,
                bottomBar = {
                    if (showPrimaryNav && !useRail) {
                        TdbBottomNavBar(
                            tabs = topTabs,
                            currentRoute = currentRoute,
                            onSelect = navigateTo
                        )
                    }
                }
            ) { innerPadding ->
                Row(modifier = Modifier.fillMaxSize()) {
                    if (showPrimaryNav && useRail) {
                        TdbSideNavRail(
                            tabs = topTabs,
                            currentRoute = currentRoute,
                            onSelect = navigateTo
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        val contentPadding = if (useRail) PaddingValues(bottom = 16.dp) else innerPadding

                        NavHost(
                            navController = navController,
                            startDestination = if (settings.hasSeenOnboarding) "dashboard" else "onboarding",
                            modifier = Modifier
                                .fillMaxSize()
                                .widthIn(max = 920.dp)
                        ) {
                            composable("onboarding") {
                                LaunchedEffect(settings.hasSeenOnboarding) {
                                    if (settings.hasSeenOnboarding) {
                                        navController.navigate("dashboard") {
                                            popUpTo("onboarding") { inclusive = true }
                                        }
                                    }
                                }
                                OnboardingScreen(
                                    onGetStarted = {
                                        mainAppViewModel.markOnboardingSeen()
                                        navController.navigate("dashboard") {
                                            popUpTo("onboarding") { inclusive = true }
                                        }
                                    }
                                )
                            }

                            composable("dashboard") {
                                DashboardScreen(
                                    settings = settings,
                                    connectionReport = connectionReport,
                                    isOnline = isOnline,
                                    recentLogs = recentLogs,
                                    onNavigate = navigateTo,
                                    bottomPadding = contentPadding
                                )
                            }

                            composable("chat") {
                                ChatScreen(
                                    chatViewModel = chatViewModel,
                                    settings = settings,
                                    onLanguageChange = { mainAppViewModel.setPrimaryLanguage(it) },
                                    onOpenApiManagement = { navigateTo("api_management") },
                                    bottomPadding = contentPadding
                                )
                            }

                            composable("voice") {
                                VoiceScreen(
                                    voiceViewModel = voiceViewModel,
                                    settings = settings,
                                    onBack = { navController.popBackStack() },
                                    onOpenChat = { navigateTo("chat") },
                                    bottomPadding = contentPadding
                                )
                            }

                            composable("studio_hub") {
                                StudioHubScreen(
                                    onNavigate = navigateTo,
                                    bottomPadding = contentPadding
                                )
                            }

                            composable("image_gen") {
                                ImageGenScreen(
                                    studioViewModel = studioViewModel,
                                    settings = settings,
                                    discoveredModels = discoveredModels,
                                    onBack = { navController.popBackStack() },
                                    onOpenApiManagement = { navigateTo("api_management") },
                                    bottomPadding = contentPadding
                                )
                            }

                            composable("thumbnail_studio") {
                                ThumbnailStudioScreen(
                                    studioViewModel = studioViewModel,
                                    onBack = { navController.popBackStack() },
                                    bottomPadding = contentPadding
                                )
                            }

                            composable("video_creator") {
                                VideoCreatorScreen(
                                    studioViewModel = studioViewModel,
                                    onBack = { navController.popBackStack() },
                                    onSendToYouTube = { topic ->
                                        pendingYouTubeTopic = topic
                                        navigateTo("youtube_automation")
                                    },
                                    bottomPadding = contentPadding
                                )
                            }

                            composable("coding_assistant") {
                                CodingAssistantScreen(
                                    studioViewModel = studioViewModel,
                                    settings = settings,
                                    onBack = { navController.popBackStack() },
                                    bottomPadding = contentPadding
                                )
                            }

                            composable("control_hub") {
                                ControlHubScreen(
                                    onNavigate = navigateTo,
                                    bottomPadding = contentPadding
                                )
                            }

                            composable("automation") {
                                AutomationScreen(
                                    controlViewModel = controlViewModel,
                                    onBack = { navController.popBackStack() },
                                    onOpenPermissions = { navigateTo("permission_center") },
                                    bottomPadding = contentPadding
                                )
                            }

                            composable("permission_center") {
                                PermissionCenterScreen(
                                    controlViewModel = controlViewModel,
                                    studioViewModel = studioViewModel,
                                    onBack = { navController.popBackStack() },
                                    bottomPadding = contentPadding
                                )
                            }

                            composable("file_manager") {
                                FileManagerScreen(
                                    studioViewModel = studioViewModel,
                                    settings = settings,
                                    onBack = { navController.popBackStack() },
                                    bottomPadding = contentPadding
                                )
                            }

                            composable("task_scheduler") {
                                TaskSchedulerScreen(
                                    controlViewModel = controlViewModel,
                                    onBack = { navController.popBackStack() },
                                    bottomPadding = contentPadding
                                )
                            }

                            composable("youtube_automation") {
                                YouTubeAutomationScreen(
                                    controlViewModel = controlViewModel,
                                    settings = settings,
                                    initialTopic = pendingYouTubeTopic,
                                    onBack = { navController.popBackStack() },
                                    bottomPadding = contentPadding
                                )
                            }

                            composable("memory_vault") {
                                MemoryVaultScreen(
                                    controlViewModel = controlViewModel,
                                    mainAppViewModel = mainAppViewModel,
                                    settings = settings,
                                    onBack = { navController.popBackStack() },
                                    bottomPadding = contentPadding
                                )
                            }

                            composable("error_logs") {
                                ErrorLogsScreen(
                                    controlViewModel = controlViewModel,
                                    onBack = { navController.popBackStack() },
                                    bottomPadding = contentPadding
                                )
                            }

                            composable("profile_settings") {
                                ProfileSettingsScreen(
                                    mainAppViewModel = mainAppViewModel,
                                    settings = settings,
                                    connectionReport = connectionReport,
                                    onNavigate = navigateTo,
                                    onBack = { navController.popBackStack() },
                                    bottomPadding = contentPadding
                                )
                            }

                            composable("api_management") {
                                GeminiApiManagementScreen(
                                    mainAppViewModel = mainAppViewModel,
                                    settings = settings,
                                    discoveredModels = discoveredModels,
                                    connectionReport = connectionReport,
                                    onBack = { navController.popBackStack() },
                                    bottomPadding = contentPadding
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TdbBottomNavBar(
    tabs: List<TdbTopTab>,
    currentRoute: String,
    onSelect: (String) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(Color(0xFF0E1426).copy(alpha = 0.90f))
            .border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(26.dp))
    ) {
        NavigationBar(
            containerColor = Color.Transparent,
            tonalElevation = 0.dp
        ) {
            tabs.forEach { tab ->
                val selected = currentRoute == tab.route
                NavigationBarItem(
                    selected = selected,
                    onClick = { onSelect(tab.route) },
                    icon = { Icon(tab.icon, contentDescription = tab.label) },
                    label = { Text(tab.label) },
                    modifier = Modifier.testTag(tab.testTag),
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = ElectricAzure,
                        indicatorColor = CrimsonPrimary.copy(alpha = 0.35f),
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted
                    )
                )
            }
        }
    }
}

@Composable
private fun TdbSideNavRail(
    tabs: List<TdbTopTab>,
    currentRoute: String,
    onSelect: (String) -> Unit
) {
    NavigationRail(
        containerColor = Color(0xFF0E1426).copy(alpha = 0.85f),
        modifier = Modifier
            .fillMaxHeight()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        tabs.forEach { tab ->
            val selected = currentRoute == tab.route
            NavigationRailItem(
                selected = selected,
                onClick = { onSelect(tab.route) },
                icon = { Icon(tab.icon, contentDescription = tab.label) },
                label = { Text(tab.label) },
                modifier = Modifier.testTag(tab.testTag),
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = Color.White,
                    selectedTextColor = ElectricAzure,
                    indicatorColor = CrimsonPrimary.copy(alpha = 0.35f),
                    unselectedIconColor = TextMuted,
                    unselectedTextColor = TextMuted
                )
            )
        }
    }
}
