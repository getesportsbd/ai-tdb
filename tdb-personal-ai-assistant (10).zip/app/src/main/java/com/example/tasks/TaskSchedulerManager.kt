package com.example.tasks

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.example.core.data.db.ScheduledTaskEntity
import com.example.core.data.repository.TdbRepository
import com.example.core.network.GenerationOptions
import kotlinx.coroutines.flow.first
import org.json.JSONObject
import java.util.Calendar
import java.util.UUID
import java.util.concurrent.TimeUnit

data class ParsedTaskBlueprint(
    val title: String,
    val actionType: String,
    val recurrence: String,
    val scheduledAtMs: Long,
    val planSummary: String,
    val requiredPermissions: String,
    val requiredResources: String
)

class TaskSchedulerManager(
    private val context: Context,
    private val repository: TdbRepository
) {
    private val workManager = WorkManager.getInstance(context)

    suspend fun createIntelligentTaskPlan(
        command: String,
        fallbackActionType: String,
        fallbackRecurrence: String,
        fallbackTimeMs: Long
    ): ParsedTaskBlueprint {
        val apiKey = repository.getGeminiApiKey()
        val modelId = repository.preferences.settingsFlow.first().selectedChatModelId

        if (!apiKey.isNullOrBlank() && modelId.isNotBlank()) {
            val aiPlan = runCatching {
                val prompt = """
                    Analyze this autonomous task command and respond ONLY with raw JSON:
                    Command: "$command"
                    Current epoch ms: ${System.currentTimeMillis()}
                    JSON keys:
                    - "title": short clear title
                    - "actionType": one of ["YOUTUBE_PREP", "AI_BRIEFING", "FILE_OPERATION", "REMINDER"]
                    - "recurrence": one of ["ONCE", "DAILY", "WEEKLY"]
                    - "delayMinutes": integer >= 1 (estimate from command, e.g., tomorrow 8am or 15 mins)
                    - "planSteps": numbered 3-step execution plan string
                    - "requiredPermissions": comma-separated permissions needed (e.g., "Notifications, Network" or "SAF Storage")
                    - "requiredResources": comma-separated resources (e.g., "Gemini API Key, Video Topic")
                """.trimIndent()
                val raw = repository.geminiApi.generateText(
                    apiKey = apiKey,
                    modelId = modelId,
                    systemInstruction = "Return valid JSON only without markdown fences.",
                    prompt = prompt,
                    options = GenerationOptions(temperature = 0.2f, preferInteractionsApi = false)
                ).trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()

                val json = JSONObject(raw)
                val delayMins = json.optLong("delayMinutes", 15L).coerceAtLeast(1L)
                ParsedTaskBlueprint(
                    title = json.optString("title").ifBlank { command.take(42) },
                    actionType = json.optString("actionType").ifBlank { fallbackActionType },
                    recurrence = json.optString("recurrence").ifBlank { fallbackRecurrence },
                    scheduledAtMs = System.currentTimeMillis() + delayMins * 60_000L,
                    planSummary = json.optString("planSteps").ifBlank { "1. Validate resources\n2. Execute AI action\n3. Verify & notify" },
                    requiredPermissions = json.optString("requiredPermissions").ifBlank { "Notifications" },
                    requiredResources = json.optString("requiredResources").ifBlank { "Gemini API Key" }
                )
            }.getOrNull()
            if (aiPlan != null) return aiPlan
        }

        return buildDeterministicPlan(command, fallbackActionType, fallbackRecurrence, fallbackTimeMs)
    }

    private fun buildDeterministicPlan(
        command: String,
        actionType: String,
        recurrence: String,
        timeMs: Long
    ): ParsedTaskBlueprint {
        val lower = command.lowercase()
        val inferredType = when {
            lower.contains("youtube") || lower.contains("video") || lower.contains("upload") -> "YOUTUBE_PREP"
            lower.contains("file") || lower.contains("folder") || lower.contains("html") -> "FILE_OPERATION"
            lower.contains("remind") -> "REMINDER"
            else -> actionType
        }
        val inferredTime = if (lower.contains("tomorrow") && lower.contains("8")) {
            Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, 1)
                set(Calendar.HOUR_OF_DAY, 8)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
            }.timeInMillis
        } else timeMs

        val steps = when (inferredType) {
            "YOUTUBE_PREP" -> "1. Check Gemini API key & channel notes\n2. Generate YouTube title, description, tags & checklist\n3. Save to Video Creator & notify Deep"
            "FILE_OPERATION" -> "1. Verify authorized workspace/SAF folder\n2. Generate code & create requested files\n3. Verify written bytes & notify"
            else -> "1. Check task preconditions\n2. Execute AI briefing/reminder\n3. Verify completion & log receipt"
        }

        return ParsedTaskBlueprint(
            title = command.take(48).ifBlank { "Autonomous TDB Task" },
            actionType = inferredType,
            recurrence = recurrence,
            scheduledAtMs = inferredTime,
            planSummary = steps,
            requiredPermissions = if (inferredType == "FILE_OPERATION") "Notifications, SAF Folder" else "Notifications, Network",
            requiredResources = if (inferredType == "REMINDER") "Local WorkManager" else "Gemini API Key"
        )
    }

    suspend fun scheduleTask(task: ScheduledTaskEntity): ScheduledTaskEntity {
        val taskId = if (task.id == 0L) repository.insertTask(task) else {
            repository.updateTask(task)
            task.id
        }
        val saved = task.copy(id = taskId)
        val delayMs = (saved.scheduledAtMs - System.currentTimeMillis()).coerceAtLeast(5_000L)

        val constraints = Constraints.Builder()
            .setRequiredNetworkType(
                if (saved.actionType == "REMINDER") NetworkType.NOT_REQUIRED else NetworkType.CONNECTED
            )
            .build()

        val input = Data.Builder()
            .putLong(AutonomousTaskWorker.KEY_TASK_ID, taskId)
            .build()

        val workUuid: UUID = if (saved.recurrence == "ONCE") {
            val req = OneTimeWorkRequestBuilder<AutonomousTaskWorker>()
                .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .setInputData(input)
                .addTag("tdb_task_$taskId")
                .build()
            workManager.enqueueUniqueWork("tdb_unique_$taskId", ExistingWorkPolicy.REPLACE, req)
            req.id
        } else {
            val repeatHours = if (saved.recurrence == "WEEKLY") 24L * 7L else 24L
            val req = PeriodicWorkRequestBuilder<AutonomousTaskWorker>(repeatHours, TimeUnit.HOURS)
                .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
                .setConstraints(constraints)
                .setInputData(input)
                .addTag("tdb_task_$taskId")
                .build()
            workManager.enqueueUniquePeriodicWork("tdb_periodic_$taskId", ExistingPeriodicWorkPolicy.UPDATE, req)
            req.id
        }

        val updated = saved.copy(workerUuid = workUuid.toString(), status = "SCHEDULED")
        repository.updateTask(updated)
        repository.logAction("TASK", "Scheduled: ${updated.title}", "WorkManager queued (${updated.recurrence}).", "SUCCESS")
        return updated
    }

    fun runTaskNow(taskId: Long) {
        val input = Data.Builder().putLong(AutonomousTaskWorker.KEY_TASK_ID, taskId).build()
        val req = OneTimeWorkRequestBuilder<AutonomousTaskWorker>()
            .setInputData(input)
            .addTag("tdb_task_now_$taskId")
            .build()
        workManager.enqueue(req)
    }

    suspend fun cancelTask(task: ScheduledTaskEntity) {
        task.workerUuid?.let { uuidStr ->
            runCatching { workManager.cancelWorkById(UUID.fromString(uuidStr)) }
        }
        workManager.cancelAllWorkByTag("tdb_task_${task.id}")
        repository.updateTask(task.copy(status = "CANCELLED", updatedAtMs = System.currentTimeMillis()))
        repository.logAction("TASK", "Cancelled: ${task.title}", "WorkManager job cancelled.", "WARNING")
    }
}
