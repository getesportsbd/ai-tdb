package com.example.youtube

import android.content.Context
import android.net.Uri
import android.util.Base64
import androidx.browser.customtabs.CustomTabsIntent
import com.example.core.error.ApiHttpException
import com.example.core.security.KeystoreCryptoManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okio.BufferedSink
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.TimeUnit

data class YouTubeChannelInfo(
    val id: String,
    val title: String,
    val subscriberCount: String
)

data class YouTubeUploadResult(
    val videoId: String,
    val privacyStatus: String,
    val processingStatus: String,
    val watchUrl: String
)

/**
 * Official YouTube Data API v3 + Google OAuth 2.0 PKCE automation module.
 * IMPORTANT: Gemini API Key alone is NEVER treated as YouTube authorization.
 */
class YouTubeAutomationManager(
    private val context: Context,
    private val crypto: KeystoreCryptoManager
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(180, TimeUnit.SECONDS)
        .build()

    private var pendingCodeVerifier: String? = null
    private var pendingClientId: String? = null

    fun hasYouTubeOAuthToken(): Boolean =
        !crypto.getSecret(KeystoreCryptoManager.KEY_YOUTUBE_ACCESS_TOKEN).isNullOrBlank()

    fun saveManualOAuthToken(accessToken: String): Result<Unit> =
        crypto.saveSecret(KeystoreCryptoManager.KEY_YOUTUBE_ACCESS_TOKEN, accessToken.trim())

    fun disconnectYouTube() {
        crypto.deleteSecret(KeystoreCryptoManager.KEY_YOUTUBE_ACCESS_TOKEN)
        crypto.deleteSecret(KeystoreCryptoManager.KEY_YOUTUBE_REFRESH_TOKEN)
    }

    fun launchOAuthPkceFlow(oauthClientId: String): Result<Unit> = runCatching {
        require(oauthClientId.isNotBlank()) {
            "Enter your Google Cloud OAuth 2.0 Android/Installed Client ID first."
        }
        val verifierBytes = ByteArray(32).also { SecureRandom().nextBytes(it) }
        val verifier = Base64.encodeToString(verifierBytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
        val challengeBytes = MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII))
        val challenge = Base64.encodeToString(challengeBytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)

        pendingCodeVerifier = verifier
        pendingClientId = oauthClientId.trim()

        val authUri = Uri.parse("https://accounts.google.com/o/oauth2/v2/auth").buildUpon()
            .appendQueryParameter("client_id", oauthClientId.trim())
            .appendQueryParameter("redirect_uri", REDIRECT_URI)
            .appendQueryParameter("response_type", "code")
            .appendQueryParameter("scope", "https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube.readonly")
            .appendQueryParameter("code_challenge", challenge)
            .appendQueryParameter("code_challenge_method", "S256")
            .appendQueryParameter("access_type", "offline")
            .appendQueryParameter("prompt", "consent")
            .build()

        CustomTabsIntent.Builder().build().launchUrl(context, authUri)
    }

    suspend fun handleOAuthRedirect(uri: Uri): Result<Boolean> = withContext(Dispatchers.IO) {
        runCatching {
            val code = uri.getQueryParameter("code")
                ?: error(uri.getQueryParameter("error") ?: "OAuth redirect missing authorization code.")
            val verifier = pendingCodeVerifier ?: error("OAuth session expired. Start Connect YouTube again.")
            val clientId = pendingClientId ?: error("Missing OAuth Client ID.")

            val formBody = "code=${Uri.encode(code)}&client_id=${Uri.encode(clientId)}" +
                "&redirect_uri=${Uri.encode(REDIRECT_URI)}&code_verifier=${Uri.encode(verifier)}" +
                "&grant_type=authorization_code"

            val request = Request.Builder()
                .url("https://oauth2.googleapis.com/token")
                .post(formBody.toRequestBody("application/x-www-form-urlencoded".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw ApiHttpException(response.code, body, "OAuth token exchange failed (${response.code})")
                }
                val json = JSONObject(body)
                val access = json.getString("access_token")
                val refresh = json.optString("refresh_token")
                crypto.saveSecret(KeystoreCryptoManager.KEY_YOUTUBE_ACCESS_TOKEN, access)
                if (refresh.isNotBlank()) {
                    crypto.saveSecret(KeystoreCryptoManager.KEY_YOUTUBE_REFRESH_TOKEN, refresh)
                }
                true
            }
        }
    }

    suspend fun fetchMyChannels(): Result<List<YouTubeChannelInfo>> = withContext(Dispatchers.IO) {
        runCatching {
            val token = crypto.getSecret(KeystoreCryptoManager.KEY_YOUTUBE_ACCESS_TOKEN)
                ?: throw SecurityException("YouTube OAuth authorization required. Gemini API key cannot access YouTube channels.")

            val request = Request.Builder()
                .url("https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&mine=true")
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw ApiHttpException(response.code, body, parseYouTubeError(body, response.code))
                }
                val items = JSONObject(body).optJSONArray("items") ?: JSONArray()
                buildList {
                    for (i in 0 until items.length()) {
                        val item = items.getJSONObject(i)
                        add(
                            YouTubeChannelInfo(
                                id = item.optString("id"),
                                title = item.optJSONObject("snippet")?.optString("title").orEmpty(),
                                subscriberCount = item.optJSONObject("statistics")?.optString("subscriberCount") ?: "Hidden"
                            )
                        )
                    }
                }
            }
        }
    }

    suspend fun uploadVideo(
        videoUri: Uri,
        title: String,
        description: String,
        tags: List<String>,
        privacyStatus: String,
        publishAtIso8601: String?,
        onProgress: (Float) -> Unit
    ): Result<YouTubeUploadResult> = withContext(Dispatchers.IO) {
        runCatching {
            val token = crypto.getSecret(KeystoreCryptoManager.KEY_YOUTUBE_ACCESS_TOKEN)
                ?: throw SecurityException("YouTube OAuth authorization required before uploading.")

            val videoBytes = context.contentResolver.openInputStream(videoUri)?.use { it.readBytes() }
                ?: error("Could not read selected video file.")
            val mimeType = context.contentResolver.getType(videoUri) ?: "video/mp4"

            val metadata = JSONObject().apply {
                put("snippet", JSONObject().apply {
                    put("title", title.trim().take(100))
                    put("description", description.trim())
                    if (tags.isNotEmpty()) {
                        put("tags", JSONArray(tags.take(15)))
                    }
                    put("categoryId", "22") // People & Blogs
                })
                put("status", JSONObject().apply {
                    put("privacyStatus", if (!publishAtIso8601.isNullOrBlank()) "private" else privacyStatus)
                    if (!publishAtIso8601.isNullOrBlank()) {
                        put("publishAt", publishAtIso8601)
                    }
                })
            }.toString()

            val boundary = "TDB_YT_${System.currentTimeMillis()}"
            val multipartBody = object : RequestBody() {
                override fun contentType() = "multipart/related; boundary=$boundary".toMediaType()
                override fun writeTo(sink: BufferedSink) {
                    val headerPart = "--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$metadata\r\n" +
                        "--$boundary\r\nContent-Type: $mimeType\r\n\r\n"
                    sink.writeUtf8(headerPart)
                    var offset = 0
                    val chunk = 65536
                    while (offset < videoBytes.size) {
                        val len = minOf(chunk, videoBytes.size - offset)
                        sink.write(videoBytes, offset, len)
                        offset += len
                        onProgress(offset.toFloat() / videoBytes.size.coerceAtLeast(1))
                    }
                    sink.writeUtf8("\r\n--$boundary--\r\n")
                }
            }

            val request = Request.Builder()
                .url("https://www.googleapis.com/upload/youtube/v3/videos?uploadType=multipart&part=snippet,status")
                .addHeader("Authorization", "Bearer $token")
                .post(multipartBody)
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw ApiHttpException(response.code, body, parseYouTubeError(body, response.code))
                }
                val json = JSONObject(body)
                val videoId = json.getString("id")
                val statusObj = json.optJSONObject("status")
                YouTubeUploadResult(
                    videoId = videoId,
                    privacyStatus = statusObj?.optString("privacyStatus") ?: privacyStatus,
                    processingStatus = "uploaded — verifying",
                    watchUrl = "https://youtu.be/$videoId"
                )
            }
        }
    }

    suspend fun verifyVideoStatus(videoId: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val token = crypto.getSecret(KeystoreCryptoManager.KEY_YOUTUBE_ACCESS_TOKEN)
                ?: throw SecurityException("YouTube OAuth token missing.")
            val request = Request.Builder()
                .url("https://www.googleapis.com/youtube/v3/videos?part=status,processingDetails&id=${Uri.encode(videoId)}")
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()
            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw ApiHttpException(response.code, body, parseYouTubeError(body, response.code))
                }
                val item = JSONObject(body).optJSONArray("items")?.optJSONObject(0)
                    ?: error("Video $videoId not found yet.")
                val uploadStatus = item.optJSONObject("status")?.optString("uploadStatus") ?: "unknown"
                val privacy = item.optJSONObject("status")?.optString("privacyStatus") ?: "unknown"
                val proc = item.optJSONObject("processingDetails")?.optString("processingStatus") ?: "pending"
                "Upload: $uploadStatus • Processing: $proc • Privacy: $privacy"
            }
        }
    }

    private fun parseYouTubeError(raw: String, code: Int): String {
        return runCatching {
            JSONObject(raw).optJSONObject("error")?.optString("message")?.takeIf { it.isNotBlank() }
        }.getOrNull() ?: "YouTube API HTTP $code"
    }

    companion object {
        const val REDIRECT_URI = "com.aistudio.tdbassistant.kxmzqr:/oauth2redirect"
    }
}
