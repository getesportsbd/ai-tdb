package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.example.core.data.AppLanguage
import com.example.core.data.VoiceGenderOption
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

enum class VoiceOrbState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING
}

class VoiceAssistantEngine(private val context: Context) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private val _orbState = MutableStateFlow(VoiceOrbState.IDLE)
    val orbState: StateFlow<VoiceOrbState> = _orbState.asStateFlow()

    private val _partialTranscript = MutableStateFlow("")
    val partialTranscript: StateFlow<String> = _partialTranscript.asStateFlow()

    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

    private val _availableVoicesInfo = MutableStateFlow<List<String>>(emptyList())
    val availableVoicesInfo: StateFlow<List<String>> = _availableVoicesInfo.asStateFlow()

    private var onFinalResultCallback: ((String) -> Unit)? = null
    private var onSpeechErrorCallback: ((String) -> Unit)? = null
    private var onTtsCompleteCallback: (() -> Unit)? = null

    init {
        initTts()
    }

    private fun initTts() {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                runCatching {
                    val voices = tts?.voices.orEmpty()
                        .filter { it.locale.language in setOf("bn", "en", "hi") }
                        .map { "${it.locale.displayLanguage} • ${it.name}" }
                        .distinct()
                        .take(12)
                    _availableVoicesInfo.value = voices
                }
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _orbState.value = VoiceOrbState.SPEAKING
                    }

                    override fun onDone(utteranceId: String?) {
                        mainHandler.post {
                            if (_orbState.value == VoiceOrbState.SPEAKING) {
                                _orbState.value = VoiceOrbState.IDLE
                            }
                            onTtsCompleteCallback?.invoke()
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        mainHandler.post {
                            _orbState.value = VoiceOrbState.IDLE
                            onTtsCompleteCallback?.invoke()
                        }
                    }
                })
            }
        }
    }

    fun startListening(
        language: AppLanguage,
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        mainHandler.post {
            // Interruption: immediately stop speaking if user activates mic
            stopSpeakingOnly()

            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                _orbState.value = VoiceOrbState.IDLE
                onError("Android Speech Recognition service is unavailable on this device.")
                return@post
            }

            onFinalResultCallback = onResult
            onSpeechErrorCallback = onError
            _partialTranscript.value = ""

            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _orbState.value = VoiceOrbState.LISTENING
                    }

                    override fun onBeginningOfSpeech() {
                        _orbState.value = VoiceOrbState.LISTENING
                    }

                    override fun onRmsChanged(rmsdB: Float) {
                        _rmsLevel.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {
                        _rmsLevel.value = 0f
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val partial = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            .orEmpty()
                        if (partial.isNotBlank()) {
                            _partialTranscript.value = partial
                        }
                    }

                    override fun onResults(results: Bundle?) {
                        val spoken = results
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            .orEmpty()
                        _rmsLevel.value = 0f
                        if (spoken.isNotBlank()) {
                            _partialTranscript.value = spoken
                            _orbState.value = VoiceOrbState.THINKING
                            onFinalResultCallback?.invoke(spoken)
                        } else {
                            _orbState.value = VoiceOrbState.IDLE
                            onSpeechErrorCallback?.invoke("Didn't catch speech. Tap mic to speak again.")
                        }
                    }

                    override fun onError(error: Int) {
                        _rmsLevel.value = 0f
                        _orbState.value = VoiceOrbState.IDLE
                        val msg = when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH -> "No speech detected."
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Listening timed out."
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required."
                            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                                "Speech recognition network error."
                            else -> "Speech recognizer error ($error)."
                        }
                        onSpeechErrorCallback?.invoke(msg)
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, language.localeTag)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            _orbState.value = VoiceOrbState.LISTENING
            runCatching { speechRecognizer?.startListening(intent) }
                .onFailure {
                    _orbState.value = VoiceOrbState.IDLE
                    onError(it.localizedMessage ?: "Unable to start speech recognizer.")
                }
        }
    }

    fun setThinkingState() {
        _orbState.value = VoiceOrbState.THINKING
    }

    fun setIdleState() {
        _orbState.value = VoiceOrbState.IDLE
    }

    fun speak(
        text: String,
        language: AppLanguage,
        speed: Float,
        gender: VoiceGenderOption,
        onDone: () -> Unit = {}
    ) {
        onTtsCompleteCallback = onDone
        val cleanText = text.replace(Regex("[*#`_]"), " ").trim()
        if (!ttsReady || cleanText.isBlank()) {
            _orbState.value = VoiceOrbState.IDLE
            onDone()
            return
        }
        mainHandler.post {
            val locale = detectLocale(cleanText, language)
            tts?.language = locale
            tts?.setSpeechRate(speed.coerceIn(0.5f, 2.0f))
            selectBestVoice(locale, gender)?.let { tts?.voice = it }
            _orbState.value = VoiceOrbState.SPEAKING
            tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
        }
    }

    fun stopAll() {
        mainHandler.post {
            runCatching { speechRecognizer?.cancel() }
            stopSpeakingOnly()
            _rmsLevel.value = 0f
            _orbState.value = VoiceOrbState.IDLE
        }
    }

    fun stopSpeakingOnly() {
        runCatching { tts?.stop() }
        if (_orbState.value == VoiceOrbState.SPEAKING) {
            _orbState.value = VoiceOrbState.IDLE
        }
    }

    fun release() {
        mainHandler.post {
            runCatching { speechRecognizer?.destroy() }
            runCatching { tts?.stop(); tts?.shutdown() }
        }
    }

    private fun detectLocale(text: String, preferred: AppLanguage): Locale {
        val hasBengali = text.any { it in '\u0980'..'\u09FF' }
        val hasDevanagari = text.any { it in '\u0900'..'\u097F' }
        return when {
            hasBengali -> Locale("bn", "IN")
            hasDevanagari -> Locale("hi", "IN")
            preferred == AppLanguage.BENGALI -> Locale("bn", "IN")
            preferred == AppLanguage.HINDI -> Locale("hi", "IN")
            else -> Locale.US
        }
    }

    private fun selectBestVoice(locale: Locale, gender: VoiceGenderOption): Voice? {
        val voices = tts?.voices.orEmpty().filter {
            it.locale.language.equals(locale.language, ignoreCase = true)
        }
        if (voices.isEmpty() || gender == VoiceGenderOption.AUTO) {
            return voices.firstOrNull { !it.isNetworkConnectionRequired } ?: voices.firstOrNull()
        }
        val targetTag = if (gender == VoiceGenderOption.MALE) "male" else "female"
        val oppositeTag = if (gender == VoiceGenderOption.MALE) "female" else "male"
        return voices.firstOrNull { v ->
            val lower = v.name.lowercase()
            val feat = v.features.joinToString(" ").lowercase()
            (lower.contains(targetTag) || feat.contains(targetTag)) && !lower.contains(oppositeTag)
        } ?: voices.firstOrNull()
    }
}
