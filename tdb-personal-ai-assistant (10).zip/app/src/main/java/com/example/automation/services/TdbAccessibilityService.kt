package com.example.automation.services

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Optional AccessibilityService enabled explicitly by the user in Android Settings.
 * Supports user-triggered global navigation actions and visible element inspection.
 */
class TdbAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isConnected.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString()
        if (!pkg.isNullOrBlank()) {
            _activePackage.value = pkg
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        _isConnected.value = false
        instance = null
        return super.onUnbind(intent)
    }

    fun performGlobalNavigation(action: Int): Boolean {
        return performGlobalAction(action)
    }

    fun readVisibleLabels(limit: Int = 12): List<String> {
        val root = rootInActiveWindow ?: return emptyList()
        val labels = mutableListOf<String>()
        collectText(root, labels, limit)
        return labels
    }

    fun clickElementByText(targetText: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val matches = root.findAccessibilityNodeInfosByText(targetText)
        for (node in matches) {
            var current: AccessibilityNodeInfo? = node
            while (current != null) {
                if (current.isClickable) {
                    return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                current = current.parent
            }
        }
        return false
    }

    private fun collectText(node: AccessibilityNodeInfo, out: MutableList<String>, limit: Int) {
        if (out.size >= limit) return
        val txt = node.text?.toString()?.trim()
        if (!txt.isNullOrBlank() && txt.length <= 80 && txt !in out) {
            out += txt
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { collectText(it, out, limit) }
        }
    }

    companion object {
        @Volatile
        var instance: TdbAccessibilityService? = null
            private set

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

        private val _activePackage = MutableStateFlow("Unknown")
        val activePackage: StateFlow<String> = _activePackage.asStateFlow()
    }
}
