package com.example.automation.services

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class CapturedNotification(
    val key: String,
    val packageName: String,
    val title: String,
    val text: String,
    val postedAtMs: Long
)

/**
 * Optional NotificationListenerService active only when user grants Notification Access.
 * Keeps recent visible notifications locally in memory for user-requested reading/summarization.
 */
class TdbNotificationListenerService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        _isConnected.value = true
        refreshActive()
    }

    override fun onListenerDisconnected() {
        _isConnected.value = false
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        sbn ?: return
        val extras = sbn.notification?.extras ?: return
        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val text = extras.getCharSequence("android.text")?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        val entry = CapturedNotification(
            key = sbn.key,
            packageName = sbn.packageName,
            title = title.ifBlank { sbn.packageName },
            text = text,
            postedAtMs = sbn.postTime
        )
        val current = _notifications.value.filterNot { it.key == entry.key }
        _notifications.value = (listOf(entry) + current).take(25)
    }

    private fun refreshActive() {
        runCatching {
            val active = activeNotifications ?: return@runCatching
            val mapped = active.mapNotNull { sbn ->
                val extras = sbn.notification?.extras ?: return@mapNotNull null
                val title = extras.getCharSequence("android.title")?.toString().orEmpty()
                val text = extras.getCharSequence("android.text")?.toString().orEmpty()
                if (title.isBlank() && text.isBlank()) null
                else CapturedNotification(sbn.key, sbn.packageName, title.ifBlank { sbn.packageName }, text, sbn.postTime)
            }.sortedByDescending { it.postedAtMs }.take(25)
            _notifications.value = mapped
        }
    }

    companion object {
        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

        private val _notifications = MutableStateFlow<List<CapturedNotification>>(emptyList())
        val notifications: StateFlow<List<CapturedNotification>> = _notifications.asStateFlow()
    }
}
