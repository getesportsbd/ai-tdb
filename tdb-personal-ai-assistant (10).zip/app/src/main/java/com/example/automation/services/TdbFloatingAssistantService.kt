package com.example.automation.services

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

/**
 * User-enabled Floating Assistant Bubble overlay.
 * Requires explicit SYSTEM_ALERT_WINDOW grant and runs as a visible foreground service.
 */
class TdbFloatingAssistantService : Service() {

    private var windowManager: WindowManager? = null
    private var bubbleView: FrameLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP || !Settings.canDrawOverlays(this)) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        showFloatingOrb()
        _isRunning.value = true
        return START_STICKY
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showFloatingOrb() {
        if (bubbleView != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val density = resources.displayMetrics.density
        val sizePx = (58 * density).toInt()

        val orbBg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#FF3B47"), Color.parseColor("#1D63DC"))
        ).apply {
            shape = GradientDrawable.OVAL
            setStroke((2 * density).toInt(), Color.argb(200, 255, 255, 255))
        }

        val label = TextView(this).apply {
            text = "TDB"
            setTextColor(Color.WHITE)
            textSize = 13f
            gravity = Gravity.CENTER
        }

        val container = FrameLayout(this).apply {
            background = orbBg
            elevation = 14f * density
            addView(label, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            ))
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            sizePx,
            sizePx,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (24 * density).toInt()
            y = (260 * density).toInt()
        }

        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        var isClick = true

        container.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    isClick = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) isClick = false
                    params.x = initialX + dx
                    params.y = initialY + dy
                    runCatching { wm.updateViewLayout(container, params) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isClick) {
                        val launch = Intent(this, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                            putExtra(TdbVoiceWakeService.EXTRA_OPEN_VOICE, true)
                        }
                        startActivity(launch)
                    }
                    true
                }
                else -> false
            }
        }

        runCatching {
            wm.addView(container, params)
            bubbleView = container
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, TdbFloatingAssistantService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 202, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("TDB Floating Assistant Active")
            .setContentText("Tap floating TDB orb for instant voice & AI access.")
            .setOngoing(true)
            .addAction(0, "Close Orb", stopPending)
            .build()
    }

    override fun onDestroy() {
        bubbleView?.let { view ->
            runCatching { windowManager?.removeView(view) }
        }
        bubbleView = null
        _isRunning.value = false
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "tdb_automation_channel"
        const val NOTIFICATION_ID = 4102
        const val ACTION_STOP = "com.example.action.STOP_FLOATING_ORB"

        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()
    }
}
