package com.example.automation.services

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Explicit, visible, Android-compliant Foreground Service for configurable wake phrases:
 * "Hey TDB", "Hello TDB", "এই TDB", "হ্যালো TDB".
 */
class TdbVoiceWakeService : Service() {

    private var speechRecognizer: SpeechRecognizer? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var wakePhrase: String = "Hey TDB"
    private var languageTag: String = "bn-IN"
    private var isStopping = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            isStopping = true
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        wakePhrase = intent?.getStringExtra(EXTRA_WAKE_PHRASE) ?: "Hey TDB"
        languageTag = intent?.getStringExtra(EXTRA_LANGUAGE_TAG) ?: "bn-IN"
        isStopping = false

        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        _isRunning.value = true
        mainHandler.post { startWakeLoop() }
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            this.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_OPEN_VOICE, true)
        }
        val openPending = PendingIntent.getActivity(
            this, 101, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = Intent(this, TdbVoiceWakeService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 102, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("TDB Voice Wake Active")
            .setContentText("Listening visibly for \"$wakePhrase\"")
            .setOngoing(true)
            .setContentIntent(openPending)
            .addAction(0, "Stop", stopPending)
            .build()
    }

    private fun startWakeLoop() {
        if (isStopping || !SpeechRecognizer.isRecognitionAvailable(this)) return
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {
                    checkMatches(partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION))
                }
                override fun onResults(results: Bundle?) {
                    val matched = checkMatches(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION))
                    if (!matched && !isStopping) {
                        mainHandler.postDelayed({ startWakeLoop() }, 450L)
                    }
                }
                override fun onError(error: Int) {
                    if (!isStopping) {
                        mainHandler.postDelayed({ startWakeLoop() }, 900L)
                    }
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val recIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        runCatching { speechRecognizer?.startListening(recIntent) }
    }

    private fun checkMatches(candidates: List<String>?): Boolean {
        if (candidates.isNullOrEmpty()) return false
        val targets = listOf(wakePhrase, "hey tdb", "hello tdb", "এই tdb", "হ্যালো tdb", "tdb")
            .map { it.lowercase() }
        val hit = candidates.any { heard ->
            val lower = heard.lowercase()
            targets.any { lower.contains(it) }
        }
        if (hit) {
            val launch = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(EXTRA_OPEN_VOICE, true)
            }
            startActivity(launch)
            mainHandler.postDelayed({ if (!isStopping) startWakeLoop() }, 2500L)
        }
        return hit
    }

    override fun onDestroy() {
        isStopping = true
        mainHandler.removeCallbacksAndMessages(null)
        speechRecognizer?.destroy()
        speechRecognizer = null
        _isRunning.value = false
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "tdb_voice_wake_channel"
        const val NOTIFICATION_ID = 4101
        const val ACTION_STOP = "com.example.action.STOP_VOICE_WAKE"
        const val EXTRA_WAKE_PHRASE = "extra_wake_phrase"
        const val EXTRA_LANGUAGE_TAG = "extra_language_tag"
        const val EXTRA_OPEN_VOICE = "extra_open_voice"

        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()
    }
}
