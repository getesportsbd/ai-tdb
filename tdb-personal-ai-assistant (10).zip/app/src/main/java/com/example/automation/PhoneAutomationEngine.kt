package com.example.automation

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.example.automation.services.TdbAccessibilityService
import com.example.automation.services.TdbFloatingAssistantService
import com.example.automation.services.TdbNotificationListenerService
import com.example.automation.services.TdbVoiceWakeService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class PermissionActionType {
    RUNTIME_MICROPHONE,
    RUNTIME_CAMERA,
    RUNTIME_LOCATION,
    RUNTIME_NOTIFICATIONS,
    SYSTEM_ACCESSIBILITY,
    SYSTEM_NOTIFICATION_LISTENER,
    SYSTEM_OVERLAY,
    SAF_DIRECTORY,
    SYSTEM_EXACT_ALARM
}

data class PermissionCenterItem(
    val id: String,
    val name: String,
    val isGranted: Boolean,
    val whyNeeded: String,
    val revokeInstructions: String,
    val actionType: PermissionActionType
)

data class SupportedAppTarget(
    val label: String,
    val packageName: String,
    val fallbackUri: String? = null
)

class PhoneAutomationEngine(private val context: Context) {

    val supportedApps = listOf(
        SupportedAppTarget("YouTube", "com.google.android.youtube", "https://www.youtube.com"),
        SupportedAppTarget("Chrome", "com.android.chrome", "https://www.google.com"),
        SupportedAppTarget("Maps", "com.google.android.apps.maps", "geo:0,0"),
        SupportedAppTarget("Gmail", "com.google.android.gm"),
        SupportedAppTarget("WhatsApp", "com.whatsapp")
    )

    fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    fun isAccessibilityEnabled(): Boolean {
        if (TdbAccessibilityService.isConnected.value) return true
        val expected = ComponentName(context, TdbAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    fun isNotificationListenerEnabled(): Boolean {
        if (TdbNotificationListenerService.isConnected.value) return true
        val expected = ComponentName(context, TdbNotificationListenerService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
            ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    fun buildPermissionCenterItems(safTreeUri: String): List<PermissionCenterItem> {
        val notifGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            hasPermission(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).areNotificationsEnabled()
        }

        val locationGranted = hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION) ||
            hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)

        val exactAlarmGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
        } else true

        return listOf(
            PermissionCenterItem(
                id = "mic",
                name = "Microphone (Voice & Wake Service)",
                isGranted = hasPermission(Manifest.permission.RECORD_AUDIO),
                whyNeeded = "Required for Bengali/English/Hindi speech recognition and the visible Hey TDB voice service.",
                revokeInstructions = "Android Settings → Apps → TDB Assistant → Permissions → Microphone.",
                actionType = PermissionActionType.RUNTIME_MICROPHONE
            ),
            PermissionCenterItem(
                id = "camera",
                name = "Camera (Photo Capture)",
                isGranted = hasPermission(Manifest.permission.CAMERA),
                whyNeeded = "Lets you capture photos for Thumbnail Studio or Gemini Vision analysis when requested.",
                revokeInstructions = "Android Settings → Apps → TDB Assistant → Permissions → Camera.",
                actionType = PermissionActionType.RUNTIME_CAMERA
            ),
            PermissionCenterItem(
                id = "location",
                name = "Location (Context-Aware Automation)",
                isGranted = locationGranted,
                whyNeeded = "Provides current coordinates only when you explicitly ask for location-based assistance.",
                revokeInstructions = "Android Settings → Apps → TDB Assistant → Permissions → Location.",
                actionType = PermissionActionType.RUNTIME_LOCATION
            ),
            PermissionCenterItem(
                id = "notifications",
                name = "Post Notifications",
                isGranted = notifGranted,
                whyNeeded = "Displays autonomous scheduled task results, upload alerts, and visible foreground indicators.",
                revokeInstructions = "Android Settings → Apps → TDB Assistant → Notifications.",
                actionType = PermissionActionType.RUNTIME_NOTIFICATIONS
            ),
            PermissionCenterItem(
                id = "saf",
                name = "Authorized Project Directory (SAF)",
                isGranted = safTreeUri.isNotBlank(),
                whyNeeded = "Grants scoped access to a folder you pick for Coding Assistant & File Manager without broad storage permissions.",
                revokeInstructions = "Tap 'Revoke SAF Folder' in File Manager or clear URI in Settings.",
                actionType = PermissionActionType.SAF_DIRECTORY
            ),
            PermissionCenterItem(
                id = "accessibility",
                name = "Accessibility Automation Service",
                isGranted = isAccessibilityEnabled(),
                whyNeeded = "Optional helper for user-triggered navigation actions (Home/Back/Recents) and reading visible UI labels.",
                revokeInstructions = "Android Settings → Accessibility → TDB Assistant → Toggle Off.",
                actionType = PermissionActionType.SYSTEM_ACCESSIBILITY
            ),
            PermissionCenterItem(
                id = "notif_listener",
                name = "Notification Reader Access",
                isGranted = isNotificationListenerEnabled(),
                whyNeeded = "Allows TDB Assistant to read and summarize incoming notifications when you ask.",
                revokeInstructions = "Android Settings → Notification Access → TDB Notification Reader → Toggle Off.",
                actionType = PermissionActionType.SYSTEM_NOTIFICATION_LISTENER
            ),
            PermissionCenterItem(
                id = "overlay",
                name = "Display Over Other Apps (Floating Orb)",
                isGranted = Settings.canDrawOverlays(context),
                whyNeeded = "Renders the optional floating TDB orb bubble when explicitly enabled.",
                revokeInstructions = "Android Settings → Apps → Special App Access → Display over other apps → TDB Assistant.",
                actionType = PermissionActionType.SYSTEM_OVERLAY
            ),
            PermissionCenterItem(
                id = "exact_alarm",
                name = "Exact Task Reminders",
                isGranted = exactAlarmGranted,
                whyNeeded = "Improves timing precision for user-scheduled autonomous tasks alongside WorkManager.",
                revokeInstructions = "Android Settings → Apps → Alarms & reminders → TDB Assistant.",
                actionType = PermissionActionType.SYSTEM_EXACT_ALARM
            )
        )
    }

    fun launchApp(target: SupportedAppTarget): Result<String> = runCatching {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(target.packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            "Opened ${target.label}."
        } else if (!target.fallbackUri.isNullOrBlank()) {
            val viewIntent = Intent(Intent.ACTION_VIEW, Uri.parse(target.fallbackUri)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(viewIntent)
            "Opened ${target.label} via system handler."
        } else {
            error("${target.label} is not installed on this device.")
        }
    }

    fun openCameraApp(): Result<String> = runCatching {
        val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        "Opened Camera."
    }

    fun openSystemSettings(action: String): Result<String> = runCatching {
        val intent = Intent(action).apply {
            if (action == Settings.ACTION_MANAGE_OVERLAY_PERMISSION ||
                action == Settings.ACTION_APPLICATION_DETAILS_SETTINGS ||
                action == Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM
            ) {
                data = Uri.parse("package:${context.packageName}")
            }
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        "Opened system settings."
    }

    fun adjustMediaVolume(increase: Boolean): String {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val direction = if (increase) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        val current = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return "Media volume set to $current / $max."
    }

    suspend fun getLastKnownLocationSummary(): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val hasCoarse = hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
            val hasFine = hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)
            if (!hasCoarse && !hasFine) {
                throw SecurityException("Location permission not granted.")
            }
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val provider = when {
                hasFine && lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                else -> LocationManager.PASSIVE_PROVIDER
            }
            @Suppress("MissingPermission")
            val loc = lm.getLastKnownLocation(provider)
            if (loc != null) {
                "Lat %.4f, Lon %.4f (via %s)".format(loc.latitude, loc.longitude, provider)
            } else {
                "Location permission granted ($provider enabled), no cached fix yet."
            }
        }
    }

    fun startFloatingOrb(): Result<String> = runCatching {
        if (!Settings.canDrawOverlays(context)) {
            throw SecurityException("Display over other apps permission is required.")
        }
        val intent = Intent(context, TdbFloatingAssistantService::class.java)
        ContextCompat.startForegroundService(context, intent)
        "Floating TDB orb started."
    }

    fun stopFloatingOrb() {
        val intent = Intent(context, TdbFloatingAssistantService::class.java).apply {
            action = TdbFloatingAssistantService.ACTION_STOP
        }
        context.startService(intent)
    }

    fun startVoiceWakeService(wakePhrase: String, languageTag: String): Result<String> = runCatching {
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) {
            throw SecurityException("Microphone permission is required for Hey TDB wake service.")
        }
        val intent = Intent(context, TdbVoiceWakeService::class.java).apply {
            putExtra(TdbVoiceWakeService.EXTRA_WAKE_PHRASE, wakePhrase)
            putExtra(TdbVoiceWakeService.EXTRA_LANGUAGE_TAG, languageTag)
        }
        ContextCompat.startForegroundService(context, intent)
        "Visible wake service started for \"$wakePhrase\"."
    }

    fun stopVoiceWakeService() {
        val intent = Intent(context, TdbVoiceWakeService::class.java).apply {
            action = TdbVoiceWakeService.ACTION_STOP
        }
        context.startService(intent)
    }

    fun triggerAccessibilityNavigation(action: String): Result<String> = runCatching {
        val service = TdbAccessibilityService.instance
            ?: error("TDB Accessibility Service is not enabled in Permission Center.")
        val code = when (action) {
            "HOME" -> AccessibilityService.GLOBAL_ACTION_HOME
            "BACK" -> AccessibilityService.GLOBAL_ACTION_BACK
            "RECENTS" -> AccessibilityService.GLOBAL_ACTION_RECENTS
            "NOTIFICATIONS" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            else -> AccessibilityService.GLOBAL_ACTION_HOME
        }
        val ok = service.performGlobalNavigation(code)
        if (ok) "Executed accessibility action: $action." else "System declined action: $action."
    }

    fun inspectScreenElements(): Result<List<String>> = runCatching {
        val service = TdbAccessibilityService.instance
            ?: error("TDB Accessibility Service is not enabled in Permission Center.")
        service.readVisibleLabels()
    }
}
