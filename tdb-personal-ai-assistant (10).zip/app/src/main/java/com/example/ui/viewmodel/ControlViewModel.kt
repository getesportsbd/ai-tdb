package com.example.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.AppContainer
import com.example.automation.PermissionCenterItem
import com.example.automation.PhoneAutomationEngine
import com.example.automation.SupportedAppTarget
import com.example.automation.services.CapturedNotification
import com.example.automation.services.TdbAccessibilityService
import com.example.automation.services.TdbFloatingAssistantService
import com.example.automation.services.TdbNotificationListenerService
import com.example.automation.services.TdbScreenCaptureService
import com.example.core.data.db.ActionLogEntity
import com.example.core.data.db.MemoryEntity
import com.example.core.data.db.ScheduledTaskEntity
import com.example.core.data.repository.TdbRepository
import com.example.core.error.ErrorRecoveryEngine
import com.example.tasks.TaskSchedulerManager
import com.example.youtube.YouTubeAutomationManager
import com.example.youtube.YouTubeChannelInfo
import com.example.youtube.YouTubeUploadResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class YouTubeUiState(
    val isConnected: Boolean = false,
    val channels: List<YouTubeChannelInfo> = emptyList(),
    val isBusy: Boolean = false,
    val uploadProgress: Float = 0f,
    val uploadResult: YouTubeUploadResult? = null,
    val statusMessage: String? = null,
    val errorMessage: String? = null
)

class ControlViewModel(
    private val repository: TdbRepository,
    val automationEngine: PhoneAutomationEngine,
    private val taskScheduler: TaskSchedulerManager,
    val youTubeManager: YouTubeAutomationManager
) : ViewModel() {

    val tasks: StateFlow<List<ScheduledTaskEntity>> = repository.tasksFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = emptyList()
    )

    val actionLogs: StateFlow<List<ActionLogEntity>> = repository.actionLogsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = emptyList()
    )

    private val _memorySearch = MutableStateFlow("")
    val memorySearch: StateFlow<String> = _memorySearch.asStateFlow()

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val memories: StateFlow<List<MemoryEntity>> = _memorySearch
        .flatMapLatest { q ->
            if (q.isBlank()) repository.memoriesFlow else repository.searchMemories(q)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val capturedNotifications: StateFlow<List<CapturedNotification>> = TdbNotificationListenerService.notifications
    val isNotificationListenerConnected: StateFlow<Boolean> = TdbNotificationListenerService.isConnected
    val isAccessibilityConnected: StateFlow<Boolean> = TdbAccessibilityService.isConnected
    val isFloatingOrbRunning: StateFlow<Boolean> = TdbFloatingAssistantService.isRunning
    val latestScreenCapturePath: StateFlow<String?> = TdbScreenCaptureService.latestCapturePath
    val screenCaptureStatus: StateFlow<String> = TdbScreenCaptureService.lastStatus

    private val _permissions = MutableStateFlow<List<PermissionCenterItem>>(emptyList())
    val permissions: StateFlow<List<PermissionCenterItem>> = _permissions.asStateFlow()

    private val _automationFeedback = MutableStateFlow<String?>(null)
    val automationFeedback: StateFlow<String?> = _automationFeedback.asStateFlow()

    private val _ytState = MutableStateFlow(
        YouTubeUiState(isConnected = youTubeManager.hasYouTubeOAuthToken())
    )
    val ytState: StateFlow<YouTubeUiState> = _ytState.asStateFlow()

    init {
        refreshPermissions()
    }

    fun refreshPermissions() {
        viewModelScope.launch {
            val safUri = repository.settingsFlow.first().safTreeUri
            _permissions.value = automationEngine.buildPermissionCenterItems(safUri)
        }
    }

    // --- PHONE AUTOMATION ---
    fun launchSupportedApp(target: SupportedAppTarget) {
        val res = automationEngine.launchApp(target)
        res.onSuccess { msg ->
            _automationFeedback.value = msg
            viewModelScope.launch { repository.logAction("AUTOMATION", "Launched ${target.label}", msg, "SUCCESS") }
        }.onFailure { err ->
            _automationFeedback.value = err.localizedMessage
        }
    }

    fun openCamera() {
        automationEngine.openCameraApp()
            .onSuccess { _automationFeedback.value = it }
            .onFailure { _automationFeedback.value = it.localizedMessage }
    }

    fun adjustVolume(up: Boolean) {
        _automationFeedback.value = automationEngine.adjustMediaVolume(up)
    }

    fun readCurrentLocation() {
        viewModelScope.launch {
            automationEngine.getLastKnownLocationSummary()
                .onSuccess { summary ->
                    _automationFeedback.value = summary
                    repository.logAction("AUTOMATION", "Location Read", summary, "SUCCESS")
                }
                .onFailure {
                    _automationFeedback.value = it.localizedMessage
                }
        }
    }

    fun toggleFloatingOrb(enable: Boolean) {
        if (enable) {
            automationEngine.startFloatingOrb()
                .onSuccess { _automationFeedback.value = it }
                .onFailure { _automationFeedback.value = it.localizedMessage }
        } else {
            automationEngine.stopFloatingOrb()
            _automationFeedback.value = "Floating orb stopped."
        }
    }

    fun runAccessibilityAction(action: String) {
        automationEngine.triggerAccessibilityNavigation(action)
            .onSuccess { _automationFeedback.value = it }
            .onFailure { _automationFeedback.value = it.localizedMessage }
    }

    fun inspectScreenLabels() {
        automationEngine.inspectScreenElements()
            .onSuccess { list ->
                _automationFeedback.value = if (list.isEmpty()) "No visible labels found." else "Visible UI: ${list.joinToString(" | ")}"
            }
            .onFailure { _automationFeedback.value = it.localizedMessage }
    }

    fun clearFeedback() {
        _automationFeedback.value = null
    }

    // --- AUTONOMOUS TASK SCHEDULER ---
    fun planAndScheduleTask(
        command: String,
        actionType: String,
        recurrence: String,
        delayMinutes: Long
    ) {
        if (command.isBlank()) return
        viewModelScope.launch {
            val fallbackTime = System.currentTimeMillis() + delayMinutes.coerceAtLeast(1L) * 60_000L
            val plan = taskScheduler.createIntelligentTaskPlan(command, actionType, recurrence, fallbackTime)
            val entity = ScheduledTaskEntity(
                title = plan.title,
                commandPrompt = command.trim(),
                planSummary = plan.planSummary,
                actionType = plan.actionType,
                recurrence = plan.recurrence,
                scheduledAtMs = plan.scheduledAtMs,
                status = "SCHEDULED",
                requiredPermissions = plan.requiredPermissions,
                requiredResources = plan.requiredResources
            )
            taskScheduler.scheduleTask(entity)
        }
    }

    fun runTaskNow(task: ScheduledTaskEntity) {
        taskScheduler.runTaskNow(task.id)
    }

    fun updateAndRescheduleTask(task: ScheduledTaskEntity) {
        viewModelScope.launch {
            taskScheduler.scheduleTask(task.copy(updatedAtMs = System.currentTimeMillis()))
        }
    }

    fun cancelTask(task: ScheduledTaskEntity) {
        viewModelScope.launch { taskScheduler.cancelTask(task) }
    }

    fun deleteTask(taskId: Long) {
        viewModelScope.launch { repository.deleteTask(taskId) }
    }

    // --- MEMORY VAULT ---
    fun setMemorySearch(query: String) {
        _memorySearch.value = query
    }

    fun addMemory(category: String, title: String, content: String, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val res = repository.saveMemory(category, title, content)
            onResult(res.fold(onSuccess = { "Saved to Memory Vault." }, onFailure = { it.localizedMessage ?: "Rejected." }))
        }
    }

    fun updateMemory(memory: MemoryEntity, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val res = repository.updateMemory(memory)
            onResult(res.fold(onSuccess = { "Memory updated." }, onFailure = { it.localizedMessage ?: "Rejected." }))
        }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch { repository.deleteMemory(id) }
    }

    // --- YOUTUBE AUTOMATION ---
    fun saveYouTubeClientId(clientId: String) {
        viewModelScope.launch {
            val cur = repository.settingsFlow.first()
            repository.preferences.setYouTubeConfig(clientId.trim(), cur.youtubeChannelId, cur.youtubeChannelName)
        }
    }

    fun startYouTubeOAuth(clientId: String) {
        saveYouTubeClientId(clientId)
        youTubeManager.launchOAuthPkceFlow(clientId)
            .onSuccess {
                _ytState.value = _ytState.value.copy(statusMessage = "Complete Google OAuth consent in browser...")
            }
            .onFailure { err ->
                _ytState.value = _ytState.value.copy(errorMessage = err.localizedMessage)
            }
    }

    fun handleOAuthCallback(uri: Uri) {
        viewModelScope.launch {
            _ytState.value = _ytState.value.copy(isBusy = true, errorMessage = null)
            youTubeManager.handleOAuthRedirect(uri)
                .onSuccess {
                    _ytState.value = _ytState.value.copy(isConnected = true, isBusy = false, statusMessage = "YouTube OAuth connected.")
                    fetchYouTubeChannels()
                }
                .onFailure { err ->
                    _ytState.value = _ytState.value.copy(isBusy = false, errorMessage = err.localizedMessage)
                }
        }
    }

    fun connectWithManualOAuthToken(token: String) {
        if (token.isBlank()) return
        youTubeManager.saveManualOAuthToken(token)
            .onSuccess {
                _ytState.value = _ytState.value.copy(isConnected = true, statusMessage = "OAuth token stored in Keystore.")
                fetchYouTubeChannels()
            }
            .onFailure { err ->
                _ytState.value = _ytState.value.copy(errorMessage = err.localizedMessage)
            }
    }

    fun disconnectYouTube() {
        youTubeManager.disconnectYouTube()
        viewModelScope.launch {
            val cur = repository.settingsFlow.first()
            repository.preferences.setYouTubeConfig(cur.youtubeClientId, "", "")
        }
        _ytState.value = YouTubeUiState(isConnected = false, statusMessage = "YouTube OAuth disconnected.")
    }

    fun fetchYouTubeChannels() {
        viewModelScope.launch {
            _ytState.value = _ytState.value.copy(isBusy = true, errorMessage = null)
            youTubeManager.fetchMyChannels()
                .onSuccess { list ->
                    val first = list.firstOrNull()
                    if (first != null) {
                        val cur = repository.settingsFlow.first()
                        repository.preferences.setYouTubeConfig(cur.youtubeClientId, first.id, first.title)
                    }
                    _ytState.value = _ytState.value.copy(
                        isConnected = true,
                        channels = list,
                        isBusy = false,
                        statusMessage = if (list.isEmpty()) "No channels returned for this account." else "Found ${list.size} channel(s)."
                    )
                }
                .onFailure { err ->
                    val diag = ErrorRecoveryEngine.diagnose(err, "YouTube Channels")
                    _ytState.value = _ytState.value.copy(isBusy = false, errorMessage = diag.userMessage)
                }
        }
    }

    fun selectYouTubeChannel(channel: YouTubeChannelInfo) {
        viewModelScope.launch {
            val cur = repository.settingsFlow.first()
            repository.preferences.setYouTubeConfig(cur.youtubeClientId, channel.id, channel.title)
        }
    }

    fun uploadVideoToYouTube(
        videoUri: Uri,
        title: String,
        description: String,
        tagsRaw: String,
        privacyStatus: String,
        publishAtIso: String?
    ) {
        viewModelScope.launch {
            _ytState.value = _ytState.value.copy(isBusy = true, uploadProgress = 0f, errorMessage = null, uploadResult = null)
            val tags = tagsRaw.split(",").map { it.trim() }.filter { it.isNotBlank() }
            youTubeManager.uploadVideo(
                videoUri = videoUri,
                title = title,
                description = description,
                tags = tags,
                privacyStatus = privacyStatus,
                publishAtIso8601 = publishAtIso?.takeIf { it.isNotBlank() },
                onProgress = { prog ->
                    _ytState.value = _ytState.value.copy(uploadProgress = prog)
                }
            ).onSuccess { result ->
                repository.logAction("YOUTUBE", "Video Uploaded", "${result.videoId} (${result.privacyStatus})", "SUCCESS")
                val statusCheck = youTubeManager.verifyVideoStatus(result.videoId).getOrNull()
                _ytState.value = _ytState.value.copy(
                    isBusy = false,
                    uploadProgress = 1f,
                    uploadResult = result.copy(processingStatus = statusCheck ?: result.processingStatus),
                    statusMessage = "Upload & status verification complete!"
                )
            }.onFailure { err ->
                val diag = ErrorRecoveryEngine.diagnose(err, "YouTube Upload")
                repository.logError("YOUTUBE", "YouTube Upload Failed", diag)
                _ytState.value = _ytState.value.copy(isBusy = false, errorMessage = diag.userMessage)
            }
        }
    }

    fun clearLogs() {
        viewModelScope.launch { repository.clearLogs() }
    }

    companion object {
        fun provideFactory(container: AppContainer): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                ControlViewModel(
                    container.repository,
                    container.automationEngine,
                    container.taskScheduler,
                    container.youTubeManager
                )
            }
        }
    }
}
