package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.ScreenshotMonitor
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.automation.PermissionActionType
import com.example.automation.services.TdbScreenCaptureService
import com.example.core.data.TdbSettingsState
import com.example.core.data.db.MemoryEntity
import com.example.core.data.db.ScheduledTaskEntity
import com.example.ui.components.TdbGlassCard
import com.example.ui.components.TdbGlowButton
import com.example.ui.components.TdbStatusPill
import com.example.ui.theme.CobaltBlue
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.ElectricAzure
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRose
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.ControlViewModel
import com.example.ui.viewmodel.MainAppViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ControlHubScreen(
    onNavigate: (String) -> Unit,
    bottomPadding: PaddingValues
) {
    val entries = listOf(
        Triple("Phone Automation", "App launcher, accessibility, notification reader & orb", "automation"),
        Triple("Autonomous Task Scheduler", "Plan, schedule, run now, edit & verify WorkManager jobs", "task_scheduler"),
        Triple("YouTube Automation", "OAuth 2.0 PKCE, channels & video upload studio", "youtube_automation"),
        Triple("Permission Center", "Transparent permission audit & revocation shortcuts", "permission_center"),
        Triple("TDB File Manager", "Authorized SAF folders & TDB_Workspace explorer", "file_manager"),
        Triple("Memory Vault", "Long-term preferences, context & secret guard", "memory_vault"),
        Triple("Action & Error Logs", "Transparent history with root-cause recovery tips", "error_logs")
    )
    val icons = listOf(
        Icons.Filled.PhoneAndroid,
        Icons.Filled.Schedule,
        Icons.Filled.SmartDisplay,
        Icons.Filled.Security,
        Icons.Filled.FolderOpen,
        Icons.Filled.Memory,
        Icons.Filled.BugReport
    )
    val accents = listOf(
        Color(0xFFA78BFA),
        CrimsonPrimary,
        Color(0xFFEF4444),
        StatusGreen,
        Color(0xFFFBBF24),
        ElectricAzure,
        StatusAmber
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = 16.dp,
            bottom = bottomPadding.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("TDB Control & Automation Hub", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
            Text(
                "User-consented device automation, autonomous tasks, memory & system diagnostics",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }
        items(entries.indices.toList()) { idx ->
            val (title, subtitle, route) = entries[idx]
            TdbGlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("control_hub_$route"),
                onClick = { onNavigate(route) },
                borderGlow = accents[idx]
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(accents[idx].copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(icons[idx], contentDescription = title, tint = accents[idx])
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                    }
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = TextSecondary)
                }
            }
        }
    }
}

@Composable
fun AutomationScreen(
    controlViewModel: ControlViewModel,
    onBack: () -> Unit,
    onOpenPermissions: () -> Unit,
    bottomPadding: PaddingValues
) {
    val context = LocalContext.current
    val isAccessibility by controlViewModel.isAccessibilityConnected.collectAsStateWithLifecycle()
    val isNotifListener by controlViewModel.isNotificationListenerConnected.collectAsStateWithLifecycle()
    val isOrbRunning by controlViewModel.isFloatingOrbRunning.collectAsStateWithLifecycle()
    val notifications by controlViewModel.capturedNotifications.collectAsStateWithLifecycle()
    val latestCapture by controlViewModel.latestScreenCapturePath.collectAsStateWithLifecycle()
    val captureStatus by controlViewModel.screenCaptureStatus.collectAsStateWithLifecycle()
    val feedback by controlViewModel.automationFeedback.collectAsStateWithLifecycle()

    val locationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.values.any { it }) {
            controlViewModel.readCurrentLocation()
        }
        controlViewModel.refreshPermissions()
    }

    val mediaProjectionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val svcIntent = Intent(context, TdbScreenCaptureService::class.java).apply {
                putExtra(TdbScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(TdbScreenCaptureService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(context, svcIntent)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = 12.dp,
            bottom = bottomPadding.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { ScreenBackHeader("Phone Automation", onBack) }

        if (!feedback.isNullOrBlank()) {
            item {
                TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = ElectricAzure) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(feedback.orEmpty(), style = MaterialTheme.typography.bodyMedium, color = TextPrimary, modifier = Modifier.weight(1f))
                        TextButton(onClick = { controlViewModel.clearFeedback() }) {
                            Text("OK", color = ElectricAzure)
                        }
                    }
                }
            }
        }

        // App Launcher
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Quick App Launcher", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                        TextButton(onClick = onOpenPermissions) {
                            Text("Permissions", color = ElectricAzure)
                        }
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(controlViewModel.automationEngine.supportedApps, key = { it.packageName }) { app ->
                            OutlinedButton(
                                onClick = { controlViewModel.launchSupportedApp(app) },
                                modifier = Modifier.testTag("launch_${app.label.lowercase()}")
                            ) {
                                Icon(Icons.Filled.Launch, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(app.label)
                            }
                        }
                    }
                }
            }
        }

        // Hardware Controls: Camera, Location, Volume, Floating Orb
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Device Actions & Sensors", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { controlViewModel.openCamera() }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Camera")
                        }
                        OutlinedButton(
                            onClick = {
                                val fine = controlViewModel.automationEngine.hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                                val coarse = controlViewModel.automationEngine.hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                                if (fine || coarse) {
                                    controlViewModel.readCurrentLocation()
                                } else {
                                    locationLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.LocationOn, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Location")
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { controlViewModel.adjustVolume(false) }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.VolumeDown, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Vol -")
                        }
                        OutlinedButton(onClick = { controlViewModel.adjustVolume(true) }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.VolumeUp, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Vol +")
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Floating Assistant Orb", style = MaterialTheme.typography.labelLarge, color = TextPrimary)
                            Text("Visible overlay bubble when Overlay permission is granted", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                        Switch(
                            checked = isOrbRunning,
                            onCheckedChange = { controlViewModel.toggleFloatingOrb(it) },
                            modifier = Modifier.testTag("floating_orb_switch")
                        )
                    }
                }
            }
        }

        // Accessibility Service Controls
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = if (isAccessibility) StatusGreen else StatusAmber) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Accessibility Automation", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                        TdbStatusPill(
                            label = if (isAccessibility) "Active" else "Not Enabled",
                            dotColor = if (isAccessibility) StatusGreen else StatusAmber
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { controlViewModel.runAccessibilityAction("HOME") }, modifier = Modifier.weight(1f)) { Text("Home") }
                        OutlinedButton(onClick = { controlViewModel.runAccessibilityAction("BACK") }, modifier = Modifier.weight(1f)) { Text("Back") }
                        OutlinedButton(onClick = { controlViewModel.runAccessibilityAction("RECENTS") }, modifier = Modifier.weight(1f)) { Text("Recents") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { controlViewModel.inspectScreenLabels() }, modifier = Modifier.weight(1f)) {
                            Text("Inspect UI Labels")
                        }
                        if (!isAccessibility) {
                            OutlinedButton(
                                onClick = { controlViewModel.automationEngine.openSystemSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Enable")
                            }
                        }
                    }
                }
            }
        }

        // One-Shot User-Consented Screen Capture
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = CrimsonPrimary) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("One-Shot Screen Capture (Consent Required)", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Text(captureStatus, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    TdbGlowButton(
                        text = "Capture 1 Screen Frame",
                        onClick = {
                            val mgr = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                            mediaProjectionLauncher.launch(mgr.createScreenCaptureIntent())
                        },
                        icon = Icons.Filled.ScreenshotMonitor,
                        testTag = "one_shot_capture_btn",
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (!latestCapture.isNullOrBlank()) {
                        val bmp = remember(latestCapture) {
                            runCatching { android.graphics.BitmapFactory.decodeFile(latestCapture) }.getOrNull()
                        }
                        if (bmp != null) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "Latest captured screen frame",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(180.dp)
                                    .clip(RoundedCornerShape(14.dp))
                            )
                        }
                    }
                }
            }
        }

        // Notification Reader
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Notification Reader", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                        TdbStatusPill(
                            label = if (isNotifListener) "Connected" else "Enable Access",
                            dotColor = if (isNotifListener) StatusGreen else StatusAmber,
                            modifier = Modifier.clickable {
                                controlViewModel.automationEngine.openSystemSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                            }
                        )
                    }
                    if (notifications.isEmpty()) {
                        Text(
                            "No captured notifications yet. Enable Notification Reader in Permission Center to read incoming alerts on demand.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    } else {
                        notifications.take(5).forEach { notif ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(alpha = 0.05f))
                                    .padding(10.dp)
                            ) {
                                Text("${notif.packageName}: ${notif.title}", style = MaterialTheme.typography.labelLarge, color = ElectricAzure)
                                Text(notif.text, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PermissionCenterScreen(
    controlViewModel: ControlViewModel,
    studioViewModel: com.example.ui.viewmodel.StudioViewModel,
    onBack: () -> Unit,
    bottomPadding: PaddingValues
) {
    val permissions by controlViewModel.permissions.collectAsStateWithLifecycle()

    val singlePermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { controlViewModel.refreshPermissions() }

    val multiPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { controlViewModel.refreshPermissions() }

    val safLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            studioViewModel.saveSafTreeUri(uri.toString())
            controlViewModel.refreshPermissions()
        }
    }

    LaunchedEffect(Unit) {
        controlViewModel.refreshPermissions()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = 12.dp,
            bottom = bottomPadding.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenBackHeader("Permission Center", onBack) }

        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = ElectricAzure) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Least-privilege access: nothing runs hidden. Review or revoke any capability anytime.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { controlViewModel.refreshPermissions() }) {
                        Text("Refresh", color = ElectricAzure)
                    }
                }
            }
        }

        items(permissions, key = { it.id }) { item ->
            TdbGlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("perm_card_${item.id}"),
                borderGlow = if (item.isGranted) StatusGreen else StatusAmber
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(item.name, style = MaterialTheme.typography.titleMedium, color = TextPrimary, modifier = Modifier.weight(1f))
                        TdbStatusPill(
                            label = if (item.isGranted) "Granted" else "Not Granted",
                            dotColor = if (item.isGranted) StatusGreen else StatusAmber
                        )
                    }
                    Text(item.whyNeeded, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Text("Revoke: ${item.revokeInstructions}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    OutlinedButton(
                        onClick = {
                            when (item.actionType) {
                                PermissionActionType.RUNTIME_MICROPHONE -> singlePermLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                PermissionActionType.RUNTIME_CAMERA -> singlePermLauncher.launch(Manifest.permission.CAMERA)
                                PermissionActionType.RUNTIME_LOCATION -> multiPermLauncher.launch(
                                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                                )
                                PermissionActionType.RUNTIME_NOTIFICATIONS -> {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        singlePermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    } else {
                                        controlViewModel.automationEngine.openSystemSettings(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                                    }
                                }
                                PermissionActionType.SYSTEM_ACCESSIBILITY ->
                                    controlViewModel.automationEngine.openSystemSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                PermissionActionType.SYSTEM_NOTIFICATION_LISTENER ->
                                    controlViewModel.automationEngine.openSystemSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                                PermissionActionType.SYSTEM_OVERLAY ->
                                    controlViewModel.automationEngine.openSystemSettings(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                                PermissionActionType.SAF_DIRECTORY -> safLauncher.launch(null)
                                PermissionActionType.SYSTEM_EXACT_ALARM -> {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                        controlViewModel.automationEngine.openSystemSettings(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                                    } else {
                                        controlViewModel.automationEngine.openSystemSettings(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                                    }
                                }
                            }
                        },
                        modifier = Modifier.testTag("perm_btn_${item.id}")
                    ) {
                        Text(if (item.isGranted) "Manage / Review" else "Grant Access")
                    }
                }
            }
        }
    }
}

@Composable
fun TaskSchedulerScreen(
    controlViewModel: ControlViewModel,
    onBack: () -> Unit,
    bottomPadding: PaddingValues
) {
    val tasks by controlViewModel.tasks.collectAsStateWithLifecycle()
    val dateFmt = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }

    var command by remember { mutableStateOf("") }
    val actionTypes = listOf("AI_BRIEFING", "YOUTUBE_PREP", "FILE_OPERATION", "REMINDER", "AUTOMATION_CHECK")
    val recurrences = listOf("ONCE", "DAILY", "WEEKLY")
    var selectedAction by remember { mutableStateOf("AI_BRIEFING") }
    var selectedRecurrence by remember { mutableStateOf("ONCE") }
    var delayMinutesText by remember { mutableStateOf("15") }
    var editingTask by remember { mutableStateOf<ScheduledTaskEntity?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = 12.dp,
            bottom = bottomPadding.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { ScreenBackHeader("Autonomous Task Scheduler", onBack) }

        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = ElectricAzure) {
                Text(
                    "Powered by WorkManager: tasks run automatically in the background while Android is powered on, subject to Doze & OEM battery settings.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }

        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = CrimsonPrimary) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Plan & Schedule Autonomous Task", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    OutlinedTextField(
                        value = command,
                        onValueChange = { command = it },
                        label = { Text("Task Instruction (e.g. Daily morning Bengali vlog ideas)") },
                        modifier = Modifier.fillMaxWidth().testTag("task_command_input"),
                        colors = darkFieldColors()
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(actionTypes) { t ->
                            FilterChip(selected = selectedAction == t, onClick = { selectedAction = t }, label = { Text(t) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        recurrences.forEach { rec ->
                            FilterChip(selected = selectedRecurrence == rec, onClick = { selectedRecurrence = rec }, label = { Text(rec) })
                        }
                    }
                    OutlinedTextField(
                        value = delayMinutesText,
                        onValueChange = { delayMinutesText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Run after (minutes)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = darkFieldColors()
                    )
                    TdbGlowButton(
                        text = "Analyze Plan & Schedule",
                        onClick = {
                            val mins = delayMinutesText.toLongOrNull() ?: 15L
                            controlViewModel.planAndScheduleTask(command, selectedAction, selectedRecurrence, mins)
                            command = ""
                        },
                        enabled = command.isNotBlank(),
                        icon = Icons.Filled.Schedule,
                        testTag = "task_schedule_btn",
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        if (tasks.isEmpty()) {
            item {
                TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("No scheduled tasks yet. Create your first autonomous workflow above.", color = TextSecondary)
                }
            }
        } else {
            items(tasks, key = { it.id }) { task ->
                val statusColor = when (task.status) {
                    "VERIFIED_SUCCESS" -> StatusGreen
                    "FAILED" -> StatusRose
                    "CANCELLED" -> TextMuted
                    else -> ElectricAzure
                }
                TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = statusColor) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(task.title, style = MaterialTheme.typography.titleMedium, color = TextPrimary, modifier = Modifier.weight(1f))
                            TdbStatusPill(label = task.status, dotColor = statusColor)
                        }
                        Text(task.planSummary, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        Text(
                            "${task.actionType} • ${task.recurrence} • ${dateFmt.format(Date(task.scheduledAtMs))}",
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricAzure
                        )
                        Text("Requires: ${task.requiredPermissions} | ${task.requiredResources}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        if (!task.lastResult.isNullOrBlank()) {
                            Text("Result: ${task.lastResult}", style = MaterialTheme.typography.bodySmall, color = StatusGreen)
                        }
                        if (!task.lastError.isNullOrBlank()) {
                            Text("Issue: ${task.lastError}", style = MaterialTheme.typography.bodySmall, color = StatusRose)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { controlViewModel.runTaskNow(task) }, modifier = Modifier.testTag("task_run_${task.id}")) {
                                Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Run Now")
                            }
                            OutlinedButton(onClick = { editingTask = task }) {
                                Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Edit")
                            }
                            IconButton(onClick = { controlViewModel.cancelTask(task) }) {
                                Icon(Icons.Filled.Cancel, contentDescription = "Cancel Task", tint = StatusAmber)
                            }
                            IconButton(onClick = { controlViewModel.deleteTask(task.id) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Delete Task", tint = StatusRose)
                            }
                        }
                    }
                }
            }
        }
    }

    editingTask?.let { target ->
        var editTitle by remember(target.id) { mutableStateOf(target.title) }
        var editPrompt by remember(target.id) { mutableStateOf(target.commandPrompt) }
        var editRecurrence by remember(target.id) { mutableStateOf(target.recurrence) }
        var editDelayMins by remember(target.id) { mutableStateOf("15") }

        AlertDialog(
            onDismissRequest = { editingTask = null },
            containerColor = Color(0xFF10172B),
            title = { Text("Edit Scheduled Task", color = TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = editTitle, onValueChange = { editTitle = it }, label = { Text("Title") }, colors = darkFieldColors())
                    OutlinedTextField(value = editPrompt, onValueChange = { editPrompt = it }, label = { Text("Instruction") }, colors = darkFieldColors())
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        recurrences.forEach { rec ->
                            FilterChip(selected = editRecurrence == rec, onClick = { editRecurrence = rec }, label = { Text(rec) })
                        }
                    }
                    OutlinedTextField(
                        value = editDelayMins,
                        onValueChange = { editDelayMins = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Reschedule in minutes") },
                        colors = darkFieldColors()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val mins = editDelayMins.toLongOrNull() ?: 15L
                    controlViewModel.updateAndRescheduleTask(
                        target.copy(
                            title = editTitle,
                            commandPrompt = editPrompt,
                            recurrence = editRecurrence,
                            scheduledAtMs = System.currentTimeMillis() + mins.coerceAtLeast(1L) * 60_000L,
                            status = "SCHEDULED"
                        )
                    )
                    editingTask = null
                }) { Text("Save & Reschedule", color = ElectricAzure) }
            },
            dismissButton = {
                TextButton(onClick = { editingTask = null }) { Text("Cancel", color = TextSecondary) }
            }
        )
    }
}

@Composable
fun YouTubeAutomationScreen(
    controlViewModel: ControlViewModel,
    settings: TdbSettingsState,
    initialTopic: String = "",
    onBack: () -> Unit,
    bottomPadding: PaddingValues
) {
    val ytState by controlViewModel.ytState.collectAsStateWithLifecycle()
    var clientIdInput by remember(settings.youtubeClientId) { mutableStateOf(settings.youtubeClientId) }
    var manualTokenInput by remember { mutableStateOf("") }
    var selectedVideoUri by remember { mutableStateOf<Uri?>(null) }
    var title by remember(initialTopic) { mutableStateOf(initialTopic) }
    var description by remember { mutableStateOf("Uploaded with TDB Personal AI Assistant • Deep Barmon Bhai Vlog") }
    var tags by remember { mutableStateOf("Deep Barmon Bhai Vlog, Bengali Vlog, TDB") }
    var privacyStatus by remember { mutableStateOf("private") }
    var publishAtIso by remember { mutableStateOf("") }
    var showConfirmUploadDialog by remember { mutableStateOf(false) }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) selectedVideoUri = uri
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = 12.dp,
            bottom = bottomPadding.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { ScreenBackHeader("YouTube Automation", onBack) }

        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = StatusAmber) {
                Text(
                    "Official Google OAuth 2.0 + YouTube Data API v3. Note: A Gemini API key alone never authorizes YouTube uploads — explicit Google OAuth consent is required.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }

        // OAuth Connection Card
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = if (ytState.isConnected) StatusGreen else CrimsonPrimary) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("YouTube Account Connection", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                        TdbStatusPill(
                            label = if (ytState.isConnected) "OAuth Connected" else "Disconnected",
                            dotColor = if (ytState.isConnected) StatusGreen else StatusRose
                        )
                    }
                    OutlinedTextField(
                        value = clientIdInput,
                        onValueChange = { clientIdInput = it },
                        label = { Text("Google OAuth 2.0 Android/Installed Client ID") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("yt_client_id_input"),
                        colors = darkFieldColors()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        TdbGlowButton(
                            text = "Connect via Google OAuth",
                            onClick = { controlViewModel.startYouTubeOAuth(clientIdInput) },
                            enabled = clientIdInput.isNotBlank() && !ytState.isBusy,
                            testTag = "yt_oauth_connect_btn",
                            modifier = Modifier.weight(1f)
                        )
                        if (ytState.isConnected) {
                            OutlinedButton(onClick = { controlViewModel.disconnectYouTube() }) {
                                Text("Disconnect", color = StatusRose)
                            }
                        }
                    }
                    OutlinedTextField(
                        value = manualTokenInput,
                        onValueChange = { manualTokenInput = it },
                        label = { Text("Or paste OAuth 2.0 Bearer Access Token (testing)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = darkFieldColors()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                controlViewModel.connectWithManualOAuthToken(manualTokenInput)
                                manualTokenInput = ""
                            },
                            enabled = manualTokenInput.isNotBlank()
                        ) { Text("Save OAuth Token") }
                        if (ytState.isConnected) {
                            OutlinedButton(onClick = { controlViewModel.fetchYouTubeChannels() }) {
                                Text("Fetch Channels")
                            }
                        }
                    }

                    if (settings.youtubeChannelName.isNotBlank()) {
                        Text("Active Channel: ${settings.youtubeChannelName}", style = MaterialTheme.typography.labelLarge, color = StatusGreen)
                    }
                    if (ytState.channels.isNotEmpty()) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(ytState.channels, key = { it.id }) { ch ->
                                FilterChip(
                                    selected = settings.youtubeChannelId == ch.id,
                                    onClick = { controlViewModel.selectYouTubeChannel(ch) },
                                    label = { Text("${ch.title} (${ch.subscriberCount} subs)") }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Video Upload Card
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Upload Video via Data API v3", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    OutlinedButton(
                        onClick = { videoPickerLauncher.launch("video/*") },
                        modifier = Modifier.fillMaxWidth().testTag("yt_pick_video_btn")
                    ) {
                        Icon(Icons.Filled.Upload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(if (selectedVideoUri != null) "Selected: ${selectedVideoUri?.lastPathSegment}" else "Select Video File")
                    }
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Video Title") }, modifier = Modifier.fillMaxWidth(), colors = darkFieldColors())
                    OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Description") }, minLines = 3, modifier = Modifier.fillMaxWidth(), colors = darkFieldColors())
                    OutlinedTextField(value = tags, onValueChange = { tags = it }, label = { Text("Tags (comma separated)") }, modifier = Modifier.fillMaxWidth(), colors = darkFieldColors())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("private", "unlisted", "public").forEach { mode ->
                            FilterChip(selected = privacyStatus == mode, onClick = { privacyStatus = mode }, label = { Text(mode.replaceFirstChar { it.uppercase() }) })
                        }
                    }
                    if (privacyStatus == "private") {
                        OutlinedTextField(
                            value = publishAtIso,
                            onValueChange = { publishAtIso = it },
                            label = { Text("Optional Scheduled Publish (ISO-8601 e.g. 2026-12-01T14:00:00Z)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = darkFieldColors()
                        )
                    }
                    if (ytState.isBusy && ytState.uploadProgress > 0f) {
                        LinearProgressIndicator(progress = { ytState.uploadProgress }, modifier = Modifier.fillMaxWidth())
                    }
                    TdbGlowButton(
                        text = if (ytState.isBusy) "Uploading ${(ytState.uploadProgress * 100).toInt()}%..." else "Review & Upload to YouTube",
                        onClick = { showConfirmUploadDialog = true },
                        enabled = ytState.isConnected && selectedVideoUri != null && title.isNotBlank() && !ytState.isBusy,
                        icon = Icons.Filled.SmartDisplay,
                        testTag = "yt_upload_btn",
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        if (!ytState.statusMessage.isNullOrBlank()) {
            item {
                TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = StatusGreen) {
                    Text(ytState.statusMessage.orEmpty(), color = StatusGreen)
                }
            }
        }
        if (!ytState.errorMessage.isNullOrBlank()) {
            item {
                TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = StatusRose) {
                    Text(ytState.errorMessage.orEmpty(), color = StatusRose)
                }
            }
        }
        ytState.uploadResult?.let { res ->
            item {
                TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = ElectricAzure) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Verified YouTube Upload", style = MaterialTheme.typography.titleMedium, color = ElectricAzure)
                        Text("Video ID: ${res.videoId}", color = TextPrimary)
                        Text("Privacy: ${res.privacyStatus} • Processing: ${res.processingStatus}", color = TextSecondary)
                        Text(res.watchUrl, color = ElectricAzure, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    if (showConfirmUploadDialog && selectedVideoUri != null) {
        AlertDialog(
            onDismissRequest = { showConfirmUploadDialog = false },
            containerColor = Color(0xFF10172B),
            title = { Text("Confirm YouTube Upload", color = TextPrimary) },
            text = {
                Text(
                    "Publish \"$title\" to ${settings.youtubeChannelName.ifBlank { "your authorized YouTube channel" }} as $privacyStatus?",
                    color = TextSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showConfirmUploadDialog = false
                    selectedVideoUri?.let { uri ->
                        controlViewModel.uploadVideoToYouTube(uri, title, description, tags, privacyStatus, publishAtIso)
                    }
                }) { Text("Confirm Upload", color = CrimsonPrimary) }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmUploadDialog = false }) { Text("Cancel", color = TextSecondary) }
            }
        )
    }
}

@Composable
fun MemoryVaultScreen(
    controlViewModel: ControlViewModel,
    mainAppViewModel: MainAppViewModel,
    settings: TdbSettingsState,
    onBack: () -> Unit,
    bottomPadding: PaddingValues
) {
    val memories by controlViewModel.memories.collectAsStateWithLifecycle()
    val search by controlViewModel.memorySearch.collectAsStateWithLifecycle()

    var showAddDialog by remember { mutableStateOf(false) }
    var editingMemory by remember { mutableStateOf<MemoryEntity?>(null) }
    var feedback by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = 12.dp,
            bottom = bottomPadding.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenBackHeader("TDB Memory Vault", onBack) }

        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Long-Term Memory Active", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                            Text("Secret Guard automatically blocks API keys, passwords, and OAuth tokens.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                        Switch(
                            checked = settings.memoryEnabled,
                            onCheckedChange = { mainAppViewModel.setMemoryEnabled(it) },
                            modifier = Modifier.testTag("memory_enabled_switch")
                        )
                    }
                    OutlinedTextField(
                        value = search,
                        onValueChange = { controlViewModel.setMemorySearch(it) },
                        label = { Text("Search saved memories...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = darkFieldColors()
                    )
                    TdbGlowButton(
                        text = "Add Memory Entry",
                        onClick = { showAddDialog = true },
                        icon = Icons.Filled.Add,
                        testTag = "memory_add_btn",
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        if (!feedback.isNullOrBlank()) {
            item {
                TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = ElectricAzure) {
                    Text(feedback.orEmpty(), color = TextPrimary)
                }
            }
        }

        if (memories.isEmpty()) {
            item {
                TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("No saved memories matching your query yet.", color = TextSecondary)
                }
            }
        } else {
            items(memories, key = { it.id }) { mem ->
                TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${mem.category} • ${mem.title}", style = MaterialTheme.typography.titleMedium, color = ElectricAzure)
                            Spacer(Modifier.height(4.dp))
                            Text(mem.content, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                        }
                        Row {
                            IconButton(onClick = { editingMemory = mem }) {
                                Icon(Icons.Filled.Edit, contentDescription = "Edit Memory", tint = TextSecondary)
                            }
                            IconButton(onClick = { controlViewModel.deleteMemory(mem.id) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Delete Memory", tint = StatusRose)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        MemoryEditorDialog(
            initialCategory = "PREFERENCE",
            initialTitle = "",
            initialContent = "",
            dialogTitle = "Add to Memory Vault",
            onDismiss = { showAddDialog = false },
            onSave = { cat, t, c ->
                controlViewModel.addMemory(cat, t, c) { feedback = it }
                showAddDialog = false
            }
        )
    }

    editingMemory?.let { mem ->
        MemoryEditorDialog(
            initialCategory = mem.category,
            initialTitle = mem.title,
            initialContent = mem.content,
            dialogTitle = "Edit Memory",
            onDismiss = { editingMemory = null },
            onSave = { cat, t, c ->
                controlViewModel.updateMemory(mem.copy(category = cat, title = t, content = c)) { feedback = it }
                editingMemory = null
            }
        )
    }
}

@Composable
private fun MemoryEditorDialog(
    initialCategory: String,
    initialTitle: String,
    initialContent: String,
    dialogTitle: String,
    onDismiss: () -> Unit,
    onSave: (String, String, String) -> Unit
) {
    val cats = listOf("PREFERENCE", "PROJECT", "TASK", "INSTRUCTION", "CONTEXT")
    var category by remember { mutableStateOf(initialCategory) }
    var title by remember { mutableStateOf(initialTitle) }
    var content by remember { mutableStateOf(initialContent) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF10172B),
        title = { Text(dialogTitle, color = TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(cats) { cat ->
                        FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat) })
                    }
                }
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, colors = darkFieldColors())
                OutlinedTextField(value = content, onValueChange = { content = it }, label = { Text("Memory Detail") }, minLines = 3, colors = darkFieldColors())
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(category, title, content) }, enabled = title.isNotBlank() && content.isNotBlank()) {
                Text("Save", color = ElectricAzure)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = TextSecondary) }
        }
    )
}

@Composable
fun ErrorLogsScreen(
    controlViewModel: ControlViewModel,
    onBack: () -> Unit,
    bottomPadding: PaddingValues
) {
    val logs by controlViewModel.actionLogs.collectAsStateWithLifecycle()
    val dateFmt = remember { SimpleDateFormat("dd MMM HH:mm:ss", Locale.getDefault()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = 12.dp,
            bottom = bottomPadding.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                ScreenBackHeader("Action & Error Logs", onBack)
                if (logs.isNotEmpty()) {
                    TextButton(onClick = { controlViewModel.clearLogs() }) {
                        Text("Clear", color = StatusRose)
                    }
                }
            }
        }

        if (logs.isEmpty()) {
            item {
                TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("No action or error logs recorded yet.", color = TextSecondary)
                }
            }
        } else {
            items(logs, key = { it.id }) { log ->
                val accent = when (log.status) {
                    "ERROR" -> StatusRose
                    "WARNING" -> StatusAmber
                    else -> StatusGreen
                }
                TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = accent) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("[${log.category}] ${log.title}", style = MaterialTheme.typography.titleSmall, color = accent, modifier = Modifier.weight(1f))
                            Text(dateFmt.format(Date(log.timestampMs)), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                        Text(log.details, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                        if (!log.errorCause.isNullOrBlank()) {
                            Text("Cause: ${log.errorCause}", style = MaterialTheme.typography.labelSmall, color = StatusAmber)
                        }
                        if (!log.recoverySuggestion.isNullOrBlank()) {
                            Text("Recovery: ${log.recoverySuggestion}", style = MaterialTheme.typography.labelSmall, color = ElectricAzure)
                        }
                    }
                }
            }
        }
    }
}
