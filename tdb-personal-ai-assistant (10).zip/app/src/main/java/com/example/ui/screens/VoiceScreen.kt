package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.data.AppLanguage
import com.example.core.data.TdbSettingsState
import com.example.core.data.VoiceGenderOption
import com.example.ui.components.TdbAnimatedAiOrb
import com.example.ui.components.TdbGlassCard
import com.example.ui.components.TdbStatusPill
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.ElectricAzure
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRose
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.VoiceViewModel
import com.example.voice.VoiceOrbState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceScreen(
    voiceViewModel: VoiceViewModel,
    settings: TdbSettingsState,
    onBack: () -> Unit,
    onOpenChat: () -> Unit,
    bottomPadding: PaddingValues
) {
    val context = LocalContext.current
    val orbState by voiceViewModel.orbState.collectAsStateWithLifecycle()
    val partial by voiceViewModel.partialTranscript.collectAsStateWithLifecycle()
    val rmsLevel by voiceViewModel.rmsLevel.collectAsStateWithLifecycle()
    val uiState by voiceViewModel.uiState.collectAsStateWithLifecycle()
    val isWakeRunning by voiceViewModel.isWakeServiceRunning.collectAsStateWithLifecycle()
    val availableVoices by voiceViewModel.availableVoices.collectAsStateWithLifecycle()

    var showVoiceSettingsSheet by remember { mutableStateOf(false) }

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMicPermission = granted
        if (granted) {
            voiceViewModel.toggleVoiceInteraction(true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(
                start = 20.dp,
                end = 20.dp,
                top = 12.dp,
                bottom = bottomPadding.calculateBottomPadding() + 18.dp
            ),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Bar (matches right screen of reference mockup)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.12f))
                    .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape)
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Talk with TDB", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
                Text(
                    text = "${settings.primaryLanguage.nativeLabel} • Wake: \"${settings.wakePhrase}\"",
                    style = MaterialTheme.typography.labelSmall,
                    color = ElectricAzure
                )
            }
            IconButton(
                onClick = { showVoiceSettingsSheet = true },
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.12f))
                    .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape)
                    .testTag("voice_settings_btn")
            ) {
                Icon(Icons.Filled.Tune, contentDescription = "Voice Settings", tint = Color.White)
            }
        }

        // Animated 3D Plasma AI Orb
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.Center
        ) {
            TdbAnimatedAiOrb(
                orbState = orbState,
                rmsLevel = rmsLevel,
                size = 230.dp
            )
            Spacer(Modifier.height(16.dp))
            if (isWakeRunning) {
                TdbStatusPill(label = "Wake Service Active (${settings.wakePhrase})", dotColor = StatusGreen)
                Spacer(Modifier.height(10.dp))
            }
            Text(
                text = if (partial.isNotBlank() && orbState == VoiceOrbState.LISTENING) "\"$partial\""
                else "\"${uiState.assistantSpeechText}\"",
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 8.dp)
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = when (orbState) {
                    VoiceOrbState.LISTENING -> "listening..."
                    VoiceOrbState.THINKING -> "thinking..."
                    VoiceOrbState.SPEAKING -> "speaking..."
                    VoiceOrbState.IDLE -> uiState.statusText
                },
                style = MaterialTheme.typography.bodyMedium,
                color = if (uiState.errorText != null) StatusRose else TextSecondary
            )
            if (!uiState.errorText.isNullOrBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    text = uiState.errorText.orEmpty(),
                    style = MaterialTheme.typography.bodySmall,
                    color = StatusRose,
                    textAlign = TextAlign.Center
                )
            }
        }

        // Bottom 3-button dock (exact homage to reference right screen)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onOpenChat,
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.14f))
                    .border(1.dp, Color.White.copy(alpha = 0.24f), CircleShape)
                    .testTag("voice_to_chat_btn")
            ) {
                Icon(Icons.Filled.ChatBubble, contentDescription = "Open Text Chat", tint = Color.White)
            }

            Box(
                modifier = Modifier
                    .size(84.dp)
                    .shadow(16.dp, CircleShape, ambientColor = CrimsonPrimary, spotColor = CrimsonPrimary)
                    .clip(CircleShape)
                    .background(
                        if (orbState == VoiceOrbState.IDLE) CrimsonPrimary else Color(0xFFFF2436)
                    )
                    .border(3.dp, Color.White.copy(alpha = 0.45f), CircleShape)
                    .clickable {
                        if (hasMicPermission) {
                            voiceViewModel.toggleVoiceInteraction(true)
                        } else {
                            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }
                    .testTag("voice_mic_btn"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (orbState == VoiceOrbState.SPEAKING || orbState == VoiceOrbState.LISTENING) {
                        Icons.Filled.Stop
                    } else {
                        Icons.Filled.Mic
                    },
                    contentDescription = "Activate or Interrupt Voice",
                    tint = Color.White,
                    modifier = Modifier.size(34.dp)
                )
            }

            IconButton(
                onClick = { voiceViewModel.stopSpeaking() },
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.14f))
                    .border(1.dp, Color.White.copy(alpha = 0.24f), CircleShape)
                    .testTag("voice_stop_btn")
            ) {
                Icon(Icons.Filled.Close, contentDescription = "Stop Speaking", tint = Color.White)
            }
        }
    }

    if (showVoiceSettingsSheet) {
        ModalBottomSheet(
            onDismissRequest = { showVoiceSettingsSheet = false },
            containerColor = Color(0xFF0E1426)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("Voice Assistant Controls", style = MaterialTheme.typography.titleLarge, color = TextPrimary)

                Text("Language", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppLanguage.entries.forEach { lang ->
                        FilterChip(
                            selected = settings.primaryLanguage == lang,
                            onClick = {
                                voiceViewModel.updateVoicePreferences(
                                    settings.voiceSpeed, settings.voiceGender, settings.wakePhrase,
                                    settings.continuousVoice, settings.backgroundWakeEnabled, lang
                                )
                            },
                            label = { Text(lang.nativeLabel) }
                        )
                    }
                }

                Text("Speaking Speed: ${"%.1fx".format(settings.voiceSpeed)}", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                Slider(
                    value = settings.voiceSpeed,
                    onValueChange = { spd ->
                        voiceViewModel.updateVoicePreferences(
                            spd, settings.voiceGender, settings.wakePhrase,
                            settings.continuousVoice, settings.backgroundWakeEnabled, settings.primaryLanguage
                        )
                    },
                    valueRange = 0.6f..1.8f
                )

                Text("Voice Option", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    VoiceGenderOption.entries.forEach { opt ->
                        FilterChip(
                            selected = settings.voiceGender == opt,
                            onClick = {
                                voiceViewModel.updateVoicePreferences(
                                    settings.voiceSpeed, opt, settings.wakePhrase,
                                    settings.continuousVoice, settings.backgroundWakeEnabled, settings.primaryLanguage
                                )
                            },
                            label = { Text(opt.label) }
                        )
                    }
                }

                Text("Wake Phrase", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    voiceViewModel.wakePhraseOptions.take(2).forEach { phrase ->
                        FilterChip(
                            selected = settings.wakePhrase == phrase,
                            onClick = {
                                voiceViewModel.updateVoicePreferences(
                                    settings.voiceSpeed, settings.voiceGender, phrase,
                                    settings.continuousVoice, settings.backgroundWakeEnabled, settings.primaryLanguage
                                )
                            },
                            label = { Text(phrase) }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    voiceViewModel.wakePhraseOptions.drop(2).forEach { phrase ->
                        FilterChip(
                            selected = settings.wakePhrase == phrase,
                            onClick = {
                                voiceViewModel.updateVoicePreferences(
                                    settings.voiceSpeed, settings.voiceGender, phrase,
                                    settings.continuousVoice, settings.backgroundWakeEnabled, settings.primaryLanguage
                                )
                            },
                            label = { Text(phrase) }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Continuous Conversation", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                        Text("Automatically listen again after TDB finishes speaking", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    Switch(
                        checked = settings.continuousVoice,
                        onCheckedChange = { cont ->
                            voiceViewModel.updateVoicePreferences(
                                settings.voiceSpeed, settings.voiceGender, settings.wakePhrase,
                                cont, settings.backgroundWakeEnabled, settings.primaryLanguage
                            )
                        }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Visible Foreground Wake Service", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                        Text("Shows an active microphone notification while listening for \"${settings.wakePhrase}\"", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    Switch(
                        checked = settings.backgroundWakeEnabled,
                        onCheckedChange = { bg ->
                            if (bg && !hasMicPermission) {
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            } else {
                                voiceViewModel.updateVoicePreferences(
                                    settings.voiceSpeed, settings.voiceGender, settings.wakePhrase,
                                    settings.continuousVoice, bg, settings.primaryLanguage
                                )
                            }
                        }
                    )
                }

                if (availableVoices.isNotEmpty()) {
                    TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                        Column {
                            Text("Detected System TTS Voices", style = MaterialTheme.typography.labelSmall, color = ElectricAzure)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = availableVoices.take(4).joinToString("\n"),
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}
