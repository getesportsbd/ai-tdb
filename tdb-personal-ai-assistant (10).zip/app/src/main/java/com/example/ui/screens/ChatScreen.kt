package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.data.AppLanguage
import com.example.core.data.TdbSettingsState
import com.example.core.data.db.ChatMessageEntity
import com.example.ui.components.TdbGlassCard
import com.example.ui.components.TdbStatusPill
import com.example.ui.theme.CobaltBlue
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.ElectricAzure
import com.example.ui.theme.StatusRose
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.ChatViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    chatViewModel: ChatViewModel,
    settings: TdbSettingsState,
    onLanguageChange: (AppLanguage) -> Unit,
    onOpenApiManagement: () -> Unit,
    bottomPadding: PaddingValues
) {
    val context = LocalContext.current
    val uiState by chatViewModel.uiState.collectAsStateWithLifecycle()
    val messages by chatViewModel.activeMessages.collectAsStateWithLifecycle()
    val sessions by chatViewModel.sessions.collectAsStateWithLifecycle()
    val searchResults by chatViewModel.searchResults.collectAsStateWithLifecycle()

    var inputText by remember { mutableStateOf("") }
    var showSessionsSheet by remember { mutableStateOf(false) }
    var showSearchBar by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let { chatViewModel.attachUri(context, it, "image/jpeg") }
    }

    val documentPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { chatViewModel.attachUri(context, it, "application/pdf") }
    }

    LaunchedEffect(messages.size, uiState.streamingText) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(bottom = bottomPadding.calculateBottomPadding())
            .imePadding()
    ) {
        // Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "TDB Personal AI Chat",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
                Text(
                    text = if (uiState.lastEngineUsed.isNotBlank()) uiState.lastEngineUsed
                    else "Model: ${settings.selectedChatModelId.ifBlank { "Not configured" }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            Row {
                IconButton(onClick = { showSearchBar = !showSearchBar }, modifier = Modifier.testTag("chat_search_btn")) {
                    Icon(Icons.Filled.Search, contentDescription = "Search Chats", tint = TextPrimary)
                }
                IconButton(onClick = { showSessionsSheet = true }, modifier = Modifier.testTag("chat_sessions_btn")) {
                    Icon(Icons.Filled.History, contentDescription = "Sessions", tint = TextPrimary)
                }
                IconButton(onClick = { chatViewModel.createNewSession() }, modifier = Modifier.testTag("chat_new_btn")) {
                    Icon(Icons.Filled.Add, contentDescription = "New Chat", tint = ElectricAzure)
                }
            }
        }

        // Language & Mode Chips
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(AppLanguage.entries) { lang ->
                val selected = settings.primaryLanguage == lang
                AssistChip(
                    onClick = { onLanguageChange(lang) },
                    label = { Text("${lang.nativeLabel} (${lang.displayName})") },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = if (selected) CrimsonPrimary.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.08f),
                        labelColor = Color.White
                    )
                )
            }
        }

        // Search Drawer
        AnimatedVisibility(visible = showSearchBar) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = { chatViewModel.updateSearchQuery(it) },
                    placeholder = { Text("Search across all chat sessions...") },
                    singleLine = true,
                    trailingIcon = {
                        IconButton(onClick = {
                            chatViewModel.updateSearchQuery("")
                            showSearchBar = false
                        }) {
                            Icon(Icons.Filled.Close, contentDescription = "Close Search")
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = ElectricAzure,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.2f)
                    )
                )
                if (searchResults.isNotEmpty()) {
                    TdbGlassCard(modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Matches (${searchResults.size})", style = MaterialTheme.typography.labelSmall, color = ElectricAzure)
                            searchResults.take(5).forEach { hit ->
                                Text(
                                    text = hit.content.take(90),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextPrimary,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            chatViewModel.selectSession(hit.sessionId)
                                            showSearchBar = false
                                        }
                                        .padding(vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Error Banner
        if (!uiState.errorMessage.isNullOrBlank()) {
            TdbGlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                tintColor = Color(0xFF3A121C),
                borderGlow = StatusRose
            ) {
                Column {
                    Text(uiState.errorMessage.orEmpty(), style = MaterialTheme.typography.bodyMedium, color = StatusRose)
                    if (!uiState.errorSuggestion.isNullOrBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text(uiState.errorSuggestion.orEmpty(), style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 6.dp)) {
                        Text(
                            "API Settings",
                            color = ElectricAzure,
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.clickable { onOpenApiManagement() }
                        )
                        Text(
                            "Dismiss",
                            color = TextMuted,
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.clickable { chatViewModel.clearError() }
                        )
                    }
                }
            }
        }

        // Messages List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (messages.isEmpty() && !uiState.isStreaming) {
                item {
                    TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = ElectricAzure) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "হ্যালো Deep! আমি TDB Personal AI Assistant।",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary
                            )
                            Text(
                                text = "Ask in বাংলা, English, or हिन्दी — attach photos or PDFs/documents, generate code, or ask me about Deep Barmon Bhai Vlog.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TdbStatusPill(
                                    label = "আপনি কে?",
                                    dotColor = CrimsonPrimary,
                                    modifier = Modifier.clickable {
                                        chatViewModel.sendMessage("আপনি কে এবং আপনার নির্মাতা কে?")
                                    }
                                )
                                TdbStatusPill(
                                    label = "Vlog Ideas",
                                    dotColor = ElectricAzure,
                                    modifier = Modifier.clickable {
                                        chatViewModel.sendMessage("Deep Barmon Bhai Vlog এর জন্য ৩টি ভাইরাল ভিডিও আইডিয়া দাও।")
                                    }
                                )
                            }
                        }
                    }
                }
            }

            items(messages, key = { it.id }) { msg ->
                ChatMessageBubble(
                    message = msg,
                    onCopy = { copyTextToClipboard(context, msg.content) },
                    onShare = { shareText(context, msg.content) },
                    onSaveMemory = { chatViewModel.saveMessageToMemory(msg.content) }
                )
            }

            if (uiState.isStreaming) {
                item {
                    TdbGlassCard(
                        modifier = Modifier.fillMaxWidth(0.92f),
                        tintColor = Color(0xFF141E38),
                        borderGlow = ElectricAzure
                    ) {
                        Column {
                            if (uiState.streamingReasoning.isNotBlank()) {
                                Text(
                                    text = "Reasoning: ${uiState.streamingReasoning.takeLast(220)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ElectricAzure
                                )
                                Spacer(Modifier.height(6.dp))
                            }
                            Text(
                                text = uiState.streamingText.ifBlank { "Thinking..." },
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }
        }

        // Pending attachment chip
        uiState.pendingAttachment?.let { att ->
            Row(
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .clip(CircleShape)
                    .background(CobaltBlue.copy(alpha = 0.3f))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Attached: ${att.label}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Spacer(Modifier.width(8.dp))
                Icon(
                    Icons.Filled.Close,
                    contentDescription = "Remove Attachment",
                    tint = Color.White,
                    modifier = Modifier
                        .size(16.dp)
                        .clickable { chatViewModel.clearAttachment() }
                )
            }
        }

        // Composer Bar
        TdbGlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            cornerRadius = 26.dp,
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.testTag("chat_attach_image")
                ) {
                    Icon(Icons.Filled.Image, contentDescription = "Attach Image", tint = ElectricAzure)
                }
                IconButton(
                    onClick = {
                        documentPicker.launch(arrayOf("application/pdf", "text/*", "application/json"))
                    },
                    modifier = Modifier.testTag("chat_attach_doc")
                ) {
                    Icon(Icons.Filled.AttachFile, contentDescription = "Attach Document", tint = TextSecondary)
                }
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = { Text("Ask TDB in বাংলা / English / हिन्दी...") },
                    maxLines = 4,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent
                    )
                )
                IconButton(
                    onClick = {
                        if (uiState.isStreaming) {
                            chatViewModel.stopStreaming()
                        } else if (inputText.isNotBlank() || uiState.pendingAttachment != null) {
                            val toSend = inputText
                            inputText = ""
                            chatViewModel.sendMessage(toSend)
                        }
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(CrimsonPrimary)
                        .testTag("chat_send_btn")
                ) {
                    Icon(
                        imageVector = if (uiState.isStreaming) Icons.Filled.Stop else Icons.AutoMirrored.Filled.Send,
                        contentDescription = if (uiState.isStreaming) "Stop" else "Send",
                        tint = Color.White
                    )
                }
            }
        }
    }

    if (showSessionsSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSessionsSheet = false },
            containerColor = Color(0xFF0E1426)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Conversation Sessions", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
                sessions.forEach { session ->
                    val active = session.id == uiState.activeSessionId
                    TdbGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        borderGlow = if (active) CrimsonPrimary else null,
                        onClick = {
                            chatViewModel.selectSession(session.id)
                            showSessionsSheet = false
                        }
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = session.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { chatViewModel.deleteSession(session.id) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Delete Session", tint = StatusRose)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun ChatMessageBubble(
    message: ChatMessageEntity,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onSaveMemory: () -> Unit
) {
    val isUser = message.role == "user"
    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        TdbGlassCard(
            modifier = Modifier.widthIn(max = 330.dp),
            cornerRadius = 20.dp,
            tintColor = if (isUser) Color(0xFF36121C) else Color(0xFF141D35),
            borderGlow = if (isUser) CrimsonPrimary else CobaltBlue,
            contentPadding = PaddingValues(14.dp)
        ) {
            Column {
                if (!message.attachmentLabel.isNullOrBlank()) {
                    Text(
                        text = "Attachment: ${message.attachmentLabel}",
                        style = MaterialTheme.typography.labelSmall,
                        color = ElectricAzure
                    )
                    Spacer(Modifier.height(4.dp))
                }
                if (!message.reasoningSummary.isNullOrBlank()) {
                    Text(
                        text = "Reasoning trace saved",
                        style = MaterialTheme.typography.labelSmall,
                        color = ElectricAzure
                    )
                    Spacer(Modifier.height(4.dp))
                }
                Text(
                    text = message.content,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary
                )
                if (!isUser) {
                    Spacer(Modifier.height(8.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Filled.ContentCopy,
                            contentDescription = "Copy response",
                            tint = TextSecondary,
                            modifier = Modifier
                                .size(18.dp)
                                .clickable(onClick = onCopy)
                        )
                        Icon(
                            Icons.Filled.Share,
                            contentDescription = "Share response",
                            tint = TextSecondary,
                            modifier = Modifier
                                .size(18.dp)
                                .clickable(onClick = onShare)
                        )
                        Icon(
                            Icons.Filled.BookmarkAdd,
                            contentDescription = "Save to Memory",
                            tint = ElectricAzure,
                            modifier = Modifier
                                .size(18.dp)
                                .clickable(onClick = onSaveMemory)
                        )
                        if (!message.modelUsed.isNullOrBlank()) {
                            Text(
                                text = message.modelUsed.take(18),
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun copyTextToClipboard(context: Context, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("TDB Response", text))
}

private fun shareText(context: Context, text: String) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(intent, "Share via TDB Assistant"))
}
