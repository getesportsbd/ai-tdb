package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CobaltBlue
import com.example.ui.theme.CobaltDeep
import com.example.ui.theme.CrimsonDeep
import com.example.ui.theme.CrimsonGlow
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.ElectricAzure
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.voice.VoiceOrbState
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun TdbAtmosphereBackground(
    glowIntensity: Float = 0.85f,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianVoid)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val alphaScale = glowIntensity.coerceIn(0.25f, 1f)

            // Deep crimson radial glow (right / upper-right & lower-right, inspired by mockup)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        CrimsonPrimary.copy(alpha = 0.55f * alphaScale),
                        CrimsonDeep.copy(alpha = 0.30f * alphaScale),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.88f, h * 0.28f),
                    radius = w * 0.95f
                ),
                center = Offset(w * 0.88f, h * 0.28f),
                radius = w * 0.95f
            )

            // Electric sapphire diagonal streak (left / top-left)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        CobaltBlue.copy(alpha = 0.52f * alphaScale),
                        CobaltDeep.copy(alpha = 0.25f * alphaScale),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.14f, h * 0.36f),
                    radius = w * 0.88f
                ),
                center = Offset(w * 0.14f, h * 0.36f),
                radius = w * 0.88f
            )

            // Bottom ambient crimson aura
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        CrimsonPrimary.copy(alpha = 0.42f * alphaScale),
                        CobaltDeep.copy(alpha = 0.18f * alphaScale),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.55f, h * 0.92f),
                    radius = w * 0.85f
                ),
                center = Offset(w * 0.55f, h * 0.92f),
                radius = w * 0.85f
            )
        }
        content()
    }
}

@Composable
fun TdbGlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 24.dp,
    tintColor: Color = Color(0xFF181C2E),
    borderGlow: Color? = null,
    onClick: (() -> Unit)? = null,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)
    val borderBrush = Brush.linearGradient(
        colors = listOf(
            (borderGlow ?: Color.White).copy(alpha = 0.32f),
            Color.White.copy(alpha = 0.08f),
            (borderGlow ?: ElectricAzure).copy(alpha = 0.18f)
        )
    )
    val baseModifier = modifier
        .clip(shape)
        .background(
            Brush.verticalGradient(
                colors = listOf(
                    tintColor.copy(alpha = 0.62f),
                    tintColor.copy(alpha = 0.44f)
                )
            )
        )
        .border(width = 1.dp, brush = borderBrush, shape = shape)
        .let { m ->
            if (onClick != null) m.minimumInteractiveComponentSize().clickable(onClick = onClick) else m
        }
        .padding(contentPadding)

    Box(modifier = baseModifier, content = content)
}

@Composable
fun TdbGlowButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String? = null,
    icon: ImageVector? = null,
    containerColor: Color = CrimsonPrimary,
    enabled: Boolean = true
) {
    val mod = modifier
        .minimumInteractiveComponentSize()
        .shadow(
            elevation = if (enabled) 12.dp else 0.dp,
            shape = CircleShape,
            ambientColor = containerColor,
            spotColor = containerColor
        )
        .let { if (testTag != null) it.testTag(testTag) else it }

    Button(
        onClick = onClick,
        enabled = enabled,
        shape = CircleShape,
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = Color.White,
            disabledContainerColor = Color.White.copy(alpha = 0.12f),
            disabledContentColor = TextSecondary.copy(alpha = 0.5f)
        ),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        modifier = mod
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text = text, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun TdbStatusPill(
    label: String,
    dotColor: Color = StatusGreen,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.10f))
            .border(1.dp, Color.White.copy(alpha = 0.18f), CircleShape)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(dotColor)
        )
        Spacer(Modifier.width(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = TextPrimary
        )
    }
}

@Composable
fun TdbSectionHeader(
    title: String,
    actionLabel: String? = null,
    onActionClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = TextPrimary
        )
        if (actionLabel != null && onActionClick != null) {
            Text(
                text = actionLabel,
                style = MaterialTheme.typography.bodyMedium,
                color = ElectricAzure,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable(onClick = onActionClick)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

/**
 * 3D-inspired fiery crimson & sapphire animated AI Orb (JARVIS holographic sphere).
 */
@Composable
fun TdbAnimatedAiOrb(
    orbState: VoiceOrbState = VoiceOrbState.IDLE,
    rmsLevel: Float = 0f,
    size: Dp = 180.dp,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "tdb_orb")
    val spinAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (orbState) {
                    VoiceOrbState.THINKING -> 2600
                    VoiceOrbState.LISTENING -> 4200
                    VoiceOrbState.SPEAKING -> 3200
                    VoiceOrbState.IDLE -> 7500
                },
                easing = LinearEasing
            )
        ),
        label = "orb_spin"
    )
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.07f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (orbState) {
                    VoiceOrbState.SPEAKING -> 550
                    VoiceOrbState.LISTENING -> 850
                    VoiceOrbState.THINKING -> 700
                    VoiceOrbState.IDLE -> 1800
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb_pulse"
    )

    val dynamicScale = pulse + (rmsLevel * 0.14f)

    Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = this.size.width / 2f
            val cy = this.size.height / 2f
            val baseRadius = (minOf(this.size.width, this.size.height) * 0.34f) * dynamicScale

            // Outer ambient halo
            val haloColor = when (orbState) {
                VoiceOrbState.LISTENING -> ElectricAzure
                VoiceOrbState.THINKING -> Color(0xFFA855F7)
                VoiceOrbState.SPEAKING -> CrimsonGlow
                VoiceOrbState.IDLE -> CrimsonPrimary
            }
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        haloColor.copy(alpha = 0.55f),
                        CobaltBlue.copy(alpha = 0.25f),
                        Color.Transparent
                    ),
                    center = Offset(cx, cy),
                    radius = baseRadius * 1.55f
                ),
                center = Offset(cx, cy),
                radius = baseRadius * 1.55f
            )

            // Outer JARVIS HUD segmented rings
            drawArc(
                color = ElectricAzure.copy(alpha = 0.65f),
                startAngle = spinAngle,
                sweepAngle = 110f,
                useCenter = false,
                topLeft = Offset(cx - baseRadius * 1.24f, cy - baseRadius * 1.24f),
                size = androidx.compose.ui.geometry.Size(baseRadius * 2.48f, baseRadius * 2.48f),
                style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round)
            )
            drawArc(
                color = CrimsonGlow.copy(alpha = 0.85f),
                startAngle = -spinAngle * 1.3f,
                sweepAngle = 140f,
                useCenter = false,
                topLeft = Offset(cx - baseRadius * 1.13f, cy - baseRadius * 1.13f),
                size = androidx.compose.ui.geometry.Size(baseRadius * 2.26f, baseRadius * 2.26f),
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )

            // Core 3D volumetric plasma sphere
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFFFB4B8),
                        CrimsonGlow,
                        CrimsonPrimary,
                        Color(0xFF3A040A),
                        Color(0xFF0A142E)
                    ),
                    center = Offset(cx - baseRadius * 0.22f, cy - baseRadius * 0.22f),
                    radius = baseRadius * 1.15f
                ),
                center = Offset(cx, cy),
                radius = baseRadius
            )

            // Internal swirling energy filaments (matching mockup fiery sphere)
            val rad = spinAngle * (PI / 180.0)
            for (ribbon in 0 until 4) {
                val offsetAngle = rad + ribbon * (PI / 2.2)
                val path = Path()
                val steps = 28
                for (i in 0..steps) {
                    val t = (i.toFloat() / steps) * 2f - 1f
                    val x = cx + t * baseRadius * 0.82f * cos(offsetAngle).toFloat() -
                        sin(t * 2.6f + offsetAngle.toFloat()) * baseRadius * 0.26f
                    val y = cy + t * baseRadius * 0.82f * sin(offsetAngle).toFloat() +
                        cos(t * 2.2f + offsetAngle.toFloat()) * baseRadius * 0.24f
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(
                    path = path,
                    color = if (ribbon % 2 == 0) Color(0xFFFFD6D9).copy(alpha = 0.72f)
                    else ElectricAzure.copy(alpha = 0.55f),
                    style = Stroke(width = (1.6f + ribbon * 0.4f).dp.toPx(), cap = StrokeCap.Round)
                )
            }

            // Specular 3D glass rim highlight
            drawCircle(
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.55f),
                        Color.Transparent,
                        ElectricAzure.copy(alpha = 0.35f)
                    ),
                    start = Offset(cx - baseRadius, cy - baseRadius),
                    end = Offset(cx + baseRadius, cy + baseRadius)
                ),
                center = Offset(cx, cy),
                radius = baseRadius,
                style = Stroke(width = 1.6.dp.toPx())
            )
        }
    }
}
