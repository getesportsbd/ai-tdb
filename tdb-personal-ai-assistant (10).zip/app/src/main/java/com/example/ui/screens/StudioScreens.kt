package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.data.TdbSettingsState
import com.example.core.network.DiscoveredGeminiModel
import com.example.ui.components.TdbGlassCard
import com.example.ui.components.TdbGlowButton
import com.example.ui.components.TdbStatusPill
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.ElectricAzure
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRose
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.StudioViewModel
import com.example.ui.viewmodel.ThumbnailFontStyle
import com.example.ui.viewmodel.ThumbnailTemplate

@Composable
fun StudioHubScreen(
    onNavigate: (String) -> Unit,
    bottomPadding: PaddingValues
) {
    val items = listOf(
        Triple("AI Image Studio", "Realistic art, logos, promo graphics & photo editing", "image_gen"),
        Triple("YouTube Thumbnail Studio", "16:9 canvas, upload photo, AI background & HD export", "thumbnail_studio"),
        Triple("Video Creation Assistant", "Ideas, titles, scripts, hooks, tags, Shorts & vlog planner", "video_creator"),
        Triple("Advanced Coding Assistant", "Generate, debug, analyze code & controlled file engine", "coding_assistant")
    )
    val icons = listOf(Icons.Filled.Image, Icons.Filled.PhotoLibrary, Icons.Filled.Movie, Icons.Filled.Code)
    val accents = listOf(CrimsonPrimary, ElectricAzure, Color(0xFFF59E0B), Color(0xFF34D399))

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding(),
        contentPadding = PaddingValues(
            start = 16.dp, end = 16.dp, top = 16.dp,
            bottom = bottomPadding.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("TDB Creative & Code Studio", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
            Text("Designed for Deep Barmon Bhai Vlog & full-stack creation", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        }
        items(items.indices.toList()) { idx ->
            val (title, subtitle, route) = items[idx]
            TdbGlassCard(
                modifier = Modifier.fillMaxWidth().testTag("studio_hub_$route"),
                borderGlow = accents[idx],
                onClick = { onNavigate(route) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(accents[idx].copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(icons[idx], contentDescription = title, tint = accents[idx])
                        }
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                    }
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = TextSecondary)
                }
            }
        }
    }
}

@Composable
fun ImageGenScreen(
    studioViewModel: StudioViewModel,
    settings: TdbSettingsState,
    discoveredModels: List<DiscoveredGeminiModel>,
    onBack: () -> Unit,
    onOpenApiManagement: () -> Unit,
    bottomPadding: PaddingValues
) {
    val context = LocalContext.current
    val state by studioViewModel.imageState.collectAsStateWithLifecycle()
    var prompt by remember { mutableStateOf("") }
    var selectedStyle by remember { mutableStateOf("Realistic") }
    var selectedAspect by remember { mutableStateOf("1:1") }
    var saveBanner by remember { mutableStateOf<String?>(null) }

    val styleOptions = listOf("Realistic", "Professional Graphic", "Social Media", "Background", "Logo", "Promotional Art")
    val aspectOptions = listOf("1:1", "16:9", "9:16", "4:3")
    val imageModels = discoveredModels.filter { it.supportsImageOutput }
    val selectedModel = discoveredModels.firstOrNull { it.id == settings.selectedImageModelId }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { studioViewModel.setUploadedImageForEdit(context, it) }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = bottomPadding.calculateBottomPadding() + 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ScreenBackHeader("AI Image Studio", onBack)
        }
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        TdbStatusPill(
                            label = if (selectedModel?.supportsImageOutput == true) {
                                "Image Model: ${selectedModel.id}"
                            } else {
                                "Image Model Required"
                            },
                            dotColor = if (selectedModel?.supportsImageOutput == true) StatusGreen else StatusAmber
                        )
                        Text(
                            "Select Model",
                            color = ElectricAzure,
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.clickable { onOpenApiManagement() }
                        )
                    }
                    if (imageModels.isEmpty()) {
                        Text(
                            "Text-only models cannot generate images. Refresh models in Profile → Gemini API Management to discover image-generation models.",
                            style = MaterialTheme.typography.bodySmall,
                            color = StatusAmber
                        )
                    }
                }
            }
        }
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        label = { Text("Describe image or edit instruction") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth().testTag("image_gen_prompt"),
                        colors = darkFieldColors()
                    )
                    Text("Style", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(styleOptions) { st ->
                            FilterChip(selected = selectedStyle == st, onClick = { selectedStyle = st }, label = { Text(st) })
                        }
                    }
                    Text("Aspect Ratio", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        aspectOptions.forEach { ar ->
                            FilterChip(selected = selectedAspect == ar, onClick = { selectedAspect = ar }, label = { Text(ar) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = {
                                photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (state.uploadedEditBitmap == null) "Upload to Edit" else "Change Photo")
                        }
                        TdbGlowButton(
                            text = if (state.isGenerating) "Generating..." else "Generate",
                            onClick = { studioViewModel.generateOrEditImage(prompt, selectedStyle, selectedAspect) },
                            enabled = !state.isGenerating && prompt.isNotBlank(),
                            testTag = "image_gen_submit",
                            icon = Icons.Filled.AutoAwesome,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (state.uploadedEditBitmap != null) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("Reference photo attached for editing", style = MaterialTheme.typography.bodySmall, color = ElectricAzure)
                            Text("Clear", color = StatusRose, style = MaterialTheme.typography.labelLarge, modifier = Modifier.clickable { studioViewModel.clearUploadedEditImage() })
                        }
                    }
                }
            }
        }
        if (state.isGenerating) {
            item {
                TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth().padding(20.dp)) {
                        CircularProgressIndicator(color = CrimsonPrimary)
                        Spacer(Modifier.height(10.dp))
                        Text("Synthesizing high-resolution artwork...", color = TextSecondary)
                    }
                }
            }
        }
        if (!state.errorMessage.isNullOrBlank()) {
            item {
                TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = StatusRose) {
                    Text(state.errorMessage.orEmpty(), color = StatusRose, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        state.generatedBitmap?.let { bmp ->
            item {
                TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = ElectricAzure) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "Generated Artwork",
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)),
                            contentScale = ContentScale.Fit
                        )
                        if (!state.statusMessage.isNullOrBlank()) {
                            Text(state.statusMessage.orEmpty(), style = MaterialTheme.typography.bodySmall, color = StatusGreen)
                        }
                        if (!saveBanner.isNullOrBlank()) {
                            Text(saveBanner.orEmpty(), style = MaterialTheme.typography.bodySmall, color = ElectricAzure)
                        }
                        TdbGlowButton(
                            text = "Save to Gallery",
                            onClick = {
                                studioViewModel.saveBitmapToGallery(context, bmp, "TDB_Art") { saveBanner = it }
                            },
                            icon = Icons.Filled.Download,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ThumbnailStudioScreen(
    studioViewModel: StudioViewModel,
    onBack: () -> Unit,
    bottomPadding: PaddingValues
) {
    val context = LocalContext.current
    val state by studioViewModel.thumbState.collectAsStateWithLifecycle()
    var bgPrompt by remember { mutableStateOf("Futuristic glowing red and electric blue tech studio lights") }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { studioViewModel.setThumbnailSubjectPhoto(context, it) }
    }

    val colorSwatches = listOf(
        android.graphics.Color.WHITE,
        android.graphics.Color.parseColor("#FACC15"),
        android.graphics.Color.parseColor("#38BDF8"),
        android.graphics.Color.parseColor("#FF3B47")
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = bottomPadding.calculateBottomPadding() + 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { ScreenBackHeader("YouTube Thumbnail Studio (16:9)", onBack) }

        // Live 16:9 Canvas Preview
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(state.template.bgHex))
                    .border(2.dp, Color(state.template.accentHex).copy(alpha = 0.7f), RoundedCornerShape(20.dp))
            ) {
                state.aiBackgroundBitmap?.let { bg ->
                    Image(
                        bitmap = bg.asImageBitmap(),
                        contentDescription = "AI Thumbnail Background",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
                state.userSubjectBitmap?.let { subj ->
                    Image(
                        bitmap = subj.asImageBitmap(),
                        contentDescription = "Uploaded Subject",
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .fillMaxSize(0.75f),
                        contentScale = ContentScale.Fit
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    Color(0xFF060913).copy(alpha = state.vignetteStrength.coerceIn(0.15f, 0.9f)),
                                    Color.Transparent
                                )
                            )
                        )
                        .padding(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .width(5.dp)
                            .height(92.dp)
                            .align(Alignment.CenterStart)
                            .clip(CircleShape)
                            .background(Color(state.template.accentHex))
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(start = 16.dp)
                            .fillMaxWidth(0.66f),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = state.headlineText,
                            color = Color(state.textColor),
                            fontSize = (20 * state.textSizeScale).sp,
                            fontWeight = FontWeight.ExtraBold,
                            lineHeight = (24 * state.textSizeScale).sp
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = state.subText,
                            color = Color(state.template.accentHex),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Photo & AI Background
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Subject Photo & AI Backdrop", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Text(
                        "Uploaded photos preserve the person's actual appearance unless you explicitly request a transformation.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = {
                                photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            modifier = Modifier.weight(1f).testTag("thumb_pick_photo")
                        ) {
                            Text(if (state.userSubjectBitmap == null) "Upload Photo" else "Change Photo")
                        }
                        TdbGlowButton(
                            text = if (state.isGeneratingBg) "Generating..." else "AI Backdrop",
                            onClick = { studioViewModel.generateThumbnailAiBackground(bgPrompt) },
                            enabled = !state.isGeneratingBg,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(
                        value = bgPrompt,
                        onValueChange = { bgPrompt = it },
                        label = { Text("AI Background Prompt") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = darkFieldColors()
                    )
                }
            }
        }

        // Text, Font, Templates & Adjustments
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = state.headlineText,
                        onValueChange = { studioViewModel.updateThumbnailFields(headline = it) },
                        label = { Text("Thumbnail Headline") },
                        modifier = Modifier.fillMaxWidth().testTag("thumb_headline_input"),
                        colors = darkFieldColors()
                    )
                    OutlinedTextField(
                        value = state.subText,
                        onValueChange = { studioViewModel.updateThumbnailFields(subText = it) },
                        label = { Text("Badge / Channel Label") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = darkFieldColors()
                    )
                    Text("Templates", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(ThumbnailTemplate.entries) { tpl ->
                            FilterChip(
                                selected = state.template == tpl,
                                onClick = { studioViewModel.updateThumbnailFields(template = tpl) },
                                label = { Text(tpl.label) }
                            )
                        }
                    }
                    Text("Font Style", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(ThumbnailFontStyle.entries) { f ->
                            FilterChip(
                                selected = state.fontStyle == f,
                                onClick = { studioViewModel.updateThumbnailFields(fontStyle = f) },
                                label = { Text(f.label) }
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Text Color:", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                        colorSwatches.forEach { hex ->
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(CircleShape)
                                    .background(Color(hex))
                                    .border(
                                        width = if (state.textColor == hex) 3.dp else 1.dp,
                                        color = if (state.textColor == hex) ElectricAzure else Color.White,
                                        shape = CircleShape
                                    )
                                    .clickable { studioViewModel.updateThumbnailFields(textColor = hex) }
                            )
                        }
                    }
                    Text("Text Scale: ${"%.1fx".format(state.textSizeScale)}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Slider(
                        value = state.textSizeScale,
                        onValueChange = { studioViewModel.updateThumbnailFields(textScale = it) },
                        valueRange = 0.7f..1.4f
                    )
                    Text("Vignette Contrast", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Slider(
                        value = state.vignetteStrength,
                        onValueChange = { studioViewModel.updateThumbnailFields(vignette = it) },
                        valueRange = 0.1f..0.95f
                    )
                    if (!state.errorMessage.isNullOrBlank()) {
                        Text(state.errorMessage.orEmpty(), color = StatusRose, style = MaterialTheme.typography.bodySmall)
                    }
                    if (!state.exportStatus.isNullOrBlank()) {
                        Text(state.exportStatus.orEmpty(), color = StatusGreen, style = MaterialTheme.typography.bodySmall)
                    }
                    TdbGlowButton(
                        text = "Export HD 1280×720 PNG",
                        onClick = { studioViewModel.exportThumbnail(context) },
                        icon = Icons.Filled.Download,
                        testTag = "thumb_export_btn",
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
fun VideoCreatorScreen(
    studioViewModel: StudioViewModel,
    onBack: () -> Unit,
    onSendToYouTube: (String) -> Unit,
    bottomPadding: PaddingValues
) {
    val context = LocalContext.current
    val output by studioViewModel.videoOutput.collectAsStateWithLifecycle()
    val busy by studioViewModel.videoBusy.collectAsStateWithLifecycle()
    val error by studioViewModel.videoError.collectAsStateWithLifecycle()
    val savedProjects by studioViewModel.savedVideoProjects.collectAsStateWithLifecycle()

    val tools = listOf(
        "Video Ideas", "YouTube Titles", "Description", "Hashtags", "SEO Tags",
        "Full Script", "Viral Hooks", "Intro & Outro", "Shorts Ideas",
        "Vlog Planner", "Editing Tips", "BG Music", "Storytelling"
    )
    var selectedTool by remember { mutableStateOf(tools.first()) }
    var topic by remember { mutableStateOf("") }
    var extraNotes by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = bottomPadding.calculateBottomPadding() + 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { ScreenBackHeader("Video Creation Assistant", onBack) }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(tools) { tool ->
                    FilterChip(selected = selectedTool == tool, onClick = { selectedTool = tool }, label = { Text(tool) })
                }
            }
        }

        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = topic,
                        onValueChange = { topic = it },
                        label = { Text("Video Topic / Vlog Idea (Bengali or English)") },
                        modifier = Modifier.fillMaxWidth().testTag("video_topic_input"),
                        colors = darkFieldColors()
                    )
                    OutlinedTextField(
                        value = extraNotes,
                        onValueChange = { extraNotes = it },
                        label = { Text("Audience / Tone / Duration notes (optional)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = darkFieldColors()
                    )
                    TdbGlowButton(
                        text = if (busy) "Generating $selectedTool..." else "Generate $selectedTool",
                        onClick = { studioViewModel.generateVideoAsset(selectedTool, topic, extraNotes) },
                        enabled = !busy && topic.isNotBlank(),
                        icon = Icons.Filled.AutoAwesome,
                        testTag = "video_generate_btn",
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        if (!error.isNullOrBlank()) {
            item {
                TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = StatusRose) {
                    Text(error.orEmpty(), color = StatusRose, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        if (output.isNotBlank()) {
            item {
                TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = ElectricAzure) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(selectedTool, style = MaterialTheme.typography.titleMedium, color = ElectricAzure)
                        Text(output, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(onClick = {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("TDB Video", output))
                            }) {
                                Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Copy")
                            }
                            OutlinedButton(onClick = {
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, output)
                                }
                                context.startActivity(Intent.createChooser(intent, "Share Video Draft"))
                            }) {
                                Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Share")
                            }
                            OutlinedButton(onClick = { onSendToYouTube(topic) }) {
                                Text("YouTube")
                            }
                        }
                    }
                }
            }
        }

        if (savedProjects.isNotEmpty()) {
            item { Text("Saved Creator Drafts", style = MaterialTheme.typography.titleMedium, color = TextPrimary) }
            items(savedProjects.take(10), key = { it.id }) { proj ->
                TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${proj.toolType} • ${proj.topic}", style = MaterialTheme.typography.labelLarge, color = ElectricAzure)
                            Spacer(Modifier.height(4.dp))
                            Text(proj.generatedContent.take(160), style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                        IconButton(onClick = { studioViewModel.deleteVideoProject(proj.id) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete Draft", tint = StatusRose)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ScreenBackHeader(title: String, onBack: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.10f))
        ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
        }
        Spacer(Modifier.width(12.dp))
        Text(title, style = MaterialTheme.typography.headlineSmall, color = TextPrimary)
    }
}

@Composable
fun darkFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    focusedLabelColor = ElectricAzure,
    unfocusedLabelColor = TextSecondary,
    focusedBorderColor = ElectricAzure,
    unfocusedBorderColor = Color.White.copy(alpha = 0.22f),
    cursorColor = CrimsonPrimary
)
