package com.example.ui.viewmodel

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.res.ResourcesCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.AppContainer
import com.example.R
import com.example.core.data.db.VideoProjectEntity
import com.example.core.data.repository.TdbRepository
import com.example.core.error.ErrorRecoveryEngine
import com.example.core.files.ControlledFileEngine
import com.example.core.files.FileExecutionReceipt
import com.example.core.files.ManagedFileEntry
import com.example.core.network.GenerationOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

enum class ThumbnailTemplate(val label: String, val accentHex: Int, val bgHex: Int) {
    TECH_CYBER("Cyber Tech", android.graphics.Color.parseColor("#38BDF8"), android.graphics.Color.parseColor("#0A1328")),
    VLOG_CRIMSON("Deep Vlog", android.graphics.Color.parseColor("#FF3B47"), android.graphics.Color.parseColor("#2A080E")),
    BREAKING_GOLD("Viral Alert", android.graphics.Color.parseColor("#FACC15"), android.graphics.Color.parseColor("#18181B")),
    TUTORIAL_PRO("Pro Guide", android.graphics.Color.parseColor("#34D399"), android.graphics.Color.parseColor("#062019"))
}

enum class ThumbnailFontStyle(val label: String, val fontRes: Int) {
    SPACE_GROTESK("Futuristic", R.font.space_grotesk),
    PLUS_JAKARTA("Modern Clean", R.font.plus_jakarta_sans),
    JETBRAINS_MONO("Tech Mono", R.font.jetbrains_mono),
    BENGALI("বাংলা Bold", R.font.noto_sans_bengali)
}

data class ImageStudioUiState(
    val isGenerating: Boolean = false,
    val generatedBitmap: Bitmap? = null,
    val uploadedEditBitmap: Bitmap? = null,
    val uploadedBytes: ByteArray? = null,
    val statusMessage: String? = null,
    val errorMessage: String? = null
)

data class ThumbnailStudioUiState(
    val headlineText: String = "AI JARVIS IN REAL LIFE!",
    val subText: String = "Deep Barmon Bhai Vlog",
    val template: ThumbnailTemplate = ThumbnailTemplate.VLOG_CRIMSON,
    val fontStyle: ThumbnailFontStyle = ThumbnailFontStyle.SPACE_GROTESK,
    val textColor: Int = android.graphics.Color.WHITE,
    val brightnessBoost: Float = 1.0f,
    val vignetteStrength: Float = 0.45f,
    val textSizeScale: Float = 1.0f,
    val userSubjectBitmap: Bitmap? = null,
    val aiBackgroundBitmap: Bitmap? = null,
    val isGeneratingBg: Boolean = false,
    val exportStatus: String? = null,
    val errorMessage: String? = null
)

data class CodingUiState(
    val isBusy: Boolean = false,
    val outputCode: String = "",
    val explanation: String = "",
    val lastReceipt: FileExecutionReceipt? = null,
    val files: List<ManagedFileEntry> = emptyList(),
    val selectedFileContent: String? = null,
    val selectedFileName: String? = null,
    val errorMessage: String? = null
)

class StudioViewModel(
    private val repository: TdbRepository,
    private val fileEngine: ControlledFileEngine
) : ViewModel() {

    private val _imageState = MutableStateFlow(ImageStudioUiState())
    val imageState: StateFlow<ImageStudioUiState> = _imageState.asStateFlow()

    private val _thumbState = MutableStateFlow(ThumbnailStudioUiState())
    val thumbState: StateFlow<ThumbnailStudioUiState> = _thumbState.asStateFlow()

    private val _codingState = MutableStateFlow(CodingUiState())
    val codingState: StateFlow<CodingUiState> = _codingState.asStateFlow()

    private val _videoOutput = MutableStateFlow("")
    val videoOutput: StateFlow<String> = _videoOutput.asStateFlow()

    private val _videoBusy = MutableStateFlow(false)
    val videoBusy: StateFlow<Boolean> = _videoBusy.asStateFlow()

    private val _videoError = MutableStateFlow<String?>(null)
    val videoError: StateFlow<String?> = _videoError.asStateFlow()

    val savedVideoProjects: StateFlow<List<VideoProjectEntity>> = repository.videoProjectsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = emptyList()
    )

    init {
        refreshWorkspaceFiles()
    }

    // --- 1. AI IMAGE GENERATION & EDITING ---
    fun setUploadedImageForEdit(context: Context, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: error("Unable to read selected image.")
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    ?: error("Invalid image file.")
                bmp to bytes
            }.onSuccess { (bmp, bytes) ->
                _imageState.value = _imageState.value.copy(
                    uploadedEditBitmap = bmp,
                    uploadedBytes = bytes,
                    errorMessage = null
                )
            }.onFailure {
                _imageState.value = _imageState.value.copy(errorMessage = it.localizedMessage)
            }
        }
    }

    fun clearUploadedEditImage() {
        _imageState.value = _imageState.value.copy(uploadedEditBitmap = null, uploadedBytes = null)
    }

    fun generateOrEditImage(prompt: String, stylePreset: String, aspectRatio: String) {
        if (prompt.isBlank()) return
        viewModelScope.launch {
            val apiKey = repository.getGeminiApiKey().orEmpty()
            val settings = repository.settingsFlow.first()
            val models = repository.discoveredModels.value
            val chosenModel = models.firstOrNull { it.id == settings.selectedImageModelId }
                ?: models.firstOrNull { it.supportsImageOutput }

            if (apiKey.isBlank()) {
                _imageState.value = _imageState.value.copy(
                    errorMessage = "Configure your Gemini API key in Profile → Gemini API Management first."
                )
                return@launch
            }
            if (chosenModel == null || !chosenModel.supportsImageOutput) {
                _imageState.value = _imageState.value.copy(
                    errorMessage = "No image-capable model selected or discovered. Text-only models cannot generate images — refresh models in API Management and choose an image-generation model."
                )
                return@launch
            }

            _imageState.value = _imageState.value.copy(isGenerating = true, errorMessage = null, statusMessage = null)
            try {
                val fullPrompt = if (_imageState.value.uploadedBytes != null) {
                    "Edit the uploaded image according to this instruction ($stylePreset): $prompt. Preserve realistic subject identity unless transformation is requested."
                } else {
                    "Create a $stylePreset graphic: $prompt"
                }

                val bmp = withTimeout(75_000L) {
                    repository.geminiApi.generateOrEditImage(
                        apiKey = apiKey,
                        model = chosenModel,
                        prompt = fullPrompt,
                        inputBitmapBytes = _imageState.value.uploadedBytes,
                        aspectRatio = aspectRatio
                    )
                }
                repository.logAction("IMAGE", "Image Generated", "Model: ${chosenModel.id} ($stylePreset)", "SUCCESS")
                _imageState.value = _imageState.value.copy(
                    isGenerating = false,
                    generatedBitmap = bmp,
                    statusMessage = "Generated using ${chosenModel.displayName}"
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val diagnosis = ErrorRecoveryEngine.diagnose(e, "AI Image Studio")
                repository.logError("IMAGE", "Image Generation Failed", diagnosis)
                _imageState.value = _imageState.value.copy(
                    isGenerating = false,
                    errorMessage = diagnosis.userMessage
                )
            }
        }
    }

    fun saveBitmapToGallery(context: Context, bitmap: Bitmap, fileNamePrefix: String, onComplete: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val resultMsg = runCatching {
                val fileName = "${fileNamePrefix}_${System.currentTimeMillis()}.png"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                        put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/TDB_Assistant")
                    }
                    val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                        ?: error("Failed to create MediaStore record.")
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    } ?: error("Failed to write image stream.")
                    "Saved to Pictures/TDB_Assistant/$fileName"
                } else {
                    val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "TDB_Assistant")
                    dir.mkdirs()
                    val file = File(dir, fileName)
                    FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    "Saved to ${file.absolutePath}"
                }
            }.getOrElse { "Save error: ${it.localizedMessage}" }
            withContext(Dispatchers.Main) { onComplete(resultMsg) }
        }
    }

    // --- 2. YOUTUBE THUMBNAIL STUDIO ---
    fun setThumbnailSubjectPhoto(context: Context, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                    ?: error("Could not decode photo.")
            }.onSuccess { bmp ->
                _thumbState.value = _thumbState.value.copy(userSubjectBitmap = bmp, errorMessage = null)
            }.onFailure {
                _thumbState.value = _thumbState.value.copy(errorMessage = it.localizedMessage)
            }
        }
    }

    fun updateThumbnailFields(
        headline: String? = null,
        subText: String? = null,
        template: ThumbnailTemplate? = null,
        fontStyle: ThumbnailFontStyle? = null,
        textColor: Int? = null,
        brightness: Float? = null,
        vignette: Float? = null,
        textScale: Float? = null
    ) {
        val cur = _thumbState.value
        _thumbState.value = cur.copy(
            headlineText = headline ?: cur.headlineText,
            subText = subText ?: cur.subText,
            template = template ?: cur.template,
            fontStyle = fontStyle ?: cur.fontStyle,
            textColor = textColor ?: cur.textColor,
            brightnessBoost = brightness ?: cur.brightnessBoost,
            vignetteStrength = vignette ?: cur.vignetteStrength,
            textSizeScale = textScale ?: cur.textSizeScale
        )
    }

    fun generateThumbnailAiBackground(prompt: String) {
        viewModelScope.launch {
            val apiKey = repository.getGeminiApiKey().orEmpty()
            val settings = repository.settingsFlow.first()
            val models = repository.discoveredModels.value
            val chosenModel = models.firstOrNull { it.id == settings.selectedImageModelId }
                ?: models.firstOrNull { it.supportsImageOutput }
            if (apiKey.isBlank() || chosenModel == null) {
                _thumbState.value = _thumbState.value.copy(
                    errorMessage = "Select an image-capable Gemini model in Profile → Gemini API Management to generate AI backgrounds."
                )
                return@launch
            }
            _thumbState.value = _thumbState.value.copy(isGeneratingBg = true, errorMessage = null)
            try {
                val subjectBytes = _thumbState.value.userSubjectBitmap?.let { bmp ->
                    ByteArrayOutputStream().use { bos ->
                        bmp.compress(Bitmap.CompressFormat.JPEG, 90, bos)
                        bos.toByteArray()
                    }
                }
                val finalPrompt = if (subjectBytes != null) {
                    "YouTube 16:9 thumbnail background around the uploaded person: $prompt. STRICTLY preserve the person's real face, skin tone, and actual appearance without altering facial features."
                } else {
                    "High-impact 16:9 YouTube thumbnail cinematic background without text: $prompt"
                }
                val bmp = withTimeout(75_000L) {
                    repository.geminiApi.generateOrEditImage(
                        apiKey = apiKey,
                        model = chosenModel,
                        prompt = finalPrompt,
                        inputBitmapBytes = subjectBytes,
                        aspectRatio = "16:9"
                    )
                }
                _thumbState.value = _thumbState.value.copy(
                    aiBackgroundBitmap = bmp,
                    isGeneratingBg = false,
                    exportStatus = "AI 16:9 background generated."
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val diag = ErrorRecoveryEngine.diagnose(e, "Thumbnail AI Background")
                _thumbState.value = _thumbState.value.copy(isGeneratingBg = false, errorMessage = diag.userMessage)
            }
        }
    }

    fun renderHighResThumbnail(context: Context): Bitmap {
        val state = _thumbState.value
        val w = 1280
        val h = 720
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)

        // Base background
        canvas.drawColor(state.template.bgHex)
        state.aiBackgroundBitmap?.let { bg ->
            val src = Rect(0, 0, bg.width, bg.height)
            val dst = Rect(0, 0, w, h)
            canvas.drawBitmap(bg, src, dst, Paint(Paint.ANTI_ALIAS_FLAG))
        }

        // Subject photo (right side composition, preserving actual appearance)
        state.userSubjectBitmap?.let { subj ->
            val targetH = (h * 0.92f).toInt()
            val scale = targetH.toFloat() / subj.height.coerceAtLeast(1)
            val targetW = (subj.width * scale).toInt()
            val left = w - targetW - 24
            val top = h - targetH
            val dst = Rect(left.coerceAtLeast(w / 3), top, (left + targetW).coerceAtMost(w), h)
            canvas.drawBitmap(subj, Rect(0, 0, subj.width, subj.height), dst, Paint(Paint.ANTI_ALIAS_FLAG))
        }

        // Dark gradient vignette for crisp text readability
        val vignettePaint = Paint().apply {
            shader = android.graphics.LinearGradient(
                0f, 0f, w * 0.72f, 0f,
                android.graphics.Color.argb((220 * state.vignetteStrength).toInt().coerceIn(40, 230), 6, 9, 19),
                android.graphics.Color.TRANSPARENT,
                android.graphics.Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), vignettePaint)

        // Accent bar
        val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = state.template.accentHex }
        canvas.drawRoundRect(56f, 150f, 72f, 540f, 8f, 8f, accentPaint)

        val typeface = runCatching {
            ResourcesCompat.getFont(context, state.fontStyle.fontRes)
        }.getOrNull() ?: Typeface.DEFAULT_BOLD

        // Headline text
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = state.textColor
            textSize = 92f * state.textSizeScale
            this.typeface = Typeface.create(typeface, Typeface.BOLD)
            setShadowLayer(12f, 4f, 6f, android.graphics.Color.BLACK)
        }
        val words = state.headlineText.split(" ")
        var line = ""
        var y = 260f
        for (word in words) {
            val test = if (line.isEmpty()) word else "$line $word"
            if (textPaint.measureText(test) > w * 0.54f && line.isNotEmpty()) {
                canvas.drawText(line, 102f, y, textPaint)
                y += 108f * state.textSizeScale
                line = word
            } else {
                line = test
            }
        }
        if (line.isNotEmpty()) {
            canvas.drawText(line, 102f, y, textPaint)
        }

        // Channel / Subtext badge
        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = state.template.accentHex
            textSize = 40f
            this.typeface = Typeface.create(typeface, Typeface.BOLD)
        }
        canvas.drawText(state.subText, 102f, 610f, subPaint)
        return out
    }

    fun exportThumbnail(context: Context) {
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.Default) { renderHighResThumbnail(context) }
            saveBitmapToGallery(context, bmp, "TDB_Thumb") { msg ->
                _thumbState.value = _thumbState.value.copy(exportStatus = msg)
            }
        }
    }

    // --- 3. VIDEO CREATION ASSISTANT ---
    fun generateVideoAsset(toolType: String, topic: String, extraContext: String) {
        if (topic.isBlank()) return
        viewModelScope.launch {
            val apiKey = repository.getGeminiApiKey().orEmpty()
            val settings = repository.settingsFlow.first()
            val modelId = settings.selectedChatModelId
            if (apiKey.isBlank() || modelId.isBlank()) {
                _videoError.value = "Configure your Gemini API key & model in Profile → Gemini API Management."
                return@launch
            }
            _videoBusy.value = true
            _videoError.value = null
            try {
                val sys = repository.buildSystemPrompt(
                    "You are the dedicated YouTube Video Creation Strategist for Deep Barmon Bhai Vlog. Provide actionable, high-retention output."
                )
                val prompt = """
                    Tool Mode: $toolType
                    Topic / Concept: $topic
                    Channel: Deep Barmon Bhai Vlog
                    Extra Notes: $extraContext
                    Provide structured, ready-to-use output tailored to the requested mode ($toolType).
                """.trimIndent()
                val text = withTimeout(60_000L) {
                    repository.geminiApi.generateText(
                        apiKey = apiKey,
                        modelId = modelId,
                        systemInstruction = sys,
                        prompt = prompt,
                        options = GenerationOptions(
                            temperature = settings.temperature,
                            preferInteractionsApi = settings.preferInteractionsApi
                        )
                    )
                }
                _videoOutput.value = text
                repository.saveVideoProject(toolType, topic, text, settings.primaryLanguage.code)
                repository.logAction("VIDEO", "Generated $toolType", topic, "SUCCESS")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val diag = ErrorRecoveryEngine.diagnose(e, "Video Creation Assistant")
                _videoError.value = diag.userMessage
            } finally {
                _videoBusy.value = false
            }
        }
    }

    fun deleteVideoProject(id: Long) {
        viewModelScope.launch { repository.deleteVideoProject(id) }
    }

    // --- 4. ADVANCED CODING ASSISTANT & FILE ENGINE ---
    fun refreshWorkspaceFiles(query: String = "") {
        viewModelScope.launch {
            val safUri = repository.settingsFlow.first().safTreeUri
            val entries = fileEngine.listFiles(safUri, query)
            _codingState.value = _codingState.value.copy(files = entries)
        }
    }

    fun runCodingTask(mode: String, language: String, prompt: String, executeFileCommand: Boolean) {
        if (prompt.isBlank()) return
        viewModelScope.launch {
            val apiKey = repository.getGeminiApiKey().orEmpty()
            val settings = repository.settingsFlow.first()
            val modelId = settings.selectedChatModelId
            if (apiKey.isBlank() || modelId.isBlank()) {
                _codingState.value = _codingState.value.copy(
                    errorMessage = "Configure your Gemini API key & model in Profile → Gemini API Management."
                )
                return@launch
            }
            _codingState.value = _codingState.value.copy(isBusy = true, errorMessage = null, lastReceipt = null)
            try {
                val plan = if (executeFileCommand) fileEngine.parseNaturalCommand(prompt) else null
                val aiPrompt = if (executeFileCommand && plan != null) {
                    "Mode: $mode\nLanguage: ${plan.languageHint}\nInstruction: $prompt\nReturn ONLY the complete clean source code for '${plan.fileName ?: "output.txt"}' without markdown code fences."
                } else {
                    "Mode: $mode\nLanguage: $language\nInstruction: $prompt\nExisting code context:\n${_codingState.value.outputCode.take(3000)}"
                }
                val sys = repository.buildSystemPrompt("You are TDB Advanced Coding Assistant. Write clean, secure, production-ready code.")
                val generated = withTimeout(60_000L) {
                    repository.geminiApi.generateText(
                        apiKey = apiKey,
                        modelId = modelId,
                        systemInstruction = sys,
                        prompt = aiPrompt,
                        options = GenerationOptions(temperature = 0.25f, preferInteractionsApi = settings.preferInteractionsApi)
                    )
                }.trim()
                    .removePrefix("```html").removePrefix("```kotlin").removePrefix("```python")
                    .removePrefix("```javascript").removePrefix("```java").removePrefix("```css")
                    .removePrefix("```").removeSuffix("```").trim()

                var receipt: FileExecutionReceipt? = null
                if (executeFileCommand && plan != null) {
                    receipt = fileEngine.createFolderAndFile(
                        safTreeUriString = settings.safTreeUri,
                        folderName = plan.folderName ?: "TDB Project",
                        fileName = plan.fileName ?: "index.html",
                        fileContent = generated
                    )
                    repository.logAction("FILE", "Controlled File Engine", receipt.summary, if (receipt.verified) "SUCCESS" else "WARNING")
                }

                _codingState.value = _codingState.value.copy(
                    isBusy = false,
                    outputCode = generated,
                    lastReceipt = receipt
                )
                refreshWorkspaceFiles()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val diag = ErrorRecoveryEngine.diagnose(e, "Coding Assistant")
                _codingState.value = _codingState.value.copy(isBusy = false, errorMessage = diag.userMessage)
            }
        }
    }

    fun openWorkspaceFile(entry: ManagedFileEntry) {
        if (entry.isDirectory) return
        viewModelScope.launch {
            runCatching { fileEngine.readFileContent(entry) }
                .onSuccess { text ->
                    _codingState.value = _codingState.value.copy(
                        selectedFileContent = text,
                        selectedFileName = entry.name,
                        outputCode = text
                    )
                }
                .onFailure {
                    _codingState.value = _codingState.value.copy(errorMessage = it.localizedMessage)
                }
        }
    }

    fun createManualFolderOrFile(folderName: String, fileName: String, content: String) {
        viewModelScope.launch {
            val safUri = repository.settingsFlow.first().safTreeUri
            runCatching {
                fileEngine.createFolderAndFile(safUri, folderName.ifBlank { null }, fileName.ifBlank { null }, content)
            }.onSuccess { receipt ->
                _codingState.value = _codingState.value.copy(lastReceipt = receipt)
                refreshWorkspaceFiles()
            }.onFailure {
                _codingState.value = _codingState.value.copy(errorMessage = it.localizedMessage)
            }
        }
    }

    fun deleteWorkspaceEntry(entry: ManagedFileEntry) {
        viewModelScope.launch {
            fileEngine.deleteEntry(entry)
            refreshWorkspaceFiles()
        }
    }

    fun saveSafTreeUri(uriString: String) {
        viewModelScope.launch {
            repository.preferences.setSafTreeUri(uriString)
            refreshWorkspaceFiles()
        }
    }

    companion object {
        fun provideFactory(container: AppContainer): ViewModelProvider.Factory = viewModelFactory {
            initializer { StudioViewModel(container.repository, container.fileEngine) }
        }
    }
}
