package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianVoid = Color(0xFF060913)
val ObsidianSurface = Color(0xFF0D1222)
val ObsidianCard = Color(0xFF141A2E)

val CrimsonPrimary = Color(0xFFE52534)
val CrimsonGlow = Color(0xFFFF4655)
val CrimsonDeep = Color(0xFF8B111C)

val CobaltBlue = Color(0xFF1D63DC)
val ElectricAzure = Color(0xFF38BDF8)
val CobaltDeep = Color(0xFF0B2A63)

val GlassWhite = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFFCBD5E1)
val TextMuted = Color(0xFF94A3B8)

val StatusGreen = Color(0xFF22C55E)
val StatusAmber = Color(0xFFF59E0B)
val StatusRose = Color(0xFFFB7185)
