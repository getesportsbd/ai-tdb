package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.data.AiPersonality
import com.example.core.data.AppLanguage
import com.example.core.data.TdbSettingsState
import com.example.core.network.ApiConnectionReport
import com.example.core.network.ApiConnectionStatus
import com.example.core.network.DiscoveredGeminiModel
import com.example.ui.components.TdbGlassCard
import com.example.ui.components.TdbGlowButton
import com.example.ui.components.TdbStatusPill
import com.example.ui.theme.CobaltBlue
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.ElectricAzure
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRose
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainAppViewModel
import kotlin.math.roundToInt

@Composable
fun ProfileSettingsScreen(
    mainAppViewModel: MainAppViewModel,
    settings: TdbSettingsState,
    connectionReport: ApiConnectionReport,
    onNavigate: (String) -> Unit,
    onBack: () -> Unit,
    bottomPadding: PaddingValues
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = 12.dp,
            bottom = bottomPadding.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenBackHeader("Profile & Settings", onBack) }

        // Brand & Founder Identity Card
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = CrimsonPrimary) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(CrimsonPrimary, CobaltBlue)))
                                .border(1.5.dp, Color.White.copy(alpha = 0.6f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("DB", style = MaterialTheme.typography.titleLarge, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Deep Barmon", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
                            Text("Founder & Creator • Brand: TDB", style = MaterialTheme.typography.bodySmall, color = ElectricAzure)
                            Text("YouTube: Deep Barmon Bhai Vlog", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                    }
                    OutlinedButton(
                        onClick = {
                            val intent = Intent(
                                Intent.ACTION_VIEW,
                                Uri.parse("https://www.youtube.com/results?search_query=Deep+Barmon+Bhai+Vlog")
                            )
                            context.startActivity(intent)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.SmartDisplay, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Open Deep Barmon Bhai Vlog")
                    }
                }
            }
        }

        // 1 & 2. Gemini API Management & Model Selection
        item {
            TdbGlassCard(
                modifier = Modifier.fillMaxWidth().testTag("settings_api_management"),
                onClick = { onNavigate("api_management") },
                borderGlow = ElectricAzure
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.Key, contentDescription = null, tint = ElectricAzure)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("1-2. Gemini API Management & Models", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                            Text(
                                "Status: ${connectionReport.status.label} • Chat: ${settings.selectedChatModelId.ifBlank { "Select Model" }}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = TextSecondary)
                }
            }
        }

        // 3. Voice Settings shortcut
        item {
            TdbGlassCard(
                modifier = Modifier.fillMaxWidth(),
                onClick = { onNavigate("voice") }
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.VolumeUp, contentDescription = null, tint = CrimsonPrimary)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("3. Voice Assistant Settings", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                            Text("Wake: \"${settings.wakePhrase}\" • Speed: ${(settings.voiceSpeed * 10).roundToInt() / 10f}x • ${settings.voiceGender.label}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                    }
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = TextSecondary)
                }
            }
        }

        // 4. Language & AI Personality
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Language, contentDescription = null, tint = ElectricAzure)
                        Spacer(Modifier.width(8.dp))
                        Text("4. Primary Language & Personality", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AppLanguage.entries.forEach { lang ->
                            FilterChip(
                                selected = settings.primaryLanguage == lang,
                                onClick = { mainAppViewModel.setPrimaryLanguage(lang) },
                                label = { Text("${lang.displayName} (${lang.nativeLabel})") }
                            )
                        }
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(AiPersonality.entries) { p ->
                            FilterChip(
                                selected = settings.personality == p,
                                onClick = { mainAppViewModel.setPersonality(p) },
                                label = { Text(p.title) }
                            )
                        }
                    }
                }
            }
        }

        // 5. Memory Settings
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth(), onClick = { onNavigate("memory_vault") }) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.Memory, contentDescription = null, tint = ElectricAzure)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("5. Memory Vault", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                            Text(if (settings.memoryEnabled) "Long-term context active (Secret Guard ON)" else "Paused", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                    }
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = TextSecondary)
                }
            }
        }

        // 6. Permission Center
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth(), onClick = { onNavigate("permission_center") }) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.Security, contentDescription = null, tint = StatusGreen)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("6. Permission Center", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                            Text("Review & revoke runtime, SAF, Accessibility & Overlay access", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                    }
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = TextSecondary)
                }
            }
        }

        // 7 & 8. Automation Confirmation & Notifications
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.PhoneAndroid, contentDescription = null, tint = Color(0xFFA78BFA))
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("7. Confirm Sensitive Automation", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                                Text("Prompt confirmation before uploads/system triggers", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            }
                        }
                        Switch(checked = settings.automationConfirmSensitive, onCheckedChange = { mainAppViewModel.setAutomationConfirmSensitive(it) })
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.Notifications, contentDescription = null, tint = StatusAmber)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("8. Task & Assistant Notifications", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                                Text("Show alerts when autonomous tasks complete", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            }
                        }
                        Switch(checked = settings.notificationsEnabled, onCheckedChange = { mainAppViewModel.setNotificationsEnabled(it) })
                    }
                }
            }
        }

        // 9. Appearance
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Palette, contentDescription = null, tint = CrimsonPrimary)
                        Spacer(Modifier.width(8.dp))
                        Text("9. Appearance • Ambient Glow ${(settings.glowIntensity * 100).roundToInt()}%", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                    }
                    Slider(
                        value = settings.glowIntensity,
                        onValueChange = { mainAppViewModel.setGlowIntensity(it) },
                        valueRange = 0.25f..1.0f
                    )
                }
            }
        }

        // 10. Privacy & Security + Logs
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth(), onClick = { onNavigate("error_logs") }) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.Lock, contentDescription = null, tint = StatusGreen)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("10. Privacy, Keystore & Error Logs", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                            Text("Keys encrypted in Android Keystore (AES-256-GCM) • Zero telemetry", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                    }
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = TextSecondary)
                }
            }
        }

        // 11. About Application
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = ElectricAzure) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("11. About TDB Personal AI Assistant", style = MaterialTheme.typography.titleMedium, color = ElectricAzure)
                    Text("Brand: TDB • Founder & Creator: Deep Barmon", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    Text("Official Channel: Deep Barmon Bhai Vlog", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Text(
                        "\"An AI That Doesn't Just Answer. An AI That Helps You Get Things Done.\"",
                        style = MaterialTheme.typography.labelLarge,
                        color = CrimsonPrimary
                    )
                }
            }
        }
    }
}

@Composable
fun GeminiApiManagementScreen(
    mainAppViewModel: MainAppViewModel,
    settings: TdbSettingsState,
    discoveredModels: List<DiscoveredGeminiModel>,
    connectionReport: ApiConnectionReport,
    onBack: () -> Unit,
    bottomPadding: PaddingValues
) {
    val statusBanner by mainAppViewModel.statusBanner.collectAsStateWithLifecycle()

    var keyInput by remember { mutableStateOf("") }
    var showKey by remember { mutableStateOf(false) }
    var preferInteractions by remember(settings.preferInteractionsApi) { mutableStateOf(settings.preferInteractionsApi) }
    var autoRefresh by remember(settings.autoRefreshModels) { mutableStateOf(settings.autoRefreshModels) }
    var temperature by remember(settings.temperature) { mutableFloatStateOf(settings.temperature) }
    var topP by remember(settings.topP) { mutableFloatStateOf(settings.topP) }
    var maxTokens by remember(settings.maxOutputTokens) { mutableIntStateOf(settings.maxOutputTokens) }
    var enableThinking by remember(settings.enableThinking) { mutableStateOf(settings.enableThinking) }

    val hasKey = mainAppViewModel.hasGeminiKey()
    val maskedKey = remember(hasKey, statusBanner) { mainAppViewModel.getMaskedGeminiKey() }

    val statusColor = when (connectionReport.status) {
        ApiConnectionStatus.CONNECTED -> StatusGreen
        ApiConnectionStatus.TESTING -> ElectricAzure
        ApiConnectionStatus.AUTH_FAILED, ApiConnectionStatus.OFFLINE_OR_ERROR -> StatusRose
        ApiConnectionStatus.NOT_CONFIGURED -> StatusAmber
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = 12.dp,
            bottom = bottomPadding.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { ScreenBackHeader("Gemini API Management", onBack) }

        if (!statusBanner.isNullOrBlank()) {
            item {
                TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = ElectricAzure) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(statusBanner.orEmpty(), style = MaterialTheme.typography.bodyMedium, color = TextPrimary, modifier = Modifier.weight(1f))
                        TextButton(onClick = { mainAppViewModel.clearBanner() }) { Text("OK", color = ElectricAzure) }
                    }
                }
            }
        }

        // Connection Status & Key Storage
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = statusColor) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("API Key & Connection Status", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                        TdbStatusPill(label = connectionReport.status.label, dotColor = statusColor)
                    }
                    if (hasKey) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.06f))
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (showKey) (mainAppViewModel.revealGeminiKey() ?: maskedKey) else maskedKey,
                                style = MaterialTheme.typography.bodyMedium,
                                color = ElectricAzure,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { showKey = !showKey }, modifier = Modifier.testTag("api_toggle_visibility")) {
                                Icon(
                                    imageVector = if (showKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                    contentDescription = "Show or hide API key",
                                    tint = TextPrimary
                                )
                            }
                            IconButton(onClick = { mainAppViewModel.removeGeminiKey() }, modifier = Modifier.testTag("api_remove_key_btn")) {
                                Icon(Icons.Filled.Delete, contentDescription = "Remove API key", tint = StatusRose)
                            }
                        }
                    }

                    OutlinedTextField(
                        value = keyInput,
                        onValueChange = { keyInput = it },
                        label = { Text(if (hasKey) "Update Gemini API Key" else "Enter Gemini API Key (AIza...)") },
                        visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("api_key_input"),
                        colors = darkFieldColors()
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        TdbGlowButton(
                            text = if (hasKey) "Update & Verify" else "Save & Verify Key",
                            onClick = {
                                mainAppViewModel.saveAndTestGeminiKey(keyInput)
                                keyInput = ""
                            },
                            enabled = keyInput.isNotBlank(),
                            icon = Icons.Filled.CheckCircle,
                            testTag = "api_save_test_btn",
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedButton(
                            onClick = { mainAppViewModel.testAndDiscoverModels() },
                            enabled = hasKey,
                            modifier = Modifier.testTag("api_refresh_models_btn")
                        ) {
                            Icon(Icons.Filled.Refresh, contentDescription = "Discover Models", modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Test")
                        }
                    }

                    if (connectionReport.message.isNotBlank()) {
                        Text(
                            "${connectionReport.message}${if (connectionReport.latencyMs > 0) " (${connectionReport.latencyMs} ms)" else ""}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // Dynamic Discovered Models & Capabilities
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Discovered Models (${discoveredModels.size})",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                    if (discoveredModels.isEmpty()) {
                        Text(
                            "No models loaded yet. Save and test your Gemini API key above to dynamically discover models & verify capabilities.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    } else {
                        val chatModels = discoveredModels.filter { it.supportsGenerateContent }
                        val imageModels = discoveredModels.filter { it.supportsImageOutput }

                        Text("Primary Chat / Reasoning / Code Model", style = MaterialTheme.typography.labelLarge, color = ElectricAzure)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(chatModels, key = { "chat_${it.id}" }) { m ->
                                FilterChip(
                                    selected = settings.selectedChatModelId == m.id,
                                    onClick = { mainAppViewModel.selectChatModel(m.id) },
                                    label = { Text("${m.id} (${m.capabilitySummary})") }
                                )
                            }
                        }

                        Spacer(Modifier.height(4.dp))
                        Text("Image Generation Model", style = MaterialTheme.typography.labelLarge, color = CrimsonPrimary)
                        if (imageModels.isEmpty()) {
                            Text(
                                "No image-output model detected in the current key's model list. Text-only models are never faked as image generators.",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusAmber
                            )
                        } else {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(imageModels, key = { "img_${it.id}" }) { m ->
                                    FilterChip(
                                        selected = settings.selectedImageModelId == m.id,
                                        onClick = { mainAppViewModel.selectImageModel(m.id) },
                                        label = { Text("${m.id} (${m.capabilitySummary})") }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Interactions API & Generation Settings
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Interactions API & Generation Settings", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Prefer Gemini Interactions API", style = MaterialTheme.typography.labelLarge, color = TextPrimary)
                            Text("Uses /v1beta/interactions for agent turns with automatic generateContent fallback", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                        Switch(checked = preferInteractions, onCheckedChange = { preferInteractions = it })
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Auto-Refresh Models on Launch", style = MaterialTheme.typography.labelLarge, color = TextPrimary)
                            Text("Refreshes live /v1beta/models availability automatically", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                        Switch(checked = autoRefresh, onCheckedChange = { autoRefresh = it })
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Enable Deep Reasoning Trace", style = MaterialTheme.typography.labelLarge, color = TextPrimary)
                            Text("Streams thinking steps where supported by the model", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                        Switch(checked = enableThinking, onCheckedChange = { enableThinking = it })
                    }

                    Text("Temperature: ${(temperature * 100).roundToInt() / 100f}", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                    Slider(value = temperature, onValueChange = { temperature = it }, valueRange = 0f..1.5f)

                    Text("Top-P: ${(topP * 100).roundToInt() / 100f}", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                    Slider(value = topP, onValueChange = { topP = it }, valueRange = 0.1f..1.0f)

                    Text("Max Output Tokens: $maxTokens", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                    Slider(
                        value = maxTokens.toFloat(),
                        onValueChange = { maxTokens = it.roundToInt() },
                        valueRange = 512f..8192f
                    )

                    TdbGlowButton(
                        text = "Save Generation Config",
                        onClick = {
                            mainAppViewModel.updateGenerationSettings(
                                preferInteractions = preferInteractions,
                                autoRefresh = autoRefresh,
                                temperature = temperature,
                                topP = topP,
                                maxTokens = maxTokens,
                                enableThinking = enableThinking
                            )
                        },
                        testTag = "api_save_config_btn",
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Security & Production Backend Recommendation
        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = StatusGreen) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Security & Production Recommendation", style = MaterialTheme.typography.titleMedium, color = StatusGreen)
                    Text(
                        "• Your Gemini API key is encrypted at rest using Android Keystore (AES-256-GCM) and never written to logs or plaintext SharedPreferences.\n" +
                            "• For multi-user public production distribution, route AI requests through an authenticated backend proxy (e.g., Cloud Run / Firebase App Check) so user-facing client binaries never carry shared credentials.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}
