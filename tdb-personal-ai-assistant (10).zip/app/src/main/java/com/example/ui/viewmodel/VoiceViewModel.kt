package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.AppContainer
import com.example.automation.PhoneAutomationEngine
import com.example.automation.services.TdbVoiceWakeService
import com.example.core.data.AppLanguage
import com.example.core.data.VoiceGenderOption
import com.example.core.data.repository.TdbRepository
import com.example.core.error.ErrorRecoveryEngine
import com.example.core.network.GenerationOptions
import com.example.voice.VoiceAssistantEngine
import com.example.voice.VoiceOrbState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout

data class VoiceUiState(
    val lastHeardText: String = "",
    val assistantSpeechText: String = "হ্যালো Deep! আমি TDB Personal AI Assistant। কথা বলতে মাইক বাটনে ট্যাপ করুন।",
    val statusText: String = "Tap mic to speak in বাংলা, English, or हिन्दी",
    val errorText: String? = null
)

class VoiceViewModel(
    private val repository: TdbRepository,
    private val voiceEngine: VoiceAssistantEngine,
    private val automationEngine: PhoneAutomationEngine
) : ViewModel() {

    val orbState: StateFlow<VoiceOrbState> = voiceEngine.orbState
    val partialTranscript: StateFlow<String> = voiceEngine.partialTranscript
    val rmsLevel: StateFlow<Float> = voiceEngine.rmsLevel
    val availableVoices: StateFlow<List<String>> = voiceEngine.availableVoicesInfo
    val isWakeServiceRunning: StateFlow<Boolean> = TdbVoiceWakeService.isRunning

    private val _uiState = MutableStateFlow(VoiceUiState())
    val uiState: StateFlow<VoiceUiState> = _uiState.asStateFlow()

    val wakePhraseOptions = listOf("Hey TDB", "Hello TDB", "এই TDB", "হ্যালো TDB")

    fun toggleVoiceInteraction(hasMicPermission: Boolean) {
        if (!hasMicPermission) {
            _uiState.value = _uiState.value.copy(errorText = "Microphone permission is required for voice commands.")
            return
        }
        when (orbState.value) {
            VoiceOrbState.LISTENING, VoiceOrbState.SPEAKING -> {
                // Voice interruption / stop
                voiceEngine.stopAll()
                _uiState.value = _uiState.value.copy(statusText = "Stopped. Tap mic to resume.")
            }
            VoiceOrbState.THINKING -> {
                voiceEngine.stopAll()
            }
            VoiceOrbState.IDLE -> {
                startListeningCycle()
            }
        }
    }

    fun stopSpeaking() {
        voiceEngine.stopSpeakingOnly()
        _uiState.value = _uiState.value.copy(statusText = "Speech interrupted.")
    }

    private fun startListeningCycle() {
        viewModelScope.launch {
            val settings = repository.settingsFlow.first()
            _uiState.value = _uiState.value.copy(
                errorText = null,
                statusText = "Listening (${settings.primaryLanguage.nativeLabel})..."
            )
            voiceEngine.startListening(
                language = settings.primaryLanguage,
                onResult = { transcript ->
                    handleSpokenPrompt(transcript)
                },
                onError = { err ->
                    _uiState.value = _uiState.value.copy(
                        statusText = "Ready",
                        errorText = err
                    )
                }
            )
        }
    }

    fun handleSpokenPrompt(transcript: String) {
        viewModelScope.launch {
            val settings = repository.settingsFlow.first()
            _uiState.value = _uiState.value.copy(
                lastHeardText = transcript,
                statusText = "Thinking...",
                errorText = null
            )
            voiceEngine.setThinkingState()

            val apiKey = repository.getGeminiApiKey().orEmpty()
            val modelId = settings.selectedChatModelId
            if (apiKey.isBlank() || modelId.isBlank()) {
                val msg = "Please configure your Gemini API key and model in Profile → Gemini API Management."
                voiceEngine.setIdleState()
                _uiState.value = _uiState.value.copy(
                    assistantSpeechText = msg,
                    statusText = "API Key Needed",
                    errorText = msg
                )
                return@launch
            }

            try {
                val sys = repository.buildSystemPrompt(
                    "Voice mode active: keep responses crisp, natural for spoken audio, and under 4 sentences unless detailed steps are requested."
                )
                val reply = withTimeout(60_000L) {
                    repository.geminiApi.generateText(
                        apiKey = apiKey,
                        modelId = modelId,
                        systemInstruction = sys,
                        prompt = transcript,
                        options = GenerationOptions(
                            temperature = settings.temperature,
                            topP = settings.topP,
                            maxOutputTokens = 700,
                            preferInteractionsApi = settings.preferInteractionsApi
                        )
                    )
                }
                repository.logAction("VOICE", "Voice Interaction", "Q: ${transcript.take(60)}", "SUCCESS")
                _uiState.value = _uiState.value.copy(
                    assistantSpeechText = reply,
                    statusText = "Speaking..."
                )
                voiceEngine.speak(
                    text = reply,
                    language = settings.primaryLanguage,
                    speed = settings.voiceSpeed,
                    gender = settings.voiceGender
                ) {
                    viewModelScope.launch {
                        val latest = repository.settingsFlow.first()
                        if (latest.continuousVoice && orbState.value == VoiceOrbState.IDLE) {
                            startListeningCycle()
                        } else {
                            _uiState.value = _uiState.value.copy(statusText = "Ready")
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                voiceEngine.setIdleState()
                val diagnosis = ErrorRecoveryEngine.diagnose(e, "Voice Assistant")
                repository.logError("VOICE", "Voice Reply Failed", diagnosis)
                _uiState.value = _uiState.value.copy(
                    statusText = "Error",
                    errorText = diagnosis.userMessage
                )
            }
        }
    }

    fun updateVoicePreferences(
        speed: Float,
        gender: VoiceGenderOption,
        wakePhrase: String,
        continuous: Boolean,
        backgroundWake: Boolean,
        language: AppLanguage
    ) {
        viewModelScope.launch {
            repository.preferences.setPrimaryLanguage(language)
            repository.preferences.updateVoiceSettings(speed, gender, wakePhrase, continuous, backgroundWake)
            if (backgroundWake) {
                val res = automationEngine.startVoiceWakeService(wakePhrase, language.localeTag)
                if (res.isFailure) {
                    _uiState.value = _uiState.value.copy(errorText = res.exceptionOrNull()?.localizedMessage)
                    repository.preferences.updateVoiceSettings(speed, gender, wakePhrase, continuous, false)
                }
            } else {
                automationEngine.stopVoiceWakeService()
            }
        }
    }

    companion object {
        fun provideFactory(container: AppContainer): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                VoiceViewModel(container.repository, container.voiceEngine, container.automationEngine)
            }
        }
    }
}
