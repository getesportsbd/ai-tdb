package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.History
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.data.TdbSettingsState
import com.example.core.data.db.ActionLogEntity
import com.example.core.network.ApiConnectionReport
import com.example.core.network.ApiConnectionStatus
import com.example.ui.components.TdbAnimatedAiOrb
import com.example.ui.components.TdbGlassCard
import com.example.ui.components.TdbGlowButton
import com.example.ui.components.TdbSectionHeader
import com.example.ui.components.TdbStatusPill
import com.example.ui.theme.CobaltBlue
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.ElectricAzure
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRose
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.voice.VoiceOrbState

@Composable
fun OnboardingScreen(
    onGetStarted: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 520.dp)
                .fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(16.dp))
                TdbStatusPill(label = "TDB PERSONAL AI • FOUNDER: DEEP BARMON", dotColor = ElectricAzure)
                Spacer(Modifier.height(12.dp))
                Text(
                    text = "Your Personal AI Core",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
            }

            TdbAnimatedAiOrb(
                orbState = VoiceOrbState.IDLE,
                size = 240.dp
            )

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Smarter Days Begin with\nTDB Personal AI",
                    style = MaterialTheme.typography.displaySmall,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    text = "An AI That Doesn't Just Answer. An AI That Helps You Get Things Done.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(24.dp))
                TdbGlowButton(
                    text = "Get Started",
                    onClick = onGetStarted,
                    testTag = "onboarding_get_started",
                    icon = Icons.AutoMirrored.Filled.ArrowForward,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                )
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

private data class WorkspaceShortcut(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val accent: Color,
    val route: String,
    val testTag: String
)

@Composable
fun DashboardScreen(
    settings: TdbSettingsState,
    connectionReport: ApiConnectionReport,
    isOnline: Boolean,
    recentLogs: List<ActionLogEntity>,
    onNavigate: (String) -> Unit,
    bottomPadding: PaddingValues
) {
    val workspaces = listOf(
        WorkspaceShortcut("Thumbnail Studio", "16:9 YouTube Canvas", Icons.Filled.PhotoLibrary, CrimsonPrimary, "thumbnail_studio", "dash_thumbnail"),
        WorkspaceShortcut("Video Creator", "Ideas, Scripts & SEO", Icons.Filled.Movie, ElectricAzure, "video_creator", "dash_video"),
        WorkspaceShortcut("Coding Assistant", "Code & File Engine", Icons.Filled.Code, Color(0xFF34D399), "coding_assistant", "dash_coding"),
        WorkspaceShortcut("Phone Automation", "Apps, Sensors & HUD", Icons.Filled.PhoneAndroid, Color(0xFFA78BFA), "automation", "dash_automation"),
        WorkspaceShortcut("File Manager", "SAF & Workspace", Icons.Filled.FolderOpen, Color(0xFFFBBF24), "file_manager", "dash_files"),
        WorkspaceShortcut("Task Scheduler", "Autonomous Planner", Icons.Filled.Schedule, CrimsonPrimary, "task_scheduler", "dash_tasks"),
        WorkspaceShortcut("YouTube Upload", "OAuth Data API v3", Icons.Filled.SmartDisplay, Color(0xFFEF4444), "youtube_automation", "dash_youtube"),
        WorkspaceShortcut("Memory Vault", "Context & Preferences", Icons.Filled.Memory, ElectricAzure, "memory_vault", "dash_memory")
    )

    val availabilityColor = when {
        !isOnline -> StatusRose
        connectionReport.status == ApiConnectionStatus.CONNECTED -> StatusGreen
        connectionReport.status == ApiConnectionStatus.NOT_CONFIGURED -> StatusAmber
        else -> ElectricAzure
    }
    val availabilityLabel = when {
        !isOnline -> "Offline Mode"
        connectionReport.status == ApiConnectionStatus.CONNECTED -> "AI Ready"
        connectionReport.status == ApiConnectionStatus.NOT_CONFIGURED -> "Add API Key"
        else -> connectionReport.status.label
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = 12.dp,
            bottom = bottomPadding.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header: Personalized greeting + Status + Bell/Settings
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(listOf(CrimsonPrimary, CobaltBlue))
                            )
                            .border(1.5.dp, Color.White.copy(alpha = 0.5f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "DB",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Hello, Deep!",
                            style = MaterialTheme.typography.headlineSmall,
                            color = TextPrimary
                        )
                        Text(
                            text = "${settings.personality.badge} • ${settings.primaryLanguage.nativeLabel}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IconButton(
                        onClick = { onNavigate("error_logs") },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.10f))
                            .border(1.dp, Color.White.copy(alpha = 0.18f), CircleShape)
                            .testTag("dash_notifications_btn")
                    ) {
                        Icon(Icons.Filled.Notifications, contentDescription = "Activity and Error Logs", tint = TextPrimary)
                    }
                    IconButton(
                        onClick = { onNavigate("profile_settings") },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.10f))
                            .border(1.dp, Color.White.copy(alpha = 0.18f), CircleShape)
                            .testTag("dash_settings_btn")
                    ) {
                        Icon(Icons.Filled.Settings, contentDescription = "Profile and Settings", tint = TextPrimary)
                    }
                }
            }
        }

        // Availability & Model Status Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TdbStatusPill(
                    label = availabilityLabel,
                    dotColor = availabilityColor,
                    modifier = Modifier.clickable { onNavigate("api_management") }
                )
                TdbStatusPill(
                    label = settings.selectedChatModelId.ifBlank { "No Model Selected" }.take(24),
                    dotColor = CobaltBlue,
                    modifier = Modifier.clickable { onNavigate("api_management") }
                )
            }
        }

        // Hero Glass Card with Animated AI Orb (matches mockup top card)
        item {
            TdbGlassCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 26.dp,
                tintColor = Color(0xFF1A1E34),
                borderGlow = CrimsonPrimary
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "TDB JARVIS Core",
                            style = MaterialTheme.typography.titleLarge,
                            color = TextPrimary
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "Bengali-first voice, vision, code & autonomous execution.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TdbGlowButton(
                                text = if (connectionReport.status == ApiConnectionStatus.CONNECTED) "Talk Now" else "Setup Key",
                                onClick = {
                                    if (connectionReport.status == ApiConnectionStatus.CONNECTED) {
                                        onNavigate("voice")
                                    } else {
                                        onNavigate("api_management")
                                    }
                                },
                                testTag = "dash_hero_cta",
                                icon = if (connectionReport.status == ApiConnectionStatus.CONNECTED) Icons.Filled.Mic else Icons.Filled.AutoAwesome
                            )
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                    TdbAnimatedAiOrb(
                        orbState = VoiceOrbState.IDLE,
                        size = 108.dp,
                        modifier = Modifier
                            .clip(CircleShape)
                            .clickable { onNavigate("voice") }
                    )
                }
            }
        }

        // Asymmetric Bento Grid ("Suggest for you" from reference image)
        item {
            TdbSectionHeader(
                title = "Suggest for you",
                actionLabel = "All tools",
                onActionClick = { onNavigate("studio_hub") }
            )
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(216.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Tall Left Glass Card: Voice Assistant
                TdbGlassCard(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .testTag("dash_voice_card"),
                    onClick = { onNavigate("voice") },
                    tintColor = Color(0xFF13223D),
                    borderGlow = ElectricAzure
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.14f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Mic, contentDescription = "Voice Assistant", tint = Color.White)
                        }
                        Text(
                            text = "Speak in বাংলা, English or हिन्दी seamlessly.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary
                        )
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.16f))
                                .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = "Start Voice",
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White
                            )
                        }
                    }
                }

                // Right Column: 2 stacked Glass Cards
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    TdbGlassCard(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .testTag("dash_image_card"),
                        onClick = { onNavigate("image_gen") },
                        tintColor = Color(0xFF281629),
                        borderGlow = CrimsonPrimary,
                        contentPadding = PaddingValues(14.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.14f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Outlined.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Create\nImage & Art",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = TextPrimary
                                )
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(18.dp))
                            }
                        }
                    }

                    TdbGlassCard(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .testTag("dash_chat_card"),
                        onClick = { onNavigate("chat") },
                        tintColor = Color(0xFF1A1E33),
                        contentPadding = PaddingValues(14.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.14f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Filled.ChatBubble, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Start new\nMessage",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = TextPrimary
                                )
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }

        // All TDB Workspaces Carousel
        item {
            TdbSectionHeader(
                title = "TDB Workspaces",
                actionLabel = "Control Hub",
                onActionClick = { onNavigate("control_hub") }
            )
            Spacer(Modifier.height(10.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(workspaces, key = { it.route }) { item ->
                    TdbGlassCard(
                        modifier = Modifier
                            .width(156.dp)
                            .testTag(item.testTag),
                        onClick = { onNavigate(item.route) },
                        borderGlow = item.accent,
                        contentPadding = PaddingValues(14.dp)
                    ) {
                        Column {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(item.accent.copy(alpha = 0.22f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(item.icon, contentDescription = item.title, tint = item.accent)
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = item.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // Recent History / Activity (matches bottom section of reference mockup)
        item {
            TdbSectionHeader(
                title = "Recent Activity",
                actionLabel = "See all",
                onActionClick = { onNavigate("error_logs") }
            )
        }

        if (recentLogs.isEmpty()) {
            item {
                TdbGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { onNavigate("chat") }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Outlined.History, contentDescription = null, tint = ElectricAzure)
                            Spacer(Modifier.width(12.dp))
                            Text(
                                text = "Ready for your first command — try AI Chat, Voice, or Coding Engine.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = TextSecondary)
                    }
                }
            }
        } else {
            items(recentLogs.take(4), key = { it.id }) { log ->
                TdbGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    cornerRadius = 18.dp,
                    contentPadding = PaddingValues(14.dp),
                    onClick = { onNavigate("error_logs") }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "[${log.category}] ${log.title}",
                                style = MaterialTheme.typography.labelLarge,
                                color = if (log.status == "ERROR") StatusRose else TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = log.details,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}
