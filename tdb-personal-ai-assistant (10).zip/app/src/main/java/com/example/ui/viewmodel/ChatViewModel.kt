package com.example.ui.viewmodel

import android.content.Context
import android.net.Uri
import android.util.Base64
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.AppContainer
import com.example.core.data.db.ChatMessageEntity
import com.example.core.data.db.ChatSessionEntity
import com.example.core.data.repository.TdbRepository
import com.example.core.error.ErrorRecoveryEngine
import com.example.core.network.ChatTurnInput
import com.example.core.network.GenerationOptions
import com.example.core.network.InlineAttachment
import com.example.core.network.StreamChunk
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

data class ChatUiState(
    val activeSessionId: Long? = null,
    val isStreaming: Boolean = false,
    val streamingText: String = "",
    val streamingReasoning: String = "",
    val pendingAttachment: InlineAttachment? = null,
    val searchQuery: String = "",
    val errorMessage: String? = null,
    val errorSuggestion: String? = null,
    val lastEngineUsed: String = ""
)

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(
    private val repository: TdbRepository
) : ViewModel() {

    val sessions: StateFlow<List<ChatSessionEntity>> = repository.sessionsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = emptyList()
    )

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    val activeMessages: StateFlow<List<ChatMessageEntity>> = _uiState
        .flatMapLatest { state ->
            val sid = state.activeSessionId
            if (sid == null) flowOf(emptyList()) else repository.observeMessages(sid)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val searchResults: StateFlow<List<ChatMessageEntity>> = _uiState
        .flatMapLatest { state ->
            if (state.searchQuery.isBlank()) flowOf(emptyList())
            else repository.searchMessages(state.searchQuery.trim())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private var activeJob: Job? = null

    init {
        viewModelScope.launch {
            val existing = repository.sessionsFlow.first()
            if (existing.isNotEmpty()) {
                _uiState.value = _uiState.value.copy(activeSessionId = existing.first().id)
            } else {
                createNewSession()
            }
        }
    }

    fun createNewSession(title: String = "New TDB Session") {
        viewModelScope.launch {
            val lang = repository.settingsFlow.first().primaryLanguage.code
            val newId = repository.createChatSession(title, lang)
            _uiState.value = _uiState.value.copy(
                activeSessionId = newId,
                errorMessage = null,
                streamingText = "",
                streamingReasoning = ""
            )
        }
    }

    fun selectSession(sessionId: Long) {
        _uiState.value = _uiState.value.copy(activeSessionId = sessionId, errorMessage = null)
    }

    fun deleteSession(sessionId: Long) {
        viewModelScope.launch {
            repository.deleteChatSession(sessionId)
            val remaining = repository.sessionsFlow.first()
            if (remaining.isEmpty()) {
                createNewSession()
            } else if (_uiState.value.activeSessionId == sessionId) {
                _uiState.value = _uiState.value.copy(activeSessionId = remaining.first().id)
            }
        }
    }

    fun updateSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }

    fun attachUri(context: Context, uri: Uri, fallbackMime: String) {
        viewModelScope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    val mime = context.contentResolver.getType(uri) ?: fallbackMime
                    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: error("Could not read selected file.")
                    require(bytes.size <= 16 * 1024 * 1024) {
                        "File exceeds 16 MB inline limit."
                    }
                    val label = uri.lastPathSegment?.substringAfterLast('/') ?: mime
                    InlineAttachment(
                        mimeType = mime,
                        base64Data = Base64.encodeToString(bytes, Base64.NO_WRAP),
                        label = label
                    )
                }
            }.onSuccess { att ->
                _uiState.value = _uiState.value.copy(pendingAttachment = att, errorMessage = null)
            }.onFailure { err ->
                _uiState.value = _uiState.value.copy(errorMessage = err.localizedMessage)
            }
        }
    }

    fun clearAttachment() {
        _uiState.value = _uiState.value.copy(pendingAttachment = null)
    }

    fun stopStreaming() {
        activeJob?.cancel()
        _uiState.value = _uiState.value.copy(isStreaming = false)
    }

    fun sendMessage(rawText: String, seedPrompt: String? = null) {
        val prompt = (seedPrompt ?: rawText).trim()
        val attachment = _uiState.value.pendingAttachment
        if (prompt.isBlank() && attachment == null) return

        activeJob?.cancel()
        activeJob = viewModelScope.launch {
            val settings = repository.settingsFlow.first()
            val sid = _uiState.value.activeSessionId
                ?: repository.createChatSession(prompt.take(36).ifBlank { "Attachment Chat" }, settings.primaryLanguage.code)

            val history = repository.getMessagesSnapshot(sid)
            if (history.isEmpty() && prompt.isNotBlank()) {
                repository.renameChatSession(sid, prompt.take(38))
            }

            repository.appendChatMessage(
                sessionId = sid,
                role = "user",
                content = prompt.ifBlank { "Analyze attached ${attachment?.label}" },
                attachmentLabel = attachment?.label
            )

            _uiState.value = _uiState.value.copy(
                activeSessionId = sid,
                isStreaming = true,
                streamingText = "",
                streamingReasoning = "",
                pendingAttachment = null,
                errorMessage = null,
                errorSuggestion = null
            )

            val apiKey = repository.getGeminiApiKey().orEmpty()
            val modelId = settings.selectedChatModelId
            if (apiKey.isBlank() || modelId.isBlank()) {
                _uiState.value = _uiState.value.copy(
                    isStreaming = false,
                    errorMessage = "Gemini API key or model is not configured yet.",
                    errorSuggestion = "Open Profile → Gemini API Management to enter your Gemini API key and discover available models."
                )
                return@launch
            }

            val textAcc = StringBuilder()
            val reasonAcc = StringBuilder()
            var engineName = ""

            try {
                val systemPrompt = repository.buildSystemPrompt(
                    extraRoleGuidance = if (settings.enableThinking) {
                        "Apply structured reasoning when solving complex coding, planning, or analytical requests."
                    } else ""
                )
                val historyInputs = history.map { ChatTurnInput(role = it.role, text = it.content) }

                withTimeout(90_000L) {
                    repository.geminiApi.streamChat(
                        apiKey = apiKey,
                        modelId = modelId,
                        systemInstruction = systemPrompt,
                        history = historyInputs,
                        currentUserMessage = prompt.ifBlank { "Analyze this attachment thoroughly." },
                        attachments = listOfNotNull(attachment),
                        options = GenerationOptions(
                            temperature = settings.temperature,
                            topP = settings.topP,
                            maxOutputTokens = settings.maxOutputTokens,
                            enableThinking = settings.enableThinking,
                            preferInteractionsApi = settings.preferInteractionsApi
                        )
                    ).collect { chunk ->
                        when (chunk) {
                            is StreamChunk.TextDelta -> {
                                textAcc.append(chunk.text)
                                _uiState.value = _uiState.value.copy(streamingText = textAcc.toString())
                            }
                            is StreamChunk.ReasoningDelta -> {
                                reasonAcc.append(chunk.text)
                                _uiState.value = _uiState.value.copy(streamingReasoning = reasonAcc.toString())
                            }
                            is StreamChunk.Completed -> {
                                engineName = chunk.engineUsed
                            }
                        }
                    }
                }

                val finalReply = textAcc.toString().trim()
                if (finalReply.isNotBlank()) {
                    repository.appendChatMessage(
                        sessionId = sid,
                        role = "model",
                        content = finalReply,
                        modelUsed = modelId,
                        reasoningSummary = reasonAcc.toString().takeIf { it.isNotBlank() }
                    )
                    repository.logAction("CHAT", "AI Response Verified", "Model: $modelId via $engineName", "SUCCESS")
                } else {
                    _uiState.value = _uiState.value.copy(
                        errorMessage = "Model returned an empty response.",
                        errorSuggestion = "Try rephrasing or testing another discovered model."
                    )
                }
                _uiState.value = _uiState.value.copy(
                    isStreaming = false,
                    streamingText = "",
                    streamingReasoning = "",
                    lastEngineUsed = engineName
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val diagnosis = ErrorRecoveryEngine.diagnose(e, "AI Chat")
                repository.logError("CHAT", "Chat Generation Failed", diagnosis)
                _uiState.value = _uiState.value.copy(
                    isStreaming = false,
                    errorMessage = diagnosis.userMessage,
                    errorSuggestion = diagnosis.recoverySuggestion
                )
            }
        }
    }

    fun saveMessageToMemory(content: String) {
        viewModelScope.launch {
            val res = repository.saveMemory(
                category = "CONTEXT",
                title = content.take(36).replace("\n", " "),
                content = content.take(350)
            )
            if (res.isFailure) {
                _uiState.value = _uiState.value.copy(
                    errorMessage = res.exceptionOrNull()?.localizedMessage
                )
            }
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null, errorSuggestion = null)
    }

    companion object {
        fun provideFactory(container: AppContainer): ViewModelProvider.Factory = viewModelFactory {
            initializer { ChatViewModel(container.repository) }
        }
    }
}
