package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val TdbDarkColorScheme = darkColorScheme(
    primary = CrimsonPrimary,
    onPrimary = Color.White,
    primaryContainer = CrimsonDeep,
    onPrimaryContainer = Color.White,
    secondary = CobaltBlue,
    onSecondary = Color.White,
    secondaryContainer = CobaltDeep,
    onSecondaryContainer = ElectricAzure,
    tertiary = ElectricAzure,
    onTertiary = ObsidianVoid,
    background = ObsidianVoid,
    onBackground = TextPrimary,
    surface = ObsidianSurface,
    onSurface = TextPrimary,
    surfaceVariant = ObsidianCard,
    onSurfaceVariant = TextSecondary,
    outline = Color.White.copy(alpha = 0.18f),
    error = StatusRose,
    onError = ObsidianVoid
)

val TdbShapes = Shapes(
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun TdbAssistantTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = TdbDarkColorScheme,
        typography = TdbTypography,
        shapes = TdbShapes,
        content = content
    )
}
