package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.data.TdbSettingsState
import com.example.ui.components.TdbGlassCard
import com.example.ui.components.TdbGlowButton
import com.example.ui.components.TdbStatusPill
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.ElectricAzure
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRose
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.StudioViewModel

@Composable
fun CodingAssistantScreen(
    studioViewModel: StudioViewModel,
    settings: TdbSettingsState,
    onBack: () -> Unit,
    bottomPadding: PaddingValues
) {
    val context = LocalContext.current
    val state by studioViewModel.codingState.collectAsStateWithLifecycle()

    val modes = listOf("Generate", "Edit", "Explain", "Debug", "Analyze")
    val languages = listOf("HTML/CSS/JS", "Kotlin", "Python", "Java", "JavaScript", "CSS")
    var selectedMode by remember { mutableStateOf("Generate") }
    var selectedLanguage by remember { mutableStateOf("HTML/CSS/JS") }
    var prompt by remember {
        mutableStateOf("Create a folder named TDB Project and create an index.html file inside it.")
    }
    var executeFileEngine by remember { mutableStateOf(true) }

    val safFolderLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
            studioViewModel.saveSafTreeUri(uri.toString())
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = bottomPadding.calculateBottomPadding() + 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { ScreenBackHeader("Advanced Coding Assistant", onBack) }

        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TdbStatusPill(
                            label = if (settings.safTreeUri.isNotBlank()) "SAF Directory Authorized" else "App Workspace Active",
                            dotColor = if (settings.safTreeUri.isNotBlank()) StatusGreen else ElectricAzure
                        )
                        OutlinedButton(onClick = { safFolderLauncher.launch(null) }) {
                            Icon(Icons.Filled.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Authorize Folder")
                        }
                    }
                    Text(
                        "Controlled File Engine writes safely to your SAF folder (if authorized) or app-scoped TDB_Workspace and verifies bytes on disk.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(modes) { m ->
                            FilterChip(selected = selectedMode == m, onClick = { selectedMode = m }, label = { Text(m) })
                        }
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(languages) { l ->
                            FilterChip(selected = selectedLanguage == l, onClick = { selectedLanguage = l }, label = { Text(l) })
                        }
                    }
                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        label = { Text("Coding or File Command") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth().testTag("coding_prompt_input"),
                        colors = darkFieldColors()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Execute File/Folder Creation", style = MaterialTheme.typography.labelLarge, color = TextPrimary)
                            Text("Parses folder/file targets, writes & verifies output", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                        Switch(checked = executeFileEngine, onCheckedChange = { executeFileEngine = it })
                    }
                    TdbGlowButton(
                        text = if (state.isBusy) "Running..." else "Execute $selectedMode",
                        onClick = { studioViewModel.runCodingTask(selectedMode, selectedLanguage, prompt, executeFileEngine) },
                        enabled = !state.isBusy && prompt.isNotBlank(),
                        icon = Icons.Filled.PlayArrow,
                        testTag = "coding_run_btn",
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        state.lastReceipt?.let { receipt ->
            item {
                TdbGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderGlow = if (receipt.verified) StatusGreen else StatusAmber
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = if (receipt.verified) "Verified File Operation" else "Verification Warning",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (receipt.verified) StatusGreen else StatusAmber
                        )
                        Text(receipt.summary, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                        Text("Scope: ${receipt.storageScope} • Path: ${receipt.filePath ?: receipt.folderPath}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                }
            }
        }

        if (!state.errorMessage.isNullOrBlank()) {
            item {
                TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = StatusRose) {
                    Text(state.errorMessage.orEmpty(), color = StatusRose)
                }
            }
        }

        if (state.outputCode.isNotBlank()) {
            item {
                TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = ElectricAzure) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = state.selectedFileName ?: "Code Preview ($selectedLanguage)",
                                style = MaterialTheme.typography.titleMedium,
                                color = ElectricAzure
                            )
                            IconButton(onClick = {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("TDB Code", state.outputCode))
                            }) {
                                Icon(Icons.Filled.ContentCopy, contentDescription = "Copy Code", tint = TextPrimary)
                            }
                        }
                        Text(
                            text = state.outputCode,
                            fontFamily = JetBrainsMonoFontFamily,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFE2E8F0),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF070B14))
                                .horizontalScroll(rememberScrollState())
                                .padding(12.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FileManagerScreen(
    studioViewModel: StudioViewModel,
    settings: TdbSettingsState,
    onBack: () -> Unit,
    bottomPadding: PaddingValues
) {
    val context = LocalContext.current
    val state by studioViewModel.codingState.collectAsStateWithLifecycle()
    var searchQuery by remember { mutableStateOf("") }
    var showCreateDialog by remember { mutableStateOf(false) }
    var newFolder by remember { mutableStateOf("TDB Project") }
    var newFile by remember { mutableStateOf("notes.txt") }
    var newContent by remember { mutableStateOf("Created by TDB Personal AI Assistant.") }

    val safFolderLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
            studioViewModel.saveSafTreeUri(uri.toString())
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = bottomPadding.calculateBottomPadding() + 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenBackHeader("TDB File Manager", onBack) }

        item {
            TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { safFolderLauncher.launch(null) }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("SAF Folder")
                        }
                        TdbGlowButton(
                            text = "New File",
                            onClick = { showCreateDialog = true },
                            icon = Icons.Filled.CreateNewFolder,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (settings.safTreeUri.isNotBlank()) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("External SAF Folder Linked", style = MaterialTheme.typography.labelSmall, color = StatusGreen)
                            TextButton(onClick = { studioViewModel.saveSafTreeUri("") }) {
                                Text("Revoke SAF", color = StatusRose)
                            }
                        }
                    }
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = {
                            searchQuery = it
                            studioViewModel.refreshWorkspaceFiles(it)
                        },
                        label = { Text("Search files & folders") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = darkFieldColors()
                    )
                }
            }
        }

        if (state.files.isEmpty()) {
            item {
                TdbGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "No files in workspace yet. Tap 'New File' or run a command in Coding Assistant.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            }
        } else {
            items(state.files, key = { "${it.storageScope}:${it.relativePath}" }) { entry ->
                TdbGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { studioViewModel.openWorkspaceFile(entry) },
                    contentPadding = PaddingValues(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                imageVector = if (entry.isDirectory) Icons.Filled.Folder else Icons.Filled.InsertDriveFile,
                                contentDescription = null,
                                tint = if (entry.isDirectory) ElectricAzure else CrimsonPrimary
                            )
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(entry.name, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                                Text(
                                    "${entry.relativePath} • ${entry.storageScope} • ${entry.sizeBytes} B",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextMuted
                                )
                            }
                        }
                        IconButton(onClick = { studioViewModel.deleteWorkspaceEntry(entry) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = StatusRose)
                        }
                    }
                }
            }
        }

        if (!state.selectedFileContent.isNullOrBlank()) {
            item {
                TdbGlassCard(modifier = Modifier.fillMaxWidth(), borderGlow = ElectricAzure) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Preview: ${state.selectedFileName}", style = MaterialTheme.typography.titleMedium, color = ElectricAzure)
                        Text(
                            text = state.selectedFileContent.orEmpty(),
                            fontFamily = JetBrainsMonoFontFamily,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary
                        )
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            containerColor = Color(0xFF10172B),
            title = { Text("Create Folder & File", color = TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = newFolder, onValueChange = { newFolder = it }, label = { Text("Folder Name") }, colors = darkFieldColors())
                    OutlinedTextField(value = newFile, onValueChange = { newFile = it }, label = { Text("File Name (optional)") }, colors = darkFieldColors())
                    OutlinedTextField(value = newContent, onValueChange = { newContent = it }, label = { Text("File Content") }, minLines = 3, colors = darkFieldColors())
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    studioViewModel.createManualFolderOrFile(newFolder, newFile, newContent)
                    showCreateDialog = false
                }) { Text("Create & Verify", color = ElectricAzure) }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancel", color = TextSecondary) }
            }
        )
    }
}
