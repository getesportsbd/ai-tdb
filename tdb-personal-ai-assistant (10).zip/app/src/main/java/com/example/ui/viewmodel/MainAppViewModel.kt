package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.AppContainer
import com.example.core.data.AiPersonality
import com.example.core.data.AppLanguage
import com.example.core.data.TdbSettingsState
import com.example.core.data.db.ActionLogEntity
import com.example.core.data.repository.TdbRepository
import com.example.core.network.ApiConnectionReport
import com.example.core.network.DiscoveredGeminiModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainAppViewModel(
    private val repository: TdbRepository
) : ViewModel() {

    val settings: StateFlow<TdbSettingsState> = repository.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = TdbSettingsState()
    )

    val discoveredModels: StateFlow<List<DiscoveredGeminiModel>> = repository.discoveredModels
    val connectionReport: StateFlow<ApiConnectionReport> = repository.connectionReport

    val recentLogs: StateFlow<List<ActionLogEntity>> = repository.recentLogsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = emptyList()
    )

    private val _isOnline = MutableStateFlow(repository.isOnline())
    val isOnline: StateFlow<Boolean> = _isOnline.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    init {
        viewModelScope.launch {
            val current = repository.settingsFlow.first()
            if (current.autoRefreshModels && repository.hasGeminiApiKey()) {
                val ageMs = System.currentTimeMillis() - current.lastModelsRefreshEpochMs
                if (ageMs > 5 * 60_000L || discoveredModels.value.isEmpty()) {
                    repository.refreshConnectionAndModels()
                }
            }
        }
    }

    fun refreshConnectivity() {
        _isOnline.value = repository.isOnline()
    }

    fun markOnboardingSeen() {
        viewModelScope.launch { repository.preferences.setHasSeenOnboarding(true) }
    }

    fun hasGeminiKey(): Boolean = repository.hasGeminiApiKey()
    fun getMaskedGeminiKey(): String = repository.getMaskedGeminiKey()
    fun revealGeminiKey(): String? = repository.getGeminiApiKey()

    fun saveAndTestGeminiKey(rawKey: String) {
        viewModelScope.launch {
            _isOnline.value = repository.isOnline()
            val result = repository.saveGeminiApiKey(rawKey)
            _statusBanner.value = result.fold(
                onSuccess = { it.message },
                onFailure = { it.localizedMessage ?: "Failed to verify API key." }
            )
        }
    }

    fun removeGeminiKey() {
        viewModelScope.launch {
            repository.removeGeminiApiKey()
            _statusBanner.value = "Gemini API key removed from Android Keystore."
        }
    }

    fun testAndDiscoverModels() {
        viewModelScope.launch {
            _isOnline.value = repository.isOnline()
            val result = repository.refreshConnectionAndModels()
            _statusBanner.value = result.fold(
                onSuccess = { it.message },
                onFailure = { it.localizedMessage ?: "Model discovery failed." }
            )
        }
    }

    fun selectChatModel(modelId: String) {
        viewModelScope.launch { repository.preferences.setSelectedChatModel(modelId) }
    }

    fun selectImageModel(modelId: String) {
        viewModelScope.launch { repository.preferences.setSelectedImageModel(modelId) }
    }

    fun updateGenerationSettings(
        preferInteractions: Boolean,
        autoRefresh: Boolean,
        temperature: Float,
        topP: Float,
        maxTokens: Int,
        enableThinking: Boolean
    ) {
        viewModelScope.launch {
            repository.preferences.updateGenerationSettings(
                preferInteractions, autoRefresh, temperature, topP, maxTokens, enableThinking
            )
            _statusBanner.value = "Generation settings saved."
        }
    }

    fun setPrimaryLanguage(language: AppLanguage) {
        viewModelScope.launch { repository.preferences.setPrimaryLanguage(language) }
    }

    fun setPersonality(personality: AiPersonality) {
        viewModelScope.launch { repository.preferences.setPersonality(personality) }
    }

    fun setMemoryEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.preferences.setMemoryEnabled(enabled) }
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.preferences.setNotificationsEnabled(enabled) }
    }

    fun setAutomationConfirmSensitive(confirm: Boolean) {
        viewModelScope.launch { repository.preferences.setAutomationConfirmSensitive(confirm) }
    }

    fun setGlowIntensity(intensity: Float) {
        viewModelScope.launch { repository.preferences.setGlowIntensity(intensity) }
    }

    fun clearBanner() {
        _statusBanner.value = null
    }

    companion object {
        fun provideFactory(container: AppContainer): ViewModelProvider.Factory = viewModelFactory {
            initializer { MainAppViewModel(container.repository) }
        }
    }
}
