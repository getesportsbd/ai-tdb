package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.example.automation.PhoneAutomationEngine
import com.example.automation.services.TdbFloatingAssistantService
import com.example.automation.services.TdbVoiceWakeService
import com.example.core.data.TdbPreferences
import com.example.core.data.db.TdbDatabase
import com.example.core.data.repository.TdbRepository
import com.example.core.files.ControlledFileEngine
import com.example.core.network.GeminiApiService
import com.example.core.security.KeystoreCryptoManager
import com.example.tasks.AutonomousTaskWorker
import com.example.tasks.TaskSchedulerManager
import com.example.voice.VoiceAssistantEngine
import com.example.youtube.YouTubeAutomationManager

class AppContainer(application: Application) {
    val database: TdbDatabase by lazy { TdbDatabase.getInstance(application) }
    val preferences: TdbPreferences by lazy { TdbPreferences(application) }
    val crypto: KeystoreCryptoManager by lazy { KeystoreCryptoManager(application) }
    val geminiApi: GeminiApiService by lazy { GeminiApiService() }
    val fileEngine: ControlledFileEngine by lazy { ControlledFileEngine(application) }
    val repository: TdbRepository by lazy {
        TdbRepository(application, database, preferences, crypto, geminiApi)
    }
    val taskScheduler: TaskSchedulerManager by lazy {
        TaskSchedulerManager(application, repository)
    }
    val automationEngine: PhoneAutomationEngine by lazy {
        PhoneAutomationEngine(application)
    }
    val voiceEngine: VoiceAssistantEngine by lazy {
        VoiceAssistantEngine(application)
    }
    val youTubeManager: YouTubeAutomationManager by lazy {
        YouTubeAutomationManager(application, crypto)
    }
}

class TdbApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java) ?: return
            val channels = listOf(
                NotificationChannel(
                    AutonomousTaskWorker.CHANNEL_ID,
                    getString(R.string.channel_tasks_name),
                    NotificationManager.IMPORTANCE_HIGH
                ).apply { description = getString(R.string.channel_tasks_desc) },
                NotificationChannel(
                    TdbVoiceWakeService.CHANNEL_ID,
                    getString(R.string.channel_voice_name),
                    NotificationManager.IMPORTANCE_LOW
                ).apply { description = getString(R.string.channel_voice_desc) },
                NotificationChannel(
                    TdbFloatingAssistantService.CHANNEL_ID,
                    getString(R.string.channel_automation_name),
                    NotificationManager.IMPORTANCE_LOW
                ).apply { description = getString(R.string.channel_automation_desc) }
            )
            nm.createNotificationChannels(channels)
        }
    }
}
