package com.example.core.network

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.example.core.error.ApiHttpException
import com.example.core.error.ErrorRecoveryEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

/**
 * Real Gemini API client using OkHttp.
 * - Never logs API keys or Authorization headers.
 * - Dynamically discovers models from /v1beta/models and verifies capabilities.
 * - Supports Gemini Interactions API (/v1beta/interactions) with automatic fallback
 *   to /v1beta/models/{model}:streamGenerateContent and generateContent.
 */
class GeminiApiService {

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun discoverModels(apiKey: String): List<DiscoveredGeminiModel> = withContext(Dispatchers.IO) {
        require(apiKey.isNotBlank()) { "Gemini API key is required to discover models." }
        ErrorRecoveryEngine.retrySafeOperation(maxAttempts = 2) {
            val request = Request.Builder()
                .url("$BASE_URL/models?pageSize=100")
                .addHeader("x-goog-api-key", apiKey.trim())
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw ApiHttpException(response.code, body, parseApiErrorMessage(body, response.message))
                }
                val root = JSONObject(body)
                val modelsArr = root.optJSONArray("models") ?: JSONArray()
                val result = mutableListOf<DiscoveredGeminiModel>()
                for (i in 0 until modelsArr.length()) {
                    val obj = modelsArr.getJSONObject(i)
                    val resourceName = obj.optString("name")
                    val id = resourceName.removePrefix("models/")
                    val methodsJson = obj.optJSONArray("supportedGenerationMethods") ?: JSONArray()
                    val methods = buildList {
                        for (j in 0 until methodsJson.length()) {
                            add(methodsJson.optString(j))
                        }
                    }
                    if (id.isNotBlank() && methods.isNotEmpty()) {
                        result += DiscoveredGeminiModel(
                            id = id,
                            resourceName = resourceName,
                            displayName = obj.optString("displayName").ifBlank { id },
                            description = obj.optString("description").orEmpty(),
                            supportedMethods = methods,
                            inputTokenLimit = obj.optInt("inputTokenLimit", 0),
                            outputTokenLimit = obj.optInt("outputTokenLimit", 0)
                        )
                    }
                }
                result.sortedByDescending {
                    when {
                        it.id.contains("flash", ignoreCase = true) && !it.id.contains("image", true) -> 3
                        it.id.contains("pro", ignoreCase = true) -> 2
                        else -> 1
                    }
                }
            }
        }
    }

    suspend fun testConnection(apiKey: String): ApiConnectionReport {
        if (apiKey.isBlank()) {
            return ApiConnectionReport(
                status = ApiConnectionStatus.NOT_CONFIGURED,
                message = "No Gemini API key configured yet."
            )
        }
        val start = System.currentTimeMillis()
        return try {
            val models = discoverModels(apiKey)
            val latency = System.currentTimeMillis() - start
            ApiConnectionReport(
                status = ApiConnectionStatus.CONNECTED,
                latencyMs = latency,
                discoveredModelsCount = models.size,
                message = "Connected cleanly. Discovered ${models.size} models in ${latency}ms."
            )
        } catch (e: ApiHttpException) {
            val status = if (e.code == 401 || e.code == 403 || e.code == 400) {
                ApiConnectionStatus.AUTH_FAILED
            } else {
                ApiConnectionStatus.OFFLINE_OR_ERROR
            }
            ApiConnectionReport(
                status = status,
                latencyMs = System.currentTimeMillis() - start,
                message = e.message ?: "Connection failed (${e.code})"
            )
        } catch (e: Exception) {
            ApiConnectionReport(
                status = ApiConnectionStatus.OFFLINE_OR_ERROR,
                latencyMs = System.currentTimeMillis() - start,
                message = e.localizedMessage ?: "Network failure"
            )
        }
    }

    fun streamChat(
        apiKey: String,
        modelId: String,
        systemInstruction: String,
        history: List<ChatTurnInput>,
        currentUserMessage: String,
        attachments: List<InlineAttachment>,
        options: GenerationOptions
    ): Flow<StreamChunk> = flow {
        require(apiKey.isNotBlank()) { "Please configure your Gemini API key in Profile → Gemini API Management." }
        require(modelId.isNotBlank()) { "Please select an available AI model in Profile → Gemini API Management." }

        val cleanModel = modelId.removePrefix("models/")

        // Prefer Interactions API for text/agent turns when enabled and no raw inline attachments
        if (options.preferInteractionsApi && attachments.isEmpty()) {
            val interactionsResult = tryInteractionsApi(
                apiKey = apiKey.trim(),
                modelId = cleanModel,
                systemInstruction = systemInstruction,
                history = history,
                currentUserMessage = currentUserMessage,
                options = options
            )
            if (interactionsResult != null) {
                emit(StreamChunk.TextDelta(interactionsResult))
                emit(StreamChunk.Completed("Interactions API (/v1beta/interactions)"))
                return@flow
            }
        }

        // Standard compatible SSE streaming endpoint (/v1beta/models/{model}:streamGenerateContent?alt=sse)
        val payload = buildGenerateContentPayload(
            systemInstruction = systemInstruction,
            history = history,
            currentUserMessage = currentUserMessage,
            attachments = attachments,
            options = options
        )
        val request = Request.Builder()
            .url("$BASE_URL/models/$cleanModel:streamGenerateContent?alt=sse")
            .addHeader("x-goog-api-key", apiKey.trim())
            .post(payload.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val errBody = response.body?.string().orEmpty()
                throw ApiHttpException(response.code, errBody, parseApiErrorMessage(errBody, response.message))
            }
            val bodyStream = response.body?.byteStream()
                ?: throw IllegalStateException("Empty stream body from Gemini API")

            BufferedReader(InputStreamReader(bodyStream, Charsets.UTF_8)).use { reader ->
                val dataBuffer = StringBuilder()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    val current = line!!
                    if (current.startsWith("data:")) {
                        dataBuffer.append(current.removePrefix("data:").trim())
                    } else if (current.isBlank() && dataBuffer.isNotEmpty()) {
                        val jsonStr = dataBuffer.toString()
                        dataBuffer.clear()
                        if (jsonStr != "[DONE]") {
                            parseCandidateParts(jsonStr).forEach { emit(it) }
                        }
                    }
                }
                if (dataBuffer.isNotEmpty()) {
                    val jsonStr = dataBuffer.toString()
                    if (jsonStr != "[DONE]") {
                        parseCandidateParts(jsonStr).forEach { emit(it) }
                    }
                }
            }
        }
        emit(StreamChunk.Completed("Gemini REST SSE ($cleanModel)"))
    }.flowOn(Dispatchers.IO)

    suspend fun generateText(
        apiKey: String,
        modelId: String,
        systemInstruction: String,
        prompt: String,
        options: GenerationOptions = GenerationOptions()
    ): String = withContext(Dispatchers.IO) {
        require(apiKey.isNotBlank()) { "Please configure your Gemini API key in Profile → Gemini API Management." }
        require(modelId.isNotBlank()) { "Please select an available AI model in Profile → Gemini API Management." }

        val cleanModel = modelId.removePrefix("models/")
        ErrorRecoveryEngine.retrySafeOperation(maxAttempts = 2) {
            if (options.preferInteractionsApi) {
                val interactionText = tryInteractionsApi(
                    apiKey = apiKey.trim(),
                    modelId = cleanModel,
                    systemInstruction = systemInstruction,
                    history = emptyList(),
                    currentUserMessage = prompt,
                    options = options
                )
                if (!interactionText.isNullOrBlank()) return@retrySafeOperation interactionText
            }

            val payload = buildGenerateContentPayload(
                systemInstruction = systemInstruction,
                history = emptyList(),
                currentUserMessage = prompt,
                attachments = emptyList(),
                options = options
            )
            val request = Request.Builder()
                .url("$BASE_URL/models/$cleanModel:generateContent")
                .addHeader("x-goog-api-key", apiKey.trim())
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw ApiHttpException(response.code, body, parseApiErrorMessage(body, response.message))
                }
                extractAllText(body).ifBlank {
                    throw IllegalStateException("Model returned an empty text response.")
                }
            }
        }
    }

    suspend fun generateOrEditImage(
        apiKey: String,
        model: DiscoveredGeminiModel,
        prompt: String,
        inputBitmapBytes: ByteArray? = null,
        inputMimeType: String = "image/jpeg",
        aspectRatio: String = "1:1"
    ): Bitmap = withContext(Dispatchers.IO) {
        require(apiKey.isNotBlank()) { "Please configure your Gemini API key in Profile → Gemini API Management." }
        require(model.supportsImageOutput) {
            "Selected model '${model.displayName}' is text-only and cannot generate images. Choose an image-capable model discovered in API Management."
        }

        val cleanModel = model.id.removePrefix("models/")
        if (model.supportsPredictOnly) {
            val payload = JSONObject().apply {
                put("instances", JSONArray().put(JSONObject().put("prompt", prompt)))
                put("parameters", JSONObject().apply {
                    put("sampleCount", 1)
                    put("aspectRatio", aspectRatio)
                })
            }
            val request = Request.Builder()
                .url("$BASE_URL/models/$cleanModel:predict")
                .addHeader("x-goog-api-key", apiKey.trim())
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw ApiHttpException(response.code, body, parseApiErrorMessage(body, response.message))
                }
                val predictions = JSONObject(body).optJSONArray("predictions")
                    ?: throw IllegalStateException("No image predictions returned.")
                val b64 = predictions.getJSONObject(0).optString("bytesBase64Encoded")
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    ?: throw IllegalStateException("Failed to decode generated image bitmap.")
            }
        } else {
            val parts = JSONArray()
            if (inputBitmapBytes != null) {
                parts.put(JSONObject().apply {
                    put("inlineData", JSONObject().apply {
                        put("mimeType", inputMimeType)
                        put("data", Base64.encodeToString(inputBitmapBytes, Base64.NO_WRAP))
                    })
                })
            }
            parts.put(JSONObject().put("text", prompt))

            val payload = JSONObject().apply {
                put("contents", JSONArray().put(JSONObject().apply {
                    put("role", "user")
                    put("parts", parts)
                }))
                put("generationConfig", JSONObject().apply {
                    put("responseModalities", JSONArray().put("IMAGE").put("TEXT"))
                    put("imageConfig", JSONObject().put("aspectRatio", aspectRatio))
                })
            }
            val request = Request.Builder()
                .url("$BASE_URL/models/$cleanModel:generateContent")
                .addHeader("x-goog-api-key", apiKey.trim())
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw ApiHttpException(response.code, body, parseApiErrorMessage(body, response.message))
                }
                val root = JSONObject(body)
                val candidates = root.optJSONArray("candidates") ?: JSONArray()
                for (c in 0 until candidates.length()) {
                    val candParts = candidates.getJSONObject(c)
                        .optJSONObject("content")
                        ?.optJSONArray("parts") ?: continue
                    for (p in 0 until candParts.length()) {
                        val inlineData = candParts.getJSONObject(p).optJSONObject("inlineData")
                        if (inlineData != null) {
                            val b64 = inlineData.optString("data")
                            if (b64.isNotBlank()) {
                                val bytes = Base64.decode(b64, Base64.DEFAULT)
                                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                if (bmp != null) return@withContext bmp
                            }
                        }
                    }
                }
                val fallbackMsg = extractAllText(body)
                throw IllegalStateException(
                    fallbackMsg.ifBlank { "Model did not return image bytes. Try a dedicated image-generation model." }
                )
            }
        }
    }

    private fun tryInteractionsApi(
        apiKey: String,
        modelId: String,
        systemInstruction: String,
        history: List<ChatTurnInput>,
        currentUserMessage: String,
        options: GenerationOptions
    ): String? {
        return try {
            val formattedInput = buildString {
                if (history.isNotEmpty()) {
                    appendLine("Conversation Context:")
                    history.takeLast(8).forEach { turn ->
                        appendLine("${turn.role.uppercase()}: ${turn.text}")
                    }
                    appendLine()
                }
                append("USER: $currentUserMessage")
            }

            val payload = JSONObject().apply {
                put("model", modelId)
                put("input", formattedInput)
                if (systemInstruction.isNotBlank()) {
                    put("system_instruction", systemInstruction)
                }
                put("generation_config", JSONObject().apply {
                    put("temperature", options.temperature.toDouble())
                    put("top_p", options.topP.toDouble())
                    put("max_output_tokens", options.maxOutputTokens)
                })
            }

            val request = Request.Builder()
                .url("$BASE_URL/interactions")
                .addHeader("x-goog-api-key", apiKey)
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    // Fall back seamlessly to standard generateContent/streamGenerateContent if endpoint/model doesn't accept Interactions payload
                    return null
                }
                val json = JSONObject(body)
                val outputs = json.optJSONArray("outputs")
                if (outputs != null && outputs.length() > 0) {
                    val sb = StringBuilder()
                    for (i in 0 until outputs.length()) {
                        val item = outputs.optJSONObject(i)
                        val text = item?.optString("text").orEmpty()
                        if (text.isNotBlank()) sb.append(text)
                    }
                    sb.toString().takeIf { it.isNotBlank() }
                } else {
                    json.optString("text").takeIf { it.isNotBlank() }
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun buildGenerateContentPayload(
        systemInstruction: String,
        history: List<ChatTurnInput>,
        currentUserMessage: String,
        attachments: List<InlineAttachment>,
        options: GenerationOptions
    ): JSONObject {
        val contents = JSONArray()
        history.takeLast(14).forEach { turn ->
            contents.put(JSONObject().apply {
                put("role", if (turn.role == "model") "model" else "user")
                put("parts", JSONArray().put(JSONObject().put("text", turn.text)))
            })
        }
        val currentParts = JSONArray()
        attachments.forEach { attachment ->
            currentParts.put(JSONObject().apply {
                put("inlineData", JSONObject().apply {
                    put("mimeType", attachment.mimeType)
                    put("data", attachment.base64Data)
                })
            })
        }
        currentParts.put(JSONObject().put("text", currentUserMessage))
        contents.put(JSONObject().apply {
            put("role", "user")
            put("parts", currentParts)
        })

        return JSONObject().apply {
            if (systemInstruction.isNotBlank()) {
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
                })
            }
            put("contents", contents)
            put("generationConfig", JSONObject().apply {
                put("temperature", options.temperature.toDouble())
                put("topP", options.topP.toDouble())
                put("maxOutputTokens", options.maxOutputTokens)
            })
        }
    }

    private fun parseCandidateParts(jsonStr: String): List<StreamChunk> {
        val out = mutableListOf<StreamChunk>()
        runCatching {
            val root = JSONObject(jsonStr)
            val candidates = root.optJSONArray("candidates") ?: return@runCatching
            for (i in 0 until candidates.length()) {
                val parts = candidates.getJSONObject(i)
                    .optJSONObject("content")
                    ?.optJSONArray("parts") ?: continue
                for (j in 0 until parts.length()) {
                    val part = parts.getJSONObject(j)
                    val text = part.optString("text")
                    if (text.isNotEmpty()) {
                        if (part.optBoolean("thought", false)) {
                            out += StreamChunk.ReasoningDelta(text)
                        } else {
                            out += StreamChunk.TextDelta(text)
                        }
                    }
                }
            }
        }
        return out
    }

    private fun extractAllText(body: String): String {
        val sb = StringBuilder()
        runCatching {
            val root = JSONObject(body)
            val candidates = root.optJSONArray("candidates") ?: return@runCatching
            for (i in 0 until candidates.length()) {
                val parts = candidates.getJSONObject(i)
                    .optJSONObject("content")
                    ?.optJSONArray("parts") ?: continue
                for (j in 0 until parts.length()) {
                    val part = parts.getJSONObject(j)
                    if (!part.optBoolean("thought", false)) {
                        sb.append(part.optString("text"))
                    }
                }
            }
        }
        return sb.toString()
    }

    private fun parseApiErrorMessage(rawBody: String, fallback: String): String {
        return runCatching {
            JSONObject(rawBody).optJSONObject("error")?.optString("message")?.takeIf { it.isNotBlank() }
        }.getOrNull() ?: fallback.ifBlank { "Gemini API error" }
    }

    companion object {
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta"
    }
}
