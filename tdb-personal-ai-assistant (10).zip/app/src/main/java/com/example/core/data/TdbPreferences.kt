package com.example.core.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.tdbDataStore: DataStore<Preferences> by preferencesDataStore(name = "tdb_settings")

enum class AppLanguage(val code: String, val displayName: String, val nativeLabel: String, val localeTag: String) {
    BENGALI("bn", "Bengali", "বাংলা", "bn-IN"),
    ENGLISH("en", "English", "English", "en-US"),
    HINDI("hi", "Hindi", "हिन्दी", "hi-IN")
}

enum class AiPersonality(val id: String, val title: String, val badge: String, val instruction: String) {
    JARVIS_TACTICAL(
        id = "jarvis",
        title = "JARVIS Tactical",
        badge = "TDB Core • Tactical",
        instruction = "Be sharp, strategic, proactive, and action-oriented like an executive JARVIS AI operating assistant."
    ),
    CREATOR_PRO(
        id = "creator",
        title = "YouTube & Creative Pro",
        badge = "Creator • Vlog Mode",
        instruction = "Think like a top-tier YouTube strategist and storytelling director for Deep Barmon Bhai Vlog."
    ),
    DEV_ARCHITECT(
        id = "architect",
        title = "Code Architect",
        badge = "Dev • Precision",
        instruction = "Deliver clean, production-grade code, precise debugging steps, and safe file operation plans."
    ),
    FRIENDLY_COMPANION(
        id = "companion",
        title = "Warm Personal Guide",
        badge = "Friendly • Everyday",
        instruction = "Be warm, conversational, clear, and deeply helpful in everyday life and productivity."
    )
}

enum class VoiceGenderOption(val label: String) {
    AUTO("System Default"),
    FEMALE("Female"),
    MALE("Male")
}

data class TdbSettingsState(
    val hasSeenOnboarding: Boolean = false,
    val selectedChatModelId: String = "",
    val selectedImageModelId: String = "",
    val preferInteractionsApi: Boolean = true,
    val autoRefreshModels: Boolean = true,
    val temperature: Float = 0.7f,
    val topP: Float = 0.95f,
    val maxOutputTokens: Int = 2048,
    val enableThinking: Boolean = true,
    val primaryLanguage: AppLanguage = AppLanguage.BENGALI,
    val personality: AiPersonality = AiPersonality.JARVIS_TACTICAL,
    val voiceSpeed: Float = 1.0f,
    val voiceGender: VoiceGenderOption = VoiceGenderOption.AUTO,
    val wakePhrase: String = "Hey TDB",
    val continuousVoice: Boolean = true,
    val backgroundWakeEnabled: Boolean = false,
    val memoryEnabled: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val automationConfirmSensitive: Boolean = true,
    val glowIntensity: Float = 0.85f,
    val safTreeUri: String = "",
    val youtubeClientId: String = "",
    val youtubeChannelName: String = "",
    val youtubeChannelId: String = "",
    val lastModelsRefreshEpochMs: Long = 0L
)

class TdbPreferences(private val context: Context) {

    private object Keys {
        val HAS_SEEN_ONBOARDING = booleanPreferencesKey("has_seen_onboarding")
        val SELECTED_CHAT_MODEL = stringPreferencesKey("selected_chat_model")
        val SELECTED_IMAGE_MODEL = stringPreferencesKey("selected_image_model")
        val PREFER_INTERACTIONS = booleanPreferencesKey("prefer_interactions_api")
        val AUTO_REFRESH_MODELS = booleanPreferencesKey("auto_refresh_models")
        val TEMPERATURE = floatPreferencesKey("temperature")
        val TOP_P = floatPreferencesKey("top_p")
        val MAX_OUTPUT_TOKENS = intPreferencesKey("max_output_tokens")
        val ENABLE_THINKING = booleanPreferencesKey("enable_thinking")
        val PRIMARY_LANGUAGE = stringPreferencesKey("primary_language")
        val PERSONALITY = stringPreferencesKey("personality")
        val VOICE_SPEED = floatPreferencesKey("voice_speed")
        val VOICE_GENDER = stringPreferencesKey("voice_gender")
        val WAKE_PHRASE = stringPreferencesKey("wake_phrase")
        val CONTINUOUS_VOICE = booleanPreferencesKey("continuous_voice")
        val BACKGROUND_WAKE = booleanPreferencesKey("background_wake_enabled")
        val MEMORY_ENABLED = booleanPreferencesKey("memory_enabled")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val AUTOMATION_CONFIRM = booleanPreferencesKey("automation_confirm_sensitive")
        val GLOW_INTENSITY = floatPreferencesKey("glow_intensity")
        val SAF_TREE_URI = stringPreferencesKey("saf_tree_uri")
        val YOUTUBE_CLIENT_ID = stringPreferencesKey("youtube_client_id")
        val YOUTUBE_CHANNEL_NAME = stringPreferencesKey("youtube_channel_name")
        val YOUTUBE_CHANNEL_ID = stringPreferencesKey("youtube_channel_id")
        val LAST_MODELS_REFRESH = stringPreferencesKey("last_models_refresh")
    }

    val settingsFlow: Flow<TdbSettingsState> = context.tdbDataStore.data.map { prefs ->
        TdbSettingsState(
            hasSeenOnboarding = prefs[Keys.HAS_SEEN_ONBOARDING] ?: false,
            selectedChatModelId = prefs[Keys.SELECTED_CHAT_MODEL].orEmpty(),
            selectedImageModelId = prefs[Keys.SELECTED_IMAGE_MODEL].orEmpty(),
            preferInteractionsApi = prefs[Keys.PREFER_INTERACTIONS] ?: true,
            autoRefreshModels = prefs[Keys.AUTO_REFRESH_MODELS] ?: true,
            temperature = prefs[Keys.TEMPERATURE] ?: 0.7f,
            topP = prefs[Keys.TOP_P] ?: 0.95f,
            maxOutputTokens = prefs[Keys.MAX_OUTPUT_TOKENS] ?: 2048,
            enableThinking = prefs[Keys.ENABLE_THINKING] ?: true,
            primaryLanguage = AppLanguage.entries.firstOrNull {
                it.code == prefs[Keys.PRIMARY_LANGUAGE]
            } ?: AppLanguage.BENGALI,
            personality = AiPersonality.entries.firstOrNull {
                it.id == prefs[Keys.PERSONALITY]
            } ?: AiPersonality.JARVIS_TACTICAL,
            voiceSpeed = prefs[Keys.VOICE_SPEED] ?: 1.0f,
            voiceGender = VoiceGenderOption.entries.firstOrNull {
                it.name == prefs[Keys.VOICE_GENDER]
            } ?: VoiceGenderOption.AUTO,
            wakePhrase = prefs[Keys.WAKE_PHRASE] ?: "Hey TDB",
            continuousVoice = prefs[Keys.CONTINUOUS_VOICE] ?: true,
            backgroundWakeEnabled = prefs[Keys.BACKGROUND_WAKE] ?: false,
            memoryEnabled = prefs[Keys.MEMORY_ENABLED] ?: true,
            notificationsEnabled = prefs[Keys.NOTIFICATIONS_ENABLED] ?: true,
            automationConfirmSensitive = prefs[Keys.AUTOMATION_CONFIRM] ?: true,
            glowIntensity = prefs[Keys.GLOW_INTENSITY] ?: 0.85f,
            safTreeUri = prefs[Keys.SAF_TREE_URI].orEmpty(),
            youtubeClientId = prefs[Keys.YOUTUBE_CLIENT_ID].orEmpty(),
            youtubeChannelName = prefs[Keys.YOUTUBE_CHANNEL_NAME].orEmpty(),
            youtubeChannelId = prefs[Keys.YOUTUBE_CHANNEL_ID].orEmpty(),
            lastModelsRefreshEpochMs = prefs[Keys.LAST_MODELS_REFRESH]?.toLongOrNull() ?: 0L
        )
    }

    suspend fun setHasSeenOnboarding(seen: Boolean) {
        context.tdbDataStore.edit { it[Keys.HAS_SEEN_ONBOARDING] = seen }
    }

    suspend fun setSelectedChatModel(modelId: String) {
        context.tdbDataStore.edit { it[Keys.SELECTED_CHAT_MODEL] = modelId }
    }

    suspend fun setSelectedImageModel(modelId: String) {
        context.tdbDataStore.edit { it[Keys.SELECTED_IMAGE_MODEL] = modelId }
    }

    suspend fun updateGenerationSettings(
        preferInteractions: Boolean,
        autoRefresh: Boolean,
        temperature: Float,
        topP: Float,
        maxTokens: Int,
        enableThinking: Boolean
    ) {
        context.tdbDataStore.edit {
            it[Keys.PREFER_INTERACTIONS] = preferInteractions
            it[Keys.AUTO_REFRESH_MODELS] = autoRefresh
            it[Keys.TEMPERATURE] = temperature.coerceIn(0f, 2f)
            it[Keys.TOP_P] = topP.coerceIn(0.1f, 1f)
            it[Keys.MAX_OUTPUT_TOKENS] = maxTokens.coerceIn(256, 8192)
            it[Keys.ENABLE_THINKING] = enableThinking
        }
    }

    suspend fun setPrimaryLanguage(language: AppLanguage) {
        context.tdbDataStore.edit { it[Keys.PRIMARY_LANGUAGE] = language.code }
    }

    suspend fun setPersonality(personality: AiPersonality) {
        context.tdbDataStore.edit { it[Keys.PERSONALITY] = personality.id }
    }

    suspend fun updateVoiceSettings(
        speed: Float,
        gender: VoiceGenderOption,
        wakePhrase: String,
        continuous: Boolean,
        backgroundWake: Boolean
    ) {
        context.tdbDataStore.edit {
            it[Keys.VOICE_SPEED] = speed.coerceIn(0.5f, 2.0f)
            it[Keys.VOICE_GENDER] = gender.name
            it[Keys.WAKE_PHRASE] = wakePhrase
            it[Keys.CONTINUOUS_VOICE] = continuous
            it[Keys.BACKGROUND_WAKE] = backgroundWake
        }
    }

    suspend fun setMemoryEnabled(enabled: Boolean) {
        context.tdbDataStore.edit { it[Keys.MEMORY_ENABLED] = enabled }
    }

    suspend fun setNotificationsEnabled(enabled: Boolean) {
        context.tdbDataStore.edit { it[Keys.NOTIFICATIONS_ENABLED] = enabled }
    }

    suspend fun setAutomationConfirmSensitive(confirm: Boolean) {
        context.tdbDataStore.edit { it[Keys.AUTOMATION_CONFIRM] = confirm }
    }

    suspend fun setGlowIntensity(intensity: Float) {
        context.tdbDataStore.edit { it[Keys.GLOW_INTENSITY] = intensity.coerceIn(0.2f, 1f) }
    }

    suspend fun setSafTreeUri(uri: String) {
        context.tdbDataStore.edit { it[Keys.SAF_TREE_URI] = uri }
    }

    suspend fun setYouTubeConfig(clientId: String, channelId: String, channelName: String) {
        context.tdbDataStore.edit {
            it[Keys.YOUTUBE_CLIENT_ID] = clientId
            it[Keys.YOUTUBE_CHANNEL_ID] = channelId
            it[Keys.YOUTUBE_CHANNEL_NAME] = channelName
        }
    }

    suspend fun setLastModelsRefresh(timestampMs: Long) {
        context.tdbDataStore.edit { it[Keys.LAST_MODELS_REFRESH] = timestampMs.toString() }
    }
}
