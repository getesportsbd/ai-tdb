package com.example.core.error

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import java.io.FileNotFoundException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

data class ErrorDiagnosis(
    val userMessage: String,
    val causeSummary: String,
    val recoverySuggestion: String,
    val isRetryable: Boolean,
    val requiresUserPermission: Boolean = false
)

class ApiHttpException(val code: Int, val rawBody: String, message: String) : Exception(message)

object ErrorRecoveryEngine {

    fun diagnose(throwable: Throwable, contextLabel: String): ErrorDiagnosis {
        return when (throwable) {
            is ApiHttpException -> when (throwable.code) {
                400 -> ErrorDiagnosis(
                    userMessage = "Invalid request parameters for $contextLabel.",
                    causeSummary = "HTTP 400 Bad Request: ${throwable.message}",
                    recoverySuggestion = "Verify the selected model supports this modality or adjust generation settings in API Management.",
                    isRetryable = false
                )
                401, 403 -> ErrorDiagnosis(
                    userMessage = "Gemini API authentication failed (HTTP ${throwable.code}).",
                    causeSummary = "API key rejected or missing required scope.",
                    recoverySuggestion = "Open Profile → Gemini API Management, verify your Gemini API key, and run Test Connection.",
                    isRetryable = false,
                    requiresUserPermission = true
                )
                404 -> ErrorDiagnosis(
                    userMessage = "Selected model or endpoint was not found (HTTP 404).",
                    causeSummary = "Model ID may be unavailable for this API key.",
                    recoverySuggestion = "Tap Refresh Models in Gemini API Management to discover currently available models.",
                    isRetryable = false
                )
                429 -> ErrorDiagnosis(
                    userMessage = "Rate limit or quota reached (HTTP 429).",
                    causeSummary = "Too many requests in a short window.",
                    recoverySuggestion = "Wait a few seconds before retrying or switch to a lighter discovered Flash model.",
                    isRetryable = true
                )
                in 500..599 -> ErrorDiagnosis(
                    userMessage = "Gemini service is temporarily unavailable (HTTP ${throwable.code}).",
                    causeSummary = "Upstream server error.",
                    recoverySuggestion = "Safe automatic retry will attempt recovery; if it persists, retry shortly.",
                    isRetryable = true
                )
                else -> ErrorDiagnosis(
                    userMessage = "API error (HTTP ${throwable.code}): ${throwable.message}",
                    causeSummary = "Unexpected HTTP status ${throwable.code}.",
                    recoverySuggestion = "Review Action Logs and test connection in Gemini API Management.",
                    isRetryable = false
                )
            }
            is UnknownHostException -> ErrorDiagnosis(
                userMessage = "You appear to be offline or DNS cannot reach Google APIs.",
                causeSummary = "No internet connectivity (UnknownHostException).",
                recoverySuggestion = "Check Wi-Fi or mobile data, then tap Retry.",
                isRetryable = true
            )
            is SocketTimeoutException -> ErrorDiagnosis(
                userMessage = "Request timed out while waiting for AI response.",
                causeSummary = "Network or model latency exceeded timeout.",
                recoverySuggestion = "Retry with a shorter prompt or check your network stability.",
                isRetryable = true
            )
            is SecurityException -> ErrorDiagnosis(
                userMessage = "Permission required to perform $contextLabel.",
                causeSummary = "Android security restriction: ${throwable.localizedMessage}",
                recoverySuggestion = "Grant the required permission in Permission Center and try again.",
                isRetryable = false,
                requiresUserPermission = true
            )
            is FileNotFoundException -> ErrorDiagnosis(
                userMessage = "Target file or directory could not be accessed.",
                causeSummary = "Missing file or revoked SAF folder grant.",
                recoverySuggestion = "Re-authorize the project directory in File Manager / Permission Center.",
                isRetryable = false,
                requiresUserPermission = true
            )
            else -> ErrorDiagnosis(
                userMessage = throwable.localizedMessage ?: "Operation failed in $contextLabel.",
                causeSummary = "${throwable::class.simpleName}: ${throwable.message.orEmpty()}",
                recoverySuggestion = "Review details in Error Logs and retry the action.",
                isRetryable = false
            )
        }
    }

    suspend fun <T> retrySafeOperation(
        maxAttempts: Int = 2,
        initialDelayMs: Long = 1000L,
        block: suspend (attempt: Int) -> T
    ): T {
        var lastError: Throwable? = null
        for (attempt in 1..maxAttempts) {
            try {
                return block(attempt)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastError = e
                val diagnosis = diagnose(e, "retryable operation")
                if (!diagnosis.isRetryable || attempt == maxAttempts) {
                    throw e
                }
                delay(initialDelayMs * attempt)
            }
        }
        throw lastError ?: IllegalStateException("Operation failed after $maxAttempts attempts")
    }
}
