package com.example.core.files

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileNotFoundException

data class ManagedFileEntry(
    val name: String,
    val relativePath: String,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val lastModifiedMs: Long,
    val storageScope: String, // "SAF_AUTHORIZED" or "APP_WORKSPACE"
    val uriString: String? = null
)

data class FileCommandPlan(
    val folderName: String?,
    val fileName: String?,
    val languageHint: String,
    val description: String
)

data class FileExecutionReceipt(
    val folderPath: String,
    val filePath: String?,
    val verified: Boolean,
    val bytesWritten: Long,
    val storageScope: String,
    val summary: String
)

/**
 * Controlled file operation engine supporting:
 * 1. Storage Access Framework (SAF) user-authorized external directories
 * 2. App-scoped TDB_Workspace sandbox directory (zero extra permission)
 * Always verifies written bytes & existence before reporting success.
 */
class ControlledFileEngine(private val context: Context) {

    private val appWorkspaceRoot: File
        get() = File(context.filesDir, "TDB_Workspace").apply { if (!exists()) mkdirs() }

    fun getAppWorkspacePath(): String = appWorkspaceRoot.absolutePath

    fun parseNaturalCommand(command: String): FileCommandPlan = parseNaturalCommandStatic(command)

    companion object {
        fun parseNaturalCommandStatic(command: String): FileCommandPlan {
            val quotedFolderRegex = Regex(
                """(?:folder|directory)\s+(?:named|called)?\s*["']([^"']{1,48})["']""",
                RegexOption.IGNORE_CASE
            )
            val unquotedFolderRegex = Regex(
                """(?:folder|directory)\s+(?:named|called)?\s*([A-Za-z0-9_\- ]{1,48}?)(?=\s+(?:and|with|containing|to|then|create|make|file)\b|[.,;!?]|$)""",
                RegexOption.IGNORE_CASE
            )
            val fileRegex = Regex(
                """(?:file)\s+(?:named|called)?\s*["']?([A-Za-z0-9_.\-]{1,64}\.[a-zA-Z0-9]{1,8})["']?""",
                RegexOption.IGNORE_CASE
            )
            val bareFileRegex = Regex(
                """\b([A-Za-z0-9_\-]+\.(?:html|css|js|kt|java|py|json|md|txt|xml))\b""",
                RegexOption.IGNORE_CASE
            )

            val folder = (quotedFolderRegex.find(command)?.groupValues?.getOrNull(1)
                ?: unquotedFolderRegex.find(command)?.groupValues?.getOrNull(1))
                ?.trim()
            val file = fileRegex.find(command)?.groupValues?.getOrNull(1)?.trim()
                ?: bareFileRegex.find(command)?.groupValues?.getOrNull(1)?.trim()

            val ext = file?.substringAfterLast('.', "")?.lowercase().orEmpty()
            val lang = when (ext) {
                "html" -> "HTML"
                "css" -> "CSS"
                "js" -> "JavaScript"
                "kt" -> "Kotlin"
                "java" -> "Java"
                "py" -> "Python"
                "json" -> "JSON"
                "md" -> "Markdown"
                else -> "Text"
            }
            return FileCommandPlan(
                folderName = folder,
                fileName = file,
                languageHint = lang,
                description = buildString {
                    if (!folder.isNullOrBlank()) append("Create folder '$folder'")
                    if (!file.isNullOrBlank()) {
                        if (isNotEmpty()) append(" and ")
                        append("write $lang file '$file'")
                    }
                    if (isEmpty()) append("Create workspace file")
                }
            )
        }
    }

    suspend fun listFiles(safTreeUriString: String, query: String = ""): List<ManagedFileEntry> = withContext(Dispatchers.IO) {
        val results = mutableListOf<ManagedFileEntry>()
        // 1. App workspace files
        walkLocalDirectory(appWorkspaceRoot, "", results)

        // 2. SAF authorized directory if granted
        if (safTreeUriString.isNotBlank()) {
            runCatching {
                val uri = Uri.parse(safTreeUriString)
                val rootDoc = DocumentFile.fromTreeUri(context, uri)
                if (rootDoc != null && rootDoc.canRead()) {
                    walkSafDirectory(rootDoc, "", results)
                }
            }
        }

        if (query.isBlank()) results
        else results.filter {
            it.name.contains(query, ignoreCase = true) || it.relativePath.contains(query, ignoreCase = true)
        }
    }

    suspend fun createFolderAndFile(
        safTreeUriString: String,
        folderName: String?,
        fileName: String?,
        fileContent: String?
    ): FileExecutionReceipt = withContext(Dispatchers.IO) {
        val sanitizedFolder = folderName?.trim()?.replace(Regex("""[\\/:*?"<>|]"""), "_")
        val sanitizedFile = fileName?.trim()?.replace(Regex("""[\\/:*?"<>|]"""), "_")

        if (safTreeUriString.isNotBlank()) {
            val treeUri = Uri.parse(safTreeUriString)
            val rootDoc = DocumentFile.fromTreeUri(context, treeUri)
            if (rootDoc != null && rootDoc.canWrite()) {
                val targetDir = if (!sanitizedFolder.isNullOrBlank()) {
                    rootDoc.findFile(sanitizedFolder)?.takeIf { it.isDirectory }
                        ?: rootDoc.createDirectory(sanitizedFolder)
                        ?: throw IllegalStateException("Failed to create SAF folder '$sanitizedFolder'.")
                } else {
                    rootDoc
                }

                if (sanitizedFile.isNullOrBlank()) {
                    val verified = targetDir.exists() && targetDir.isDirectory
                    return@withContext FileExecutionReceipt(
                        folderPath = targetDir.name ?: sanitizedFolder.orEmpty(),
                        filePath = null,
                        verified = verified,
                        bytesWritten = 0L,
                        storageScope = "SAF_AUTHORIZED",
                        summary = if (verified) "Verified SAF folder '${targetDir.name}'." else "Folder verification failed."
                    )
                }

                targetDir.findFile(sanitizedFile)?.delete()
                val mime = guessMimeType(sanitizedFile)
                val targetFile = targetDir.createFile(mime, sanitizedFile)
                    ?: throw IllegalStateException("Failed to create SAF file '$sanitizedFile'.")

                val bytes = (fileContent ?: "").toByteArray(Charsets.UTF_8)
                context.contentResolver.openOutputStream(targetFile.uri)?.use { out ->
                    out.write(bytes)
                    out.flush()
                } ?: throw FileNotFoundException("Unable to open SAF output stream.")

                val verified = targetFile.exists() && targetFile.length() >= bytes.size
                return@withContext FileExecutionReceipt(
                    folderPath = "${rootDoc.name ?: "Authorized"}/${sanitizedFolder.orEmpty()}",
                    filePath = sanitizedFile,
                    verified = verified,
                    bytesWritten = targetFile.length(),
                    storageScope = "SAF_AUTHORIZED",
                    summary = "Created & verified '$sanitizedFile' (${targetFile.length()} bytes) in SAF folder."
                )
            }
        }

        // Fallback/default: App-scoped TDB_Workspace
        val targetDir = if (!sanitizedFolder.isNullOrBlank()) {
            File(appWorkspaceRoot, sanitizedFolder).apply { mkdirs() }
        } else {
            appWorkspaceRoot
        }

        if (sanitizedFile.isNullOrBlank()) {
            val verified = targetDir.exists() && targetDir.isDirectory
            return@withContext FileExecutionReceipt(
                folderPath = targetDir.relativeTo(context.filesDir).path,
                filePath = null,
                verified = verified,
                bytesWritten = 0L,
                storageScope = "APP_WORKSPACE",
                summary = "Verified workspace folder '${targetDir.name}'."
            )
        }

        val targetFile = File(targetDir, sanitizedFile)
        val contentStr = fileContent.orEmpty()
        targetFile.writeText(contentStr, Charsets.UTF_8)
        val verified = targetFile.exists() && targetFile.length() >= contentStr.toByteArray(Charsets.UTF_8).size
        FileExecutionReceipt(
            folderPath = targetDir.relativeTo(context.filesDir).path,
            filePath = targetFile.relativeTo(context.filesDir).path,
            verified = verified,
            bytesWritten = targetFile.length(),
            storageScope = "APP_WORKSPACE",
            summary = "Created & verified '${targetFile.name}' (${targetFile.length()} bytes) in TDB_Workspace."
        )
    }

    suspend fun readFileContent(entry: ManagedFileEntry): String = withContext(Dispatchers.IO) {
        if (entry.storageScope == "SAF_AUTHORIZED" && !entry.uriString.isNullOrBlank()) {
            val uri = Uri.parse(entry.uriString)
            context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: throw FileNotFoundException("Cannot read SAF file ${entry.name}")
        } else {
            val target = File(appWorkspaceRoot, entry.relativePath).canonicalFile
            require(target.path.startsWith(appWorkspaceRoot.canonicalPath)) { "Blocked path traversal outside workspace." }
            target.readText(Charsets.UTF_8)
        }
    }

    suspend fun deleteEntry(entry: ManagedFileEntry): Boolean = withContext(Dispatchers.IO) {
        if (entry.storageScope == "SAF_AUTHORIZED" && !entry.uriString.isNullOrBlank()) {
            val doc = DocumentFile.fromSingleUri(context, Uri.parse(entry.uriString))
            doc?.delete() ?: false
        } else {
            val target = File(appWorkspaceRoot, entry.relativePath).canonicalFile
            if (!target.path.startsWith(appWorkspaceRoot.canonicalPath)) return@withContext false
            if (target.isDirectory) target.deleteRecursively() else target.delete()
        }
    }

    private fun walkLocalDirectory(dir: File, prefix: String, out: MutableList<ManagedFileEntry>) {
        val children = dir.listFiles()?.sortedByDescending { it.isDirectory } ?: return
        for (child in children) {
            val rel = if (prefix.isBlank()) child.name else "$prefix/${child.name}"
            out += ManagedFileEntry(
                name = child.name,
                relativePath = rel,
                isDirectory = child.isDirectory,
                sizeBytes = if (child.isDirectory) 0L else child.length(),
                lastModifiedMs = child.lastModified(),
                storageScope = "APP_WORKSPACE"
            )
            if (child.isDirectory) {
                walkLocalDirectory(child, rel, out)
            }
        }
    }

    private fun walkSafDirectory(dir: DocumentFile, prefix: String, out: MutableList<ManagedFileEntry>, depth: Int = 0) {
        if (depth > 2) return
        for (child in dir.listFiles()) {
            val name = child.name ?: continue
            val rel = if (prefix.isBlank()) name else "$prefix/$name"
            out += ManagedFileEntry(
                name = name,
                relativePath = rel,
                isDirectory = child.isDirectory,
                sizeBytes = if (child.isDirectory) 0L else child.length(),
                lastModifiedMs = child.lastModified(),
                storageScope = "SAF_AUTHORIZED",
                uriString = child.uri.toString()
            )
            if (child.isDirectory) {
                walkSafDirectory(child, rel, out, depth + 1)
            }
        }
    }

    private fun guessMimeType(fileName: String): String = when (fileName.substringAfterLast('.', "").lowercase()) {
        "html" -> "text/html"
        "css" -> "text/css"
        "js" -> "application/javascript"
        "json" -> "application/json"
        "md" -> "text/markdown"
        "xml" -> "application/xml"
        else -> "text/plain"
    }
}
