package com.example.core.data.repository

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.example.core.data.AiPersonality
import com.example.core.data.AppLanguage
import com.example.core.data.TdbPreferences
import com.example.core.data.TdbSettingsState
import com.example.core.data.db.ActionLogEntity
import com.example.core.data.db.ChatMessageEntity
import com.example.core.data.db.ChatSessionEntity
import com.example.core.data.db.MemoryEntity
import com.example.core.data.db.ScheduledTaskEntity
import com.example.core.data.db.TdbDatabase
import com.example.core.data.db.VideoProjectEntity
import com.example.core.error.ErrorDiagnosis
import com.example.core.error.ErrorRecoveryEngine
import com.example.core.network.ApiConnectionReport
import com.example.core.network.ApiConnectionStatus
import com.example.core.network.DiscoveredGeminiModel
import com.example.core.network.GeminiApiService
import com.example.core.security.KeystoreCryptoManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first

class TdbRepository(
    private val context: Context,
    private val database: TdbDatabase,
    val preferences: TdbPreferences,
    val crypto: KeystoreCryptoManager,
    val geminiApi: GeminiApiService
) {
    private val chatDao = database.chatDao()
    private val memoryDao = database.memoryDao()
    private val taskDao = database.taskDao()
    private val logDao = database.actionLogDao()
    private val videoDao = database.videoProjectDao()

    private val _discoveredModels = MutableStateFlow<List<DiscoveredGeminiModel>>(emptyList())
    val discoveredModels: StateFlow<List<DiscoveredGeminiModel>> = _discoveredModels.asStateFlow()

    private val _connectionReport = MutableStateFlow(
        if (crypto.hasSecret(KeystoreCryptoManager.KEY_GEMINI_API)) {
            ApiConnectionReport(ApiConnectionStatus.TESTING, message = "Key stored securely in Android Keystore. Ready to verify.")
        } else {
            ApiConnectionReport(ApiConnectionStatus.NOT_CONFIGURED, message = "Add your Gemini API key in Profile → Gemini API Management.")
        }
    )
    val connectionReport: StateFlow<ApiConnectionReport> = _connectionReport.asStateFlow()

    val settingsFlow: Flow<TdbSettingsState> = preferences.settingsFlow
    val sessionsFlow: Flow<List<ChatSessionEntity>> = chatDao.observeSessions()
    val memoriesFlow: Flow<List<MemoryEntity>> = memoryDao.observeMemories()
    val tasksFlow: Flow<List<ScheduledTaskEntity>> = taskDao.observeTasks()
    val actionLogsFlow: Flow<List<ActionLogEntity>> = logDao.observeLogs()
    val recentLogsFlow: Flow<List<ActionLogEntity>> = logDao.observeRecentLogs(6)
    val videoProjectsFlow: Flow<List<VideoProjectEntity>> = videoDao.observeProjects()

    fun observeMessages(sessionId: Long): Flow<List<ChatMessageEntity>> = chatDao.observeMessages(sessionId)

    fun searchMessages(query: String): Flow<List<ChatMessageEntity>> = chatDao.searchMessages(query)

    fun searchMemories(query: String): Flow<List<MemoryEntity>> = memoryDao.searchMemories(query)

    fun isOnline(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return true
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun getGeminiApiKey(): String? = crypto.getSecret(KeystoreCryptoManager.KEY_GEMINI_API)

    fun hasGeminiApiKey(): Boolean = crypto.hasSecret(KeystoreCryptoManager.KEY_GEMINI_API)

    fun getMaskedGeminiKey(): String = crypto.maskKey(getGeminiApiKey())

    suspend fun saveGeminiApiKey(rawKey: String): Result<ApiConnectionReport> {
        val saved = crypto.saveSecret(KeystoreCryptoManager.KEY_GEMINI_API, rawKey)
        if (saved.isFailure) {
            return Result.failure(saved.exceptionOrNull() ?: IllegalStateException("Keystore error"))
        }
        logAction("API", "Gemini API Key Encrypted", "Saved encrypted key using AndroidKeyStore AES-256-GCM.", "SUCCESS")
        return refreshConnectionAndModels()
    }

    suspend fun removeGeminiApiKey() {
        crypto.deleteSecret(KeystoreCryptoManager.KEY_GEMINI_API)
        _discoveredModels.value = emptyList()
        _connectionReport.value = ApiConnectionReport(
            status = ApiConnectionStatus.NOT_CONFIGURED,
            message = "Gemini API key removed from Keystore."
        )
        preferences.setSelectedChatModel("")
        preferences.setSelectedImageModel("")
        logAction("API", "Gemini API Key Removed", "Removed encrypted key from device vault.", "WARNING")
    }

    suspend fun refreshConnectionAndModels(): Result<ApiConnectionReport> {
        val key = getGeminiApiKey()
        if (key.isNullOrBlank()) {
            val report = ApiConnectionReport(ApiConnectionStatus.NOT_CONFIGURED, message = "No Gemini API key configured.")
            _connectionReport.value = report
            return Result.success(report)
        }
        _connectionReport.value = ApiConnectionReport(ApiConnectionStatus.TESTING, message = "Querying /v1beta/models...")
        return try {
            val start = System.currentTimeMillis()
            val models = geminiApi.discoverModels(key)
            val latency = System.currentTimeMillis() - start
            _discoveredModels.value = models
            preferences.setLastModelsRefresh(System.currentTimeMillis())

            val settings = preferences.settingsFlow.first()
            if (settings.selectedChatModelId.isBlank() || models.none { it.id == settings.selectedChatModelId }) {
                val bestChat = models.firstOrNull { it.supportsGenerateContent && !it.supportsImageOutput }
                    ?: models.firstOrNull { it.supportsGenerateContent }
                if (bestChat != null) preferences.setSelectedChatModel(bestChat.id)
            }
            if (settings.selectedImageModelId.isBlank() || models.none { it.id == settings.selectedImageModelId }) {
                val bestImage = models.firstOrNull { it.supportsImageOutput }
                if (bestImage != null) preferences.setSelectedImageModel(bestImage.id)
            }

            val report = ApiConnectionReport(
                status = ApiConnectionStatus.CONNECTED,
                latencyMs = latency,
                discoveredModelsCount = models.size,
                message = "Connected (${latency}ms) • ${models.size} models available"
            )
            _connectionReport.value = report
            logAction("API", "Model Discovery Complete", report.message, "SUCCESS")
            Result.success(report)
        } catch (e: Exception) {
            val diagnosis = ErrorRecoveryEngine.diagnose(e, "Gemini API discovery")
            val status = if (diagnosis.requiresUserPermission) ApiConnectionStatus.AUTH_FAILED else ApiConnectionStatus.OFFLINE_OR_ERROR
            val report = ApiConnectionReport(status = status, message = diagnosis.userMessage)
            _connectionReport.value = report
            logError("API", "API Connection Failed", diagnosis)
            Result.failure(e)
        }
    }

    suspend fun createChatSession(title: String, languageCode: String): Long {
        val now = System.currentTimeMillis()
        return chatDao.insertSession(ChatSessionEntity(title = title, languageCode = languageCode, createdAtMs = now, updatedAtMs = now))
    }

    suspend fun renameChatSession(sessionId: Long, title: String) {
        chatDao.updateSessionMeta(sessionId, title, System.currentTimeMillis())
    }

    suspend fun deleteChatSession(sessionId: Long) {
        chatDao.deleteSession(sessionId)
    }

    suspend fun getMessagesSnapshot(sessionId: Long): List<ChatMessageEntity> = chatDao.getMessagesSnapshot(sessionId)

    suspend fun appendChatMessage(
        sessionId: Long,
        role: String,
        content: String,
        attachmentLabel: String? = null,
        modelUsed: String? = null,
        reasoningSummary: String? = null
    ): Long {
        chatDao.touchSession(sessionId, System.currentTimeMillis())
        return chatDao.insertMessage(
            ChatMessageEntity(
                sessionId = sessionId,
                role = role,
                content = content,
                attachmentLabel = attachmentLabel,
                modelUsed = modelUsed,
                reasoningSummary = reasoningSummary
            )
        )
    }

    /**
     * Guards against saving passwords, API keys, or tokens into long-term memory.
     */
    suspend fun saveMemory(category: String, title: String, content: String): Result<Long> {
        if (containsSensitiveSecret(title) || containsSensitiveSecret(content)) {
            val msg = "Blocked saving sensitive secret/API key/password into Memory Vault."
            logAction("MEMORY", "Sensitive Data Blocked", msg, "WARNING")
            return Result.failure(IllegalArgumentException(msg))
        }
        val id = memoryDao.insertMemory(
            MemoryEntity(
                category = category,
                title = title.trim(),
                content = content.trim()
            )
        )
        logAction("MEMORY", "Memory Saved", "[$category] $title", "SUCCESS")
        return Result.success(id)
    }

    suspend fun updateMemory(memory: MemoryEntity): Result<Unit> {
        if (containsSensitiveSecret(memory.title) || containsSensitiveSecret(memory.content)) {
            return Result.failure(IllegalArgumentException("Passwords, API keys, and tokens cannot be stored in Memory."))
        }
        memoryDao.updateMemory(memory.copy(updatedAtMs = System.currentTimeMillis()))
        return Result.success(Unit)
    }

    suspend fun deleteMemory(id: Long) = memoryDao.deleteMemory(id)

    suspend fun clearAllMemories() = memoryDao.clearAllMemories()

    suspend fun getRecentMemoriesContext(): String {
        val settings = preferences.settingsFlow.first()
        if (!settings.memoryEnabled) return ""
        val list = memoryDao.getRecentMemories(10)
        if (list.isEmpty()) return ""
        return buildString {
            appendLine("User-Approved Long-Term Memories:")
            list.forEach { appendLine("- [${it.category}] ${it.title}: ${it.content}") }
        }
    }

    suspend fun insertTask(task: ScheduledTaskEntity): Long = taskDao.insertTask(task)
    suspend fun updateTask(task: ScheduledTaskEntity) = taskDao.updateTask(task)
    suspend fun getTaskById(taskId: Long): ScheduledTaskEntity? = taskDao.getTaskById(taskId)
    suspend fun deleteTask(taskId: Long) = taskDao.deleteTask(taskId)

    suspend fun saveVideoProject(toolType: String, topic: String, content: String, langCode: String): Long =
        videoDao.insertProject(VideoProjectEntity(toolType = toolType, topic = topic, generatedContent = content, languageCode = langCode))

    suspend fun deleteVideoProject(id: Long) = videoDao.deleteProject(id)

    suspend fun logAction(category: String, title: String, details: String, status: String) {
        logDao.insertLog(ActionLogEntity(category = category, title = title, details = details, status = status))
    }

    suspend fun logError(category: String, title: String, diagnosis: ErrorDiagnosis) {
        logDao.insertLog(
            ActionLogEntity(
                category = category,
                title = title,
                details = diagnosis.userMessage,
                status = "ERROR",
                errorCause = diagnosis.causeSummary,
                recoverySuggestion = diagnosis.recoverySuggestion
            )
        )
    }

    suspend fun clearLogs() = logDao.clearLogs()

    suspend fun buildSystemPrompt(extraRoleGuidance: String = ""): String {
        val settings = preferences.settingsFlow.first()
        val memories = getRecentMemoriesContext()
        val langHint = when (settings.primaryLanguage) {
            AppLanguage.BENGALI -> "Respond primarily in natural, clear Bengali (বাংলা) unless the user writes in English or Hindi, in which case match or support their language seamlessly."
            AppLanguage.ENGLISH -> "Respond primarily in clear English, while fluently supporting Bengali (বাংলা) and Hindi (हिन्दी) when requested."
            AppLanguage.HINDI -> "Respond primarily in natural Hindi (हिन्दी), while fluently supporting Bengali (বাংলা) and English when requested."
        }
        return buildString {
            appendLine("You are TDB Personal AI Assistant — an intelligent, JARVIS-inspired personal AI operating assistant.")
            appendLine("Identity Rules:")
            appendLine("- Brand: TDB")
            appendLine("- Founder and Creator: Deep Barmon")
            appendLine("- Official YouTube Channel: Deep Barmon Bhai Vlog")
            appendLine("- Motto: \"An AI That Doesn't Just Answer. An AI That Helps You Get Things Done.\"")
            appendLine("- If asked who created or founded you, always reply clearly: Founder and Creator: Deep Barmon. Brand: TDB.")
            appendLine("- Never claim to have executed a device, file, or YouTube action unless the system actually verified it.")
            appendLine("Language & Personality:")
            appendLine("- $langHint")
            appendLine("- Personality (${settings.personality.title}): ${settings.personality.instruction}")
            if (extraRoleGuidance.isNotBlank()) {
                appendLine("Workspace Focus: $extraRoleGuidance")
            }
            if (memories.isNotBlank()) {
                appendLine()
                append(memories)
            }
        }
    }

    internal fun containsSensitiveSecret(text: String): Boolean {
        val hasKeyPattern = Regex("""AIza[0-9A-Za-z\-_]{20,}""").containsMatchIn(text) ||
            Regex("""ya29\.[0-9A-Za-z\-_]+""").containsMatchIn(text) ||
            Regex("""sk-[0-9A-Za-z]{16,}""").containsMatchIn(text)
        val hasSensitiveAssignment = Regex(
            """\b(password|passcode|api[_\s]?key|secret[_\s]?key|access[_\s]?token|oauth[_\s]?token)\b\s*[:=]\s*\S+""",
            RegexOption.IGNORE_CASE
        ).containsMatchIn(text)
        return hasKeyPattern || hasSensitiveAssignment
    }
}
