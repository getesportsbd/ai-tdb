package com.example.core.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "chat_sessions")
data class ChatSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val languageCode: String = "bn",
    val createdAtMs: Long = System.currentTimeMillis(),
    val updatedAtMs: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "chat_messages",
    foreignKeys = [
        ForeignKey(
            entity = ChatSessionEntity::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("sessionId")]
)
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val role: String, // "user" or "model"
    val content: String,
    val attachmentLabel: String? = null,
    val modelUsed: String? = null,
    val reasoningSummary: String? = null,
    val timestampMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String, // PREFERENCE, PROJECT, TASK, INSTRUCTION, CONTEXT
    val title: String,
    val content: String,
    val createdAtMs: Long = System.currentTimeMillis(),
    val updatedAtMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "scheduled_tasks")
data class ScheduledTaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val commandPrompt: String,
    val planSummary: String,
    val actionType: String, // AI_BRIEFING, YOUTUBE_PREP, FILE_OPERATION, REMINDER, AUTOMATION_CHECK
    val recurrence: String, // ONCE, DAILY, WEEKLY
    val scheduledAtMs: Long,
    val status: String, // SCHEDULED, RUNNING, VERIFIED_SUCCESS, FAILED, CANCELLED
    val requiredPermissions: String,
    val requiredResources: String,
    val workerUuid: String? = null,
    val lastResult: String? = null,
    val lastError: String? = null,
    val retryCount: Int = 0,
    val createdAtMs: Long = System.currentTimeMillis(),
    val updatedAtMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "action_logs")
data class ActionLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String, // CHAT, VOICE, FILE, AUTOMATION, TASK, YOUTUBE, API, ERROR
    val title: String,
    val details: String,
    val status: String, // SUCCESS, WARNING, ERROR, RECOVERED
    val errorCause: String? = null,
    val recoverySuggestion: String? = null,
    val timestampMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "video_projects")
data class VideoProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val toolType: String, // IDEA, TITLE, SCRIPT, HOOK, SHORTS, VLOG, SEO
    val topic: String,
    val generatedContent: String,
    val languageCode: String = "bn",
    val createdAtMs: Long = System.currentTimeMillis()
)
