package com.example.core.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ChatSessionEntity::class,
        ChatMessageEntity::class,
        MemoryEntity::class,
        ScheduledTaskEntity::class,
        ActionLogEntity::class,
        VideoProjectEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class TdbDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun memoryDao(): MemoryDao
    abstract fun taskDao(): ScheduledTaskDao
    abstract fun actionLogDao(): ActionLogDao
    abstract fun videoProjectDao(): VideoProjectDao

    companion object {
        @Volatile
        private var INSTANCE: TdbDatabase? = null

        fun getInstance(context: Context): TdbDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    TdbDatabase::class.java,
                    "tdb_assistant_db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
