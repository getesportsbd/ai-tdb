package com.example.core.security

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Encrypts sensitive user credentials (Gemini API key, YouTube OAuth tokens)
 * using AES-256-GCM keys backed by AndroidKeyStore.
 * Secrets are never logged or stored in plaintext.
 */
class KeystoreCryptoManager(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existing = keyStore.getEntry(KEY_ALIAS, null) as? KeyStore.SecretKeyEntry
        if (existing != null) return existing.secretKey

        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }

    fun saveSecret(keyName: String, plainText: String): Result<Unit> = runCatching {
        require(plainText.isNotBlank()) { "Secret value must not be blank." }
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey())
        val iv = cipher.iv
        val encrypted = cipher.doFinal(plainText.trim().toByteArray(Charsets.UTF_8))
        prefs.edit()
            .putString("${keyName}_ct", Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .putString("${keyName}_iv", Base64.encodeToString(iv, Base64.NO_WRAP))
            .apply()
    }

    fun getSecret(keyName: String): String? {
        val ctEncoded = prefs.getString("${keyName}_ct", null) ?: return null
        val ivEncoded = prefs.getString("${keyName}_iv", null) ?: return null
        return runCatching {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            val iv = Base64.decode(ivEncoded, Base64.NO_WRAP)
            val ct = Base64.decode(ctEncoded, Base64.NO_WRAP)
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(ct), Charsets.UTF_8)
        }.getOrNull()
    }

    fun hasSecret(keyName: String): Boolean =
        prefs.contains("${keyName}_ct") && prefs.contains("${keyName}_iv")

    fun deleteSecret(keyName: String) {
        prefs.edit()
            .remove("${keyName}_ct")
            .remove("${keyName}_iv")
            .apply()
    }

    fun maskKey(raw: String?): String {
        if (raw.isNullOrBlank()) return "Not Configured"
        if (raw.length <= 10) return "••••••••"
        return "${raw.take(6)}••••••••${raw.takeLast(4)}"
    }

    companion object {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "tdb_assistant_master_aes_key"
        private const val PREFS_NAME = "tdb_encrypted_vault"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"

        const val KEY_GEMINI_API = "gemini_api_key"
        const val KEY_YOUTUBE_ACCESS_TOKEN = "youtube_oauth_access_token"
        const val KEY_YOUTUBE_REFRESH_TOKEN = "youtube_oauth_refresh_token"
    }
}
