package com.example.core.network

data class DiscoveredGeminiModel(
    val id: String,
    val resourceName: String,
    val displayName: String,
    val description: String,
    val supportedMethods: List<String>,
    val inputTokenLimit: Int,
    val outputTokenLimit: Int
) {
    val supportsGenerateContent: Boolean
        get() = supportedMethods.any { it.equals("generateContent", ignoreCase = true) }

    val supportsImageOutput: Boolean
        get() {
            val lower = id.lowercase()
            return (lower.contains("image") || lower.contains("imagen") || lower.contains("banana")) &&
                (supportsGenerateContent || supportedMethods.any { it.equals("predict", ignoreCase = true) })
        }

    val supportsPredictOnly: Boolean
        get() = !supportsGenerateContent && supportedMethods.any { it.equals("predict", ignoreCase = true) }

    val supportsLiveAudio: Boolean
        get() = supportedMethods.any { it.equals("bidiGenerateContent", ignoreCase = true) }

    val capabilitySummary: String
        get() = buildList {
            if (supportsGenerateContent) add("Text & Multimodal")
            if (supportsImageOutput) add("Image Gen")
            if (supportsLiveAudio) add("Live Bidi")
            if (supportsPredictOnly) add("Imagen Predict")
        }.ifEmpty { listOf("Standard") }.joinToString(" • ")
}

enum class ApiConnectionStatus(val label: String) {
    NOT_CONFIGURED("Not Configured"),
    TESTING("Testing..."),
    CONNECTED("Connected"),
    AUTH_FAILED("Invalid Key / Unauthorized"),
    OFFLINE_OR_ERROR("Connection Error")
}

data class ApiConnectionReport(
    val status: ApiConnectionStatus,
    val latencyMs: Long = 0L,
    val discoveredModelsCount: Int = 0,
    val message: String = ""
)

data class ChatTurnInput(
    val role: String, // "user" or "model"
    val text: String
)

data class InlineAttachment(
    val mimeType: String,
    val base64Data: String,
    val label: String
)

sealed interface StreamChunk {
    data class ReasoningDelta(val text: String) : StreamChunk
    data class TextDelta(val text: String) : StreamChunk
    data class Completed(val engineUsed: String) : StreamChunk
}

data class GenerationOptions(
    val temperature: Float = 0.7f,
    val topP: Float = 0.95f,
    val maxOutputTokens: Int = 2048,
    val enableThinking: Boolean = true,
    val preferInteractionsApi: Boolean = true
)
